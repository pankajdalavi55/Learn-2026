# Quick Start Guide - MyShop E-Commerce Platform

## 🚀 Quick Start (5 Minutes)

### Step 1: Start MySQL Database
```bash
# Ensure MySQL is running on localhost:3306
# Create database (if not exists)
mysql -u root -p
CREATE DATABASE app_data;
exit;
```

### Step 2: Start Backend (Terminal 1)
```bash
cd my-app
./gradlew bootRun

# Wait for "Started MyAppApplication" message
# Backend will be running on http://localhost:8080
```

### Step 3: Start Frontend (Terminal 2)
```bash
cd my-app-ui
npm install  # First time only
npm run dev

# Frontend will be running on http://localhost:5173
```

### Step 4: Access the Application
Open your browser to: **http://localhost:5173**

## 👤 Creating Your First Account

### Option 1: Register via UI
1. Click "Sign up" in the navbar
2. Fill in the registration form
3. Select role: Customer or Vendor
4. Click "Create account"
5. You'll be automatically logged in

### Option 2: Register via API
```bash
curl -X POST http://localhost:8080/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "name": "John Doe",
    "email": "john@example.com",
    "phone": "1234567890",
    "password": "password123",
    "role": "CUSTOMER"
  }'
```

## 🛒 Testing the Shopping Flow

### 1. Browse Products
- Go to home page (automatically displayed)
- Use search bar to find products
- Apply filters (category, brand, price)

### 2. Add to Cart
- Click on a product card
- View product details
- Select quantity
- Click "Add to Cart"

### 3. View Cart
- Click cart icon in navbar (shows item count)
- Review items
- Update quantities or remove items

### 4. Checkout
- Click "Proceed to Checkout" in cart
- Fill in shipping information
- Select payment method
- Click "Place Order"

### 5. View Orders
- Go to "My Orders" in navbar
- See order history
- Click "View Details" for specific order

## 🔐 Creating Admin User

Since ADMIN role cannot be self-registered, you need to:

### Option 1: Direct Database Insert
```sql
USE app_data;

-- Insert admin user (password is BCrypt hash of "password123")
INSERT INTO user (name, email, phone, password, role, created_at, updated_at) 
VALUES (
  'Admin User',
  'admin@test.com',
  '1234567890',
  '$2a$10$YourBcryptHashHere',
  'ADMIN',
  NOW(),
  NOW()
);
```

### Option 2: Modify Registration Endpoint Temporarily
Edit `AuthService.java` to allow ADMIN role in registration:
```java
// Temporarily allow all roles
User user = new User();
user.setRole(request.getRole()); // Don't force CUSTOMER
```

Then register via UI with ADMIN role, and revert the code.

### Option 3: Create via Postman/cURL (after having one admin)
```bash
# Login as admin first
TOKEN=$(curl -s -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@test.com","password":"password123"}' \
  | jq -r '.token')

# Create new admin user
curl -X POST http://localhost:8080/api/users \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "name": "Another Admin",
    "email": "admin2@test.com",
    "phone": "1234567890",
    "password": "password123",
    "role": "ADMIN"
  }'
```

## 📦 Adding Sample Products

### Via API (requires VENDOR+ role)
```bash
# Login first
curl -X POST http://localhost:8080/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "your@email.com",
    "password": "yourpassword"
  }'

# Copy the token from response, then:
curl -X POST http://localhost:8080/api/products \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer YOUR_TOKEN_HERE" \
  -d '{
    "name": "Laptop Pro 15",
    "description": "High-performance laptop with 16GB RAM",
    "price": 1299.99,
    "brand": "TechBrand",
    "stockQuantity": 50,
    "categoryId": 1,
    "imageUrl": "https://via.placeholder.com/400"
  }'
```

### Via SQL (Quick Demo Data)
```sql
USE app_data;

-- Insert categories
INSERT INTO category (name, description, active, created_at, updated_at) VALUES
('Electronics', 'Electronic devices and gadgets', true, NOW(), NOW()),
('Clothing', 'Fashion and apparel', true, NOW(), NOW()),
('Books', 'Books and magazines', true, NOW(), NOW());

-- Insert products (assuming category IDs are 1, 2, 3)
INSERT INTO product (name, description, price, brand, stock_quantity, category_id, created_at, updated_at) VALUES
('Laptop Pro 15', 'High-performance laptop', 1299.99, 'TechBrand', 50, 1, NOW(), NOW()),
('Wireless Mouse', 'Ergonomic wireless mouse', 29.99, 'TechBrand', 200, 1, NOW(), NOW()),
('T-Shirt Classic', 'Cotton comfort t-shirt', 19.99, 'FashionCo', 100, 2, NOW(), NOW()),
('Programming Book', 'Learn to code', 49.99, 'TechBooks', 75, 3, NOW(), NOW());
```

## 🎯 Testing Different Roles

### Customer Role
- Login as customer
- Browse products ✅
- Add to cart ✅
- Place orders ✅
- View own orders ✅
- Access admin pages ❌

### Vendor Role
- All customer features ✅
- Create products ✅
- Edit own products ✅
- Delete own products ❌ (Manager only)

### Manager Role
- View all data ✅
- Manage all products ✅
- Manage categories ✅
- Update order status ✅
- Manage users ❌ (Admin only)

### Admin Role
- Full system access ✅
- User management ✅
- Override all restrictions ✅

## 🐛 Common Issues

### Backend won't start
**Problem**: Database connection error
**Solution**: 
- Check MySQL is running
- Verify credentials in `application.yaml`
- Ensure database `app_data` exists

### Frontend won't connect to backend
**Problem**: CORS errors or network errors
**Solution**:
- Ensure backend is running on port 8080
- Check API_BASE_URL in `src/services/axios.ts`
- Verify SecurityConfig allows CORS

### Can't add to cart
**Problem**: Not logged in or invalid token
**Solution**:
- Login first
- Check browser console for errors
- Clear localStorage and login again

### Products not showing
**Problem**: No products in database
**Solution**:
- Add sample products via SQL or API
- Check backend logs for errors

## 📱 API Testing with Postman

### Collection Setup
1. Import base URL: `http://localhost:8080/api`
2. Create environment variable: `token`

### Test Sequence
1. **Register/Login**
   - POST `/auth/login`
   - Save token from response

2. **Browse Products**
   - GET `/products?page=0&size=20`

3. **Add to Cart**
   - POST `/cart/add?userId=1`
   - Add Authorization header: `Bearer {{token}}`

4. **Place Order**
   - POST `/orders?userId=1`
   - Include shipping details

## 🎨 UI Customization

### Change Primary Color
Edit `tailwind.config.js`:
```javascript
theme: {
  extend: {
    colors: {
      primary: {
        500: '#your-color',
        600: '#your-darker-color',
      }
    }
  }
}
```

### Update Logo
Replace "MyShop" text in `Navbar.tsx`:
```tsx
<Link to="/" className="flex-shrink-0">
  <img src="/logo.png" alt="Logo" className="h-8" />
</Link>
```

## 📊 Monitoring

### Backend Health Check
```bash
curl http://localhost:8080/actuator/health
```

### API Documentation
Open in browser:
```
http://localhost:8080/swagger-ui.html
```

### Database Inspection
```bash
mysql -u root -p
USE app_data;
SHOW TABLES;
SELECT COUNT(*) FROM product;
SELECT COUNT(*) FROM user;
```

## 🔄 Reset Database
```sql
DROP DATABASE app_data;
CREATE DATABASE app_data;
-- Restart backend to recreate tables
```

## 📚 Next Steps

After getting started:
1. Explore the admin dashboard (with admin account)
2. Try different user roles
3. Test product filtering and search
4. Review the code structure
5. Add your own features

## 💡 Tips

- Use browser DevTools (F12) to debug frontend
- Check backend console for API logs
- Use React DevTools extension
- Enable debug logging in application.yaml
- Use Postman for API testing

## 🆘 Getting Help

1. Check console logs (both frontend and backend)
2. Review error messages carefully
3. Check API documentation (Swagger)
4. Verify database state
5. Review security configurations

Happy coding! 🚀
