# My App - Frontend UI Documentation

## 📋 Table of Contents
1. [Overview](#overview)
2. [Tech Stack](#tech-stack)
3. [Project Structure](#project-structure)
4. [Pages & Features](#pages--features)
5. [Components](#components)
6. [Routing](#routing)
7. [State Management](#state-management)
8. [API Integration](#api-integration)
9. [Styling & Responsive Design](#styling--responsive-design)
10. [Authentication & Authorization](#authentication--authorization)
11. [Setup & Installation](#setup--installation)
12. [Build & Deployment](#build--deployment)

---

## 🎯 Overview

My App is a modern e-commerce platform built with React 18, TypeScript, and Vite. The application provides a complete shopping experience with user authentication, product browsing, cart management, order processing, and profile management including saved addresses and payment cards.

**Key Features:**
- 🛍️ Product catalog with search, filtering, and pagination
- 🛒 Shopping cart with real-time updates
- 👤 User profile management with profile pictures
- 📍 Saved shipping addresses
- 💳 Saved payment cards (encrypted)
- 📦 Order history and tracking
- 🔐 JWT-based authentication
- 📱 Fully responsive design for all devices
- ♿ Accessibility-focused UI

---

## 🛠 Tech Stack

### Core Technologies
- **React 18.3.1** - UI library with hooks
- **TypeScript 5.5.3** - Type-safe development
- **Vite 5.4.10** - Fast build tool and dev server

### Routing & Navigation
- **React Router DOM 6.27.0** - Client-side routing

### State Management
- **React Context API** - Global state (Auth, Cart)
- **React Hooks** - Local component state

### Styling
- **Tailwind CSS 3.4.15** - Utility-first CSS framework
- **PostCSS 8.4.49** - CSS processing
- **Autoprefixer 10.4.20** - Vendor prefixes

### UI Components & Icons
- **React Icons 5.3.0** - Icon library
- **React Toastify 10.0.6** - Toast notifications

### HTTP Client
- **Axios 1.7.7** - HTTP requests with interceptors

### Development Tools
- **ESLint 9.13.0** - Code linting
- **TypeScript ESLint** - TypeScript linting
- **Vite Plugin React** - Fast Refresh

---

## 📁 Project Structure

```
my-app-ui/
├── public/                      # Static assets
├── src/
│   ├── assets/                  # Images, fonts, etc.
│   ├── components/              # Reusable components
│   │   ├── common/              # Common components
│   │   │   ├── Loading.tsx      # Loading spinner
│   │   │   └── Navbar.tsx       # Navigation bar
│   │   └── product/             # Product-specific components
│   │       └── ProductCard.tsx  # Product card component
│   ├── context/                 # React Context providers
│   │   ├── AuthContext.tsx      # Authentication state
│   │   └── CartContext.tsx      # Shopping cart state
│   ├── pages/                   # Page components
│   │   ├── AdminDashboard.tsx   # Admin dashboard
│   │   ├── Cart.tsx             # Shopping cart page
│   │   ├── Categories.tsx       # Category browsing
│   │   ├── Checkout.tsx         # Checkout process
│   │   ├── Home.tsx             # Home/product listing
│   │   ├── Login.tsx            # Login page
│   │   ├── OrderDetail.tsx      # Single order details
│   │   ├── Orders.tsx           # Order history
│   │   ├── ProductDetail.tsx    # Product details
│   │   ├── Profile.tsx          # User profile
│   │   └── Register.tsx         # Registration page
│   ├── services/                # API service layer
│   │   ├── auth.service.ts      # Authentication APIs
│   │   ├── axios.ts             # Axios instance with interceptors
│   │   ├── cart.service.ts      # Cart APIs
│   │   ├── category.service.ts  # Category APIs
│   │   ├── order.service.ts     # Order APIs
│   │   └── product.service.ts   # Product APIs
│   ├── types/                   # TypeScript type definitions
│   │   └── index.ts             # All type definitions
│   ├── utils/                   # Utility functions
│   │   └── helpers.ts           # Helper functions
│   ├── App.tsx                  # Root component
│   ├── index.css                # Global styles
│   └── main.tsx                 # Application entry point
├── .gitignore
├── eslint.config.js             # ESLint configuration
├── index.html                   # HTML template
├── package.json                 # Dependencies
├── postcss.config.js            # PostCSS configuration
├── tailwind.config.js           # Tailwind CSS configuration
├── tsconfig.json                # TypeScript configuration
├── tsconfig.app.json            # App TypeScript config
├── tsconfig.node.json           # Node TypeScript config
└── vite.config.ts               # Vite configuration
```

---

## 📄 Pages & Features

### 1. **Home Page** (`/`)
**File:** `src/pages/Home.tsx`

**Features:**
- Product grid with 12 products per page
- Search functionality by product name
- Advanced filtering:
  - Category filter
  - Brand filter
  - Price range (min/max)
- Pagination controls
- Responsive grid: 1 col (mobile) → 2 cols (tablet) → 3 cols (desktop) → 4 cols (large screens)
- Collapsible filter panel
- Sort by creation date (newest first)

**State:**
- `products` - Product array
- `categories` - Available categories
- `brands` - Available brands
- `searchKeyword` - Search term
- `filter` - Active filters
- `pagination` - Page number, size, total pages

### 2. **Product Detail Page** (`/products/:id`)
**File:** `src/pages/ProductDetail.tsx`

**Features:**
- Large product image display
- Product information (name, brand, description, price)
- Stock availability indicator
- Category badge
- Quantity selector (1-10 or available stock)
- Add to cart button (authenticated users only)
- Responsive layout with centered image on mobile
- Login prompt for unauthenticated users

**State:**
- `product` - Product details
- `quantity` - Selected quantity

### 3. **Categories Page** (`/categories`)
**File:** `src/pages/Categories.tsx`

**Features:**
- Category sidebar with product counts
- Category grid view with images
- Products filtered by selected category
- Pagination for products
- "All Products" option
- Responsive sidebar (collapsible on mobile)
- Category cards with hover effects

**State:**
- `categories` - All categories
- `selectedCategory` - Currently selected category
- `products` - Products in selected category
- `pagination` - Pagination state

### 4. **Shopping Cart Page** (`/cart`)
**File:** `src/pages/Cart.tsx`

**Features:**
- Cart item list with images
- Quantity controls (+/- buttons)
- Remove item functionality
- Clear cart option
- Order summary with totals
- "Proceed to Checkout" button
- "Continue Shopping" button
- Empty cart state with CTA
- Responsive card layout
- Real-time total calculation

**State:**
- Managed by `CartContext`

### 5. **Checkout Page** (`/checkout`)
**File:** `src/pages/Checkout.tsx`

**Features:**
- **Saved Addresses:**
  - Display all saved addresses as selectable cards
  - Auto-select default address
  - "Add New Address" option
  - Auto-fill shipping form when address selected
- **Saved Payment Cards:**
  - Display saved cards when Credit Card selected
  - Show masked card numbers
  - Auto-select default card
  - "Add New Card" option
- **Payment Methods:**
  - Credit Card
  - Cash on Delivery
- **Order Summary Sidebar:**
  - Item count and subtotal
  - Free shipping indicator
  - Total amount
- **Place Order Button**
- Responsive layout with stacked columns on mobile

**State:**
- `formData` - Shipping and payment info
- `savedAddresses` - User's saved addresses
- `savedCards` - User's saved payment cards
- `selectedAddressId` - Selected address
- `selectedCardId` - Selected card
- `useNewAddress` - Toggle for manual address entry
- `useNewCard` - Toggle for manual card entry

### 6. **Orders Page** (`/orders`)
**File:** `src/pages/Orders.tsx`

**Features:**
- Order history list
- Order status badges (color-coded)
- Order number and date
- Total items and amount
- Payment method
- Shipping address preview
- "View Details" button
- Pagination (10 orders per page)
- Empty state with CTA
- Responsive card layout

**State:**
- `orders` - Order array
- `pagination` - Page number, size, total pages

### 7. **Order Detail Page** (`/orders/:orderId`)
**File:** `src/pages/OrderDetail.tsx`

**Features:**
- Order header with status badge
- Complete item list with quantities and prices
- Shipping information
- Order notes (if any)
- Order summary sidebar:
  - Subtotal and total
  - Payment method and status
  - Delivery date (if delivered)
- "Cancel Order" button (for pending orders)
- "Back to Orders" navigation
- Responsive layout

**State:**
- `order` - Complete order details

### 8. **Profile Page** (`/profile`)
**File:** `src/pages/Profile.tsx`

**Features:**
- **Profile Header:**
  - Profile picture upload/delete
  - User name and role
  - Edit profile button
- **Basic Information Section:**
  - Name, email, phone, address
  - Editable fields
  - Save/Cancel buttons
- **Saved Addresses Section:**
  - List all addresses with labels
  - Default address indicator (star icon)
  - Add new address button
  - Edit/Delete actions per address
  - Set as default option
  - Modal form for add/edit
- **Saved Payment Cards Section:**
  - List all cards with masked numbers
  - Card type badges (Visa, Mastercard, etc.)
  - Default card indicator
  - Add new card button
  - Edit/Delete actions per card
  - Set as default option
  - Modal form for add/edit with validation
- **Form Validations:**
  - Card number: 13+ digits
  - Expiry month: 01-12 (auto-format)
  - Expiry year: current year to +20 years

**State:**
- `formData` - Profile information
- `isEditing` - Edit mode toggle
- `addresses` - Saved addresses
- `paymentCards` - Saved cards
- `showAddressModal` - Address modal visibility
- `showCardModal` - Card modal visibility
- `editingAddress` - Address being edited
- `editingCard` - Card being edited
- `profilePicture` - Profile picture URL

### 9. **Login Page** (`/login`)
**File:** `src/pages/Login.tsx`

**Features:**
- Email and password inputs
- Icon decorations
- "Sign in" button
- Link to registration
- Demo credentials display
- Responsive centered layout
- Gradient background
- Role-based redirect after login

**State:**
- `formData` - Login credentials
- `isSubmitting` - Loading state

### 10. **Register Page** (`/register`)
**File:** `src/pages/Register.tsx`

**Features:**
- Full name input
- Email input
- Phone input
- Password input (min 6 characters)
- Role selection (Customer/Vendor)
- "Create account" button
- Link to login
- Icon decorations
- Responsive centered layout
- Gradient background

**State:**
- `formData` - Registration data
- `isSubmitting` - Loading state

### 11. **Admin Dashboard** (`/admin`)
**File:** `src/pages/AdminDashboard.tsx`

**Features:**
- Admin-only access
- Dashboard statistics
- User management
- Product management
- Order management
- Role-based content

**Access:** Restricted to ADMIN and MANAGER roles

---

## 🧩 Components

### Common Components

#### **Navbar** (`src/components/common/Navbar.tsx`)
**Features:**
- Logo/brand name
- Navigation links (Home, Categories, Orders, Profile)
- Cart icon with item count badge
- Login/Logout buttons
- User greeting
- Responsive hamburger menu on mobile
- Role-based link visibility

**Props:** None (uses AuthContext and CartContext)

#### **Loading** (`src/components/common/Loading.tsx`)
**Features:**
- Centered loading spinner
- Optional message prop
- Animated spinner icon
- Full-screen or inline modes

**Props:**
```typescript
interface LoadingProps {
  message?: string;
}
```

### Product Components

#### **ProductCard** (`src/components/product/ProductCard.tsx`)
**Features:**
- Product image
- Product name and brand
- Price display
- Stock indicator
- Category badge
- "View Details" button
- Hover effects
- Responsive layout

**Props:**
```typescript
interface ProductCardProps {
  product: Product;
}
```

---

## 🗺️ Routing

**File:** `src/App.tsx`

### Public Routes
- `/` - Home page
- `/login` - Login page
- `/register` - Registration page
- `/products/:id` - Product detail page
- `/categories` - Categories page

### Protected Routes (Require Authentication)
- `/cart` - Shopping cart
- `/checkout` - Checkout process
- `/orders` - Order history
- `/orders/:orderId` - Order details
- `/profile` - User profile

### Admin Routes (Require ADMIN/MANAGER Role)
- `/admin` - Admin dashboard

### Route Protection
```typescript
// ProtectedRoute component checks authentication
<Route element={<ProtectedRoute />}>
  <Route path="/cart" element={<Cart />} />
  // ... other protected routes
</Route>
```

---

## 🔄 State Management

### AuthContext (`src/context/AuthContext.tsx`)

**Provides:**
```typescript
interface AuthContextType {
  user: AuthResponse | null;
  isAuthenticated: boolean;
  login: (credentials: LoginRequest) => Promise<AuthResponse>;
  register: (data: RegisterRequest) => Promise<void>;
  logout: () => void;
  setUser: (user: AuthResponse | null) => void;
}
```

**Features:**
- Manages authentication state
- Stores JWT token in localStorage
- Persists user data across page refreshes
- Provides login/logout/register functions
- User profile updates

### CartContext (`src/context/CartContext.tsx`)

**Provides:**
```typescript
interface CartContextType {
  cart: Cart | null;
  isLoading: boolean;
  addToCart: (request: AddToCartRequest) => Promise<void>;
  updateCartItem: (productId: number, quantity: number) => Promise<void>;
  removeFromCart: (productId: number) => Promise<void>;
  clearCart: () => Promise<void>;
  refreshCart: () => Promise<void>;
}
```

**Features:**
- Manages shopping cart state
- Fetches cart on mount
- Real-time cart updates
- Optimistic UI updates
- Toast notifications for actions
- Cart persistence in backend

---

## 🌐 API Integration

### Axios Configuration (`src/services/axios.ts`)

**Features:**
- Base URL configuration: `http://localhost:8080/api`
- Request interceptor: Adds JWT token to headers
- Response interceptor: Handles 401 errors and auto-logout
- Content-Type: application/json

**Configuration:**
```typescript
axios.defaults.baseURL = 'http://localhost:8080/api';

// Request interceptor
request.headers.Authorization = `Bearer ${token}`;

// Response interceptor
if (error.response?.status === 401) {
  // Auto logout and redirect
}
```

### Service Layer

#### **Auth Service** (`src/services/auth.service.ts`)
```typescript
- login(credentials: LoginRequest): Promise<AuthResponse>
- register(data: RegisterRequest): Promise<void>
```

#### **Product Service** (`src/services/product.service.ts`)
```typescript
- getAllProducts(pageRequest: PageRequest): Promise<PageResponse<Product>>
- getProductById(id: number): Promise<Product>
- filterProducts(filter: ProductFilter, pageRequest: PageRequest): Promise<PageResponse<Product>>
- getAllBrands(): Promise<string[]>
- getProducts(params): Promise<PageResponse<Product>>
```

#### **Category Service** (`src/services/category.service.ts`)
```typescript
- getAllCategories(activeOnly?: boolean): Promise<Category[]>
- getCategoryById(id: number): Promise<Category>
```

#### **Cart Service** (`src/services/cart.service.ts`)
```typescript
- getCart(userId: number): Promise<Cart>
- addToCart(userId: number, request: AddToCartRequest): Promise<Cart>
- updateCartItem(userId: number, productId: number, quantity: number): Promise<Cart>
- removeFromCart(userId: number, productId: number): Promise<void>
- clearCart(userId: number): Promise<void>
```

#### **Order Service** (`src/services/order.service.ts`)
```typescript
- placeOrder(userId: number, request: OrderRequest): Promise<Order>
- getUserOrders(userId: number, page: number, size: number): Promise<PageResponse<Order>>
- getOrderById(orderId: number, userId: number): Promise<Order>
```

---

## 🎨 Styling & Responsive Design

### Tailwind Configuration (`tailwind.config.js`)

**Custom Theme:**
```javascript
colors: {
  primary: {
    50: '#eff6ff',
    100: '#dbeafe',
    // ... up to 900
  },
  secondary: { /* ... */ },
  accent: { /* ... */ },
}
```

### Global Styles (`src/index.css`)

**Custom Classes:**
```css
.btn-primary - Primary button style with active state
.btn-secondary - Secondary button style with active state
.btn-danger - Danger button style with active state
.input-field - Form input style with focus states
.card - Card container with responsive padding
.touch-manipulation - Better touch handling
.animate-fadeIn - Fade-in animation
```

**Utilities:**
- Smooth scrolling
- Custom scrollbars (desktop)
- Better focus indicators
- Text selection prevention on buttons

### Responsive Breakpoints

```
Mobile:    < 640px   (default)
Tablet:    640px+    (sm:)
Desktop:   768px+    (md:)
Desktop:   1024px+   (lg:)
Large:     1280px+   (xl:)
XL:        1536px+   (2xl:)
```

### Mobile Optimizations

1. **Touch Targets:** Minimum 44px height
2. **Text Sizing:** Smaller base text on mobile, scales up
3. **Spacing:** Reduced padding on mobile
4. **Sticky Elements:** Only on large screens
5. **Grids:** Stack vertically on mobile
6. **Buttons:** Full-width on mobile where appropriate
7. **Forms:** Better input sizing for mobile keyboards
8. **Navigation:** Hamburger menu on mobile (if implemented)

### Responsive Patterns Used

```typescript
// Typography
text-2xl sm:text-3xl lg:text-4xl

// Spacing
py-6 sm:py-8

// Grid
grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4

// Flexbox
flex-col sm:flex-row

// Visibility
hidden sm:block

// Sticky
lg:sticky lg:top-20
```

---

## 🔐 Authentication & Authorization

### JWT Token Flow

1. **Login:**
   - User submits credentials
   - Backend returns JWT token and user data
   - Token stored in localStorage
   - User data stored in AuthContext

2. **Authenticated Requests:**
   - Axios interceptor adds token to Authorization header
   - Format: `Bearer <token>`

3. **Token Expiration:**
   - Backend returns 401 Unauthorized
   - Response interceptor catches error
   - Auto-logout user
   - Redirect to login page
   - Clear localStorage

4. **Logout:**
   - Remove token from localStorage
   - Clear AuthContext
   - Redirect to login

### Role-Based Access Control (RBAC)

**Roles:**
- `CUSTOMER` - Regular user
- `VENDOR` - Vendor/seller
- `SUPPORT` - Support staff
- `MANAGER` - Manager
- `ADMIN` - Administrator

**Access Levels:**
```typescript
// Admin routes
if (user.role === 'ADMIN' || user.role === 'MANAGER') {
  // Allow access
}

// Customer routes
if (isAuthenticated) {
  // Allow access
}
```

### Protected Routes Implementation

```typescript
const ProtectedRoute: React.FC = () => {
  const { isAuthenticated } = useAuth();
  
  if (!isAuthenticated) {
    return <Navigate to="/login" replace />;
  }
  
  return <Outlet />;
};
```

---

## 🚀 Setup & Installation

### Prerequisites
- Node.js 18+ and npm 9+
- Backend API running on `http://localhost:8080`

### Installation Steps

1. **Clone the repository:**
```bash
cd my-app-ui
```

2. **Install dependencies:**
```bash
npm install
```

3. **Configure environment:**
Create `.env` file if needed:
```env
VITE_API_BASE_URL=http://localhost:8080/api
```

4. **Start development server:**
```bash
npm run dev
```

5. **Access application:**
```
http://localhost:5173
```

### Available Scripts

```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run preview      # Preview production build
npm run lint         # Run ESLint
```

---

## 📦 Build & Deployment

### Production Build

```bash
npm run build
```

**Output:** `dist/` directory

**Build includes:**
- Minified JavaScript bundles
- Optimized CSS
- Compressed assets
- Source maps

### Build Configuration (`vite.config.ts`)

```typescript
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
  },
  build: {
    outDir: 'dist',
    sourcemap: true,
  },
})
```

### Deployment Options

1. **Vercel:**
```bash
npm install -g vercel
vercel
```

2. **Netlify:**
```bash
npm install -g netlify-cli
netlify deploy
```

3. **Docker:**
```dockerfile
FROM node:18-alpine
WORKDIR /app
COPY package*.json ./
RUN npm install
COPY . .
RUN npm run build
EXPOSE 5173
CMD ["npm", "run", "preview"]
```

4. **Static Hosting:**
- Upload `dist/` folder to any static host
- Configure `index.html` as fallback for SPA routing

### Environment Variables

Production environment variables:
```env
VITE_API_BASE_URL=https://api.production.com/api
VITE_APP_NAME=My App
```

---

## 📱 Progressive Web App (PWA)

Currently not configured. To add PWA support:

1. Install `vite-plugin-pwa`
2. Configure manifest.json
3. Add service worker
4. Update vite.config.ts

---

## 🧪 Testing

Currently no tests configured. Recommended additions:

- **Unit Tests:** Vitest + React Testing Library
- **E2E Tests:** Playwright or Cypress
- **Component Tests:** Storybook

---

## 🔧 Troubleshooting

### Common Issues

1. **API Connection Failed:**
   - Ensure backend is running on port 8080
   - Check CORS configuration
   - Verify API base URL

2. **Cart Not Loading:**
   - Check if user is authenticated
   - Verify JWT token in localStorage
   - Check network requests in browser DevTools

3. **Images Not Displaying:**
   - Ensure image URLs are correct
   - Check backend file serving configuration
   - Verify CORS for image resources

4. **Build Errors:**
   - Clear node_modules and reinstall: `rm -rf node_modules package-lock.json && npm install`
   - Check TypeScript errors: `npm run build`
   - Verify all dependencies are installed

---

## 📚 Resources

- [React Documentation](https://react.dev)
- [TypeScript Handbook](https://www.typescriptlang.org/docs/)
- [Vite Guide](https://vitejs.dev/guide/)
- [Tailwind CSS Docs](https://tailwindcss.com/docs)
- [React Router](https://reactrouter.com)
- [Axios Documentation](https://axios-http.com/docs/intro)

---

## 📄 License

This project is part of a private application. All rights reserved.

---

## 👥 Contributors

- Development Team - Full Stack Development

---

## 📞 Support

For issues and questions:
- Create an issue in the repository
- Contact the development team

---

**Last Updated:** November 29, 2025
**Version:** 1.0.0
**React Version:** 18.3.1
**TypeScript Version:** 5.5.3
