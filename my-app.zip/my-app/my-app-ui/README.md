# My App - Frontend

Modern e-commerce platform built with React 18, TypeScript, and Vite.

## 🚀 Quick Start

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build

# Preview production build
npm run preview
```

## 📋 Tech Stack

- **React 18.3.1** - UI library
- **TypeScript 5.5.3** - Type safety
- **Vite 5.4.10** - Build tool
- **Tailwind CSS 3.4.15** - Styling
- **React Router 6.27.0** - Routing
- **Axios 1.7.7** - HTTP client

## 📚 Documentation

For complete documentation, see [UI_DOCUMENTATION.md](./UI_DOCUMENTATION.md)

## 🌐 Demo Credentials

- **Admin:** admin@test.com / Admin@123
- **Manager:** manager@test.com / Manager@123
- **Customer:** customer1@test.com / Customer@123

## 🔗 Backend API

Ensure the backend is running on `http://localhost:8080`

## ✨ Key Features

- 🛍️ Product catalog with search & filters
- 🛒 Shopping cart management
- 👤 User profile with saved addresses & cards
- 📦 Order tracking
- 🔐 JWT authentication
- 📱 Fully responsive design

## 📄 License

All rights reserved.
