import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../../context/CartContext';
import { useAuth } from '../../context/AuthContext';
import type { Product } from '../../types';
import { FaShoppingCart } from 'react-icons/fa';

interface ProductCardProps {
  product: Product;
}

const ProductCard: React.FC<ProductCardProps> = ({ product }) => {
  const { addToCart } = useCart();
  const { isAuthenticated } = useAuth();

  const handleAddToCart = async (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!isAuthenticated) {
      return;
    }

    try {
      await addToCart({ productId: product.id, quantity: 1 });
    } catch (error) {
      console.error('Failed to add to cart:', error);
    }
  };

  const isOutOfStock = product.stockQuantity === 0;

  return (
    <Link to={`/products/${product.id}`}>
      <div className="card hover:shadow-xl transition-shadow duration-300 h-full flex flex-col">
        <div className="relative pb-[75%] bg-gray-200 rounded-t-lg overflow-hidden">
          {product.imageUrl ? (
            <img
              src={product.imageUrl}
              alt={product.name}
              className="absolute inset-0 w-full h-full object-cover"
            />
          ) : (
            <div className="absolute inset-0 flex items-center justify-center text-gray-400">
              No Image
            </div>
          )}
          {isOutOfStock && (
            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
              <span className="bg-red-600 text-white px-4 py-2 rounded-lg font-semibold">
                Out of Stock
              </span>
            </div>
          )}
        </div>

        <div className="p-4 flex flex-col flex-grow">
          <h3 className="text-lg font-semibold text-gray-900 mb-1 line-clamp-2">
            {product.name}
          </h3>
          <p className="text-sm text-gray-600 mb-2">{product.brand}</p>
          <p className="text-gray-600 text-sm mb-3 line-clamp-2 flex-grow">
            {product.description}
          </p>

          <div className="flex items-center justify-between mt-auto">
            <div>
              <p className="text-2xl font-bold text-primary-600">
                ${product.price.toFixed(2)}
              </p>
              <p className="text-xs text-gray-500">
                {product.stockQuantity > 0 ? `${product.stockQuantity} in stock` : 'Out of stock'}
              </p>
            </div>

            {isAuthenticated && !isOutOfStock && (
              <button
                onClick={handleAddToCart}
                className="btn-primary flex items-center space-x-2"
                disabled={isOutOfStock}
              >
                <FaShoppingCart />
                <span>Add</span>
              </button>
            )}
          </div>
        </div>
      </div>
    </Link>
  );
};

export default ProductCard;
