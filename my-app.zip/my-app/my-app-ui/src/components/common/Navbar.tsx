import React from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../../context/AuthContext';
import { useCart } from '../../context/CartContext';
import { FaShoppingCart, FaUser, FaSignOutAlt, FaBox, FaTags, FaUsers } from 'react-icons/fa';

const Navbar: React.FC = () => {
  const { user, isAuthenticated, logout, hasRole } = useAuth();
  const { getCartItemCount } = useCart();
  const navigate = useNavigate();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <nav className="bg-white shadow-lg sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-16">
          <div className="flex items-center">
            <Link to="/" className="flex-shrink-0 flex items-center">
              <span className="text-2xl font-bold text-primary-600">MyShop</span>
            </Link>

            <div className="hidden md:ml-10 md:flex md:space-x-8">
              {hasRole(['ADMIN', 'MANAGER']) ? (
                <Link
                  to="/admin"
                  className="text-gray-700 hover:text-primary-600 px-3 py-2 text-sm font-medium transition"
                >
                  Dashboard
                </Link>
              ) : (
                <Link
                  to="/"
                  className="text-gray-700 hover:text-primary-600 px-3 py-2 text-sm font-medium transition"
                >
                  Products
                </Link>
              )}
              <Link
                to="/categories"
                className="text-gray-700 hover:text-primary-600 px-3 py-2 text-sm font-medium transition"
              >
                Categories
              </Link>
              {isAuthenticated && (
                <Link
                  to="/orders"
                  className="text-gray-700 hover:text-primary-600 px-3 py-2 text-sm font-medium transition"
                >
                  My Orders
                </Link>
              )}
            </div>
          </div>

          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                {/* Cart Icon */}
                <Link
                  to="/cart"
                  className="relative text-gray-700 hover:text-primary-600 transition"
                >
                  <FaShoppingCart className="h-6 w-6" />
                  {getCartItemCount() > 0 && (
                    <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                      {getCartItemCount()}
                    </span>
                  )}
                </Link>

                {/* Profile Link */}
                <Link
                  to="/profile"
                  className="text-gray-700 hover:text-primary-600 transition"
                  title="Profile"
                >
                  <FaUser className="h-6 w-6" />
                </Link>

                {/* Admin/Manager Links */}
                {hasRole(['ADMIN', 'MANAGER']) && (
                  <div className="hidden md:flex items-center space-x-4">
                    <Link
                      to="/admin/products"
                      className="text-gray-700 hover:text-primary-600 transition"
                      title="Manage Products"
                    >
                      <FaBox className="h-5 w-5" />
                    </Link>
                    <Link
                      to="/admin/categories"
                      className="text-gray-700 hover:text-primary-600 transition"
                      title="Manage Categories"
                    >
                      <FaTags className="h-5 w-5" />
                    </Link>
                  </div>
                )}

                {/* Logout Button */}
                <button
                  onClick={handleLogout}
                  className="flex items-center space-x-2 text-gray-700 hover:text-primary-600 transition px-3 py-2 text-sm font-medium"
                  title="Logout"
                >
                  <FaSignOutAlt className="h-5 w-5" />
                  <span className="hidden md:block">Logout</span>
                </button>
              </>
            ) : (
              <div className="flex items-center space-x-4">
                <Link
                  to="/login"
                  className="text-gray-700 hover:text-primary-600 px-3 py-2 text-sm font-medium transition"
                >
                  Login
                </Link>
                <Link
                  to="/register"
                  className="btn-primary"
                >
                  Sign up
                </Link>
              </div>
            )}
          </div>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
