import React, { createContext, useContext, useState, useEffect } from 'react';
import { cartService } from '../services/cart.service';
import { useAuth } from './AuthContext';
import type { Cart, AddToCartRequest } from '../types';
import { toast } from 'react-toastify';

interface CartContextType {
  cart: Cart | null;
  isLoading: boolean;
  fetchCart: () => Promise<void>;
  addToCart: (request: AddToCartRequest) => Promise<void>;
  updateCartItem: (productId: number, quantity: number) => Promise<void>;
  removeFromCart: (productId: number) => Promise<void>;
  clearCart: () => Promise<void>;
  getCartItemCount: () => number;
}

const CartContext = createContext<CartContextType | undefined>(undefined);

export const useCart = () => {
  const context = useContext(CartContext);
  if (!context) {
    throw new Error('useCart must be used within CartProvider');
  }
  return context;
};

export const CartProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [cart, setCart] = useState<Cart | null>(null);
  const [isLoading, setIsLoading] = useState(false);
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    if (isAuthenticated && user) {
      fetchCart();
    } else {
      setCart(null);
    }
  }, [isAuthenticated, user]);

  const fetchCart = async () => {
    if (!user) return;
    
    setIsLoading(true);
    try {
      console.log('Fetching cart for user:', user.userId);
      const cartData = await cartService.getCart(user.userId);
      console.log('Cart data received:', cartData);
      setCart(cartData);
    } catch (error: any) {
      console.error('Failed to fetch cart:', error);
      console.error('Error response:', error.response);
      // Don't show error toast for empty cart (404) or just set empty cart state
      if (error.response?.status === 404) {
        setCart(null);
      } else {
        toast.error('Failed to load cart');
      }
    } finally {
      setIsLoading(false);
    }
  };

  const addToCart = async (request: AddToCartRequest) => {
    if (!user) {
      toast.error('Please login to add items to cart');
      return;
    }

    try {
      const updatedCart = await cartService.addToCart(user.userId, request);
      setCart(updatedCart);
      toast.success('Item added to cart');
    } catch (error: any) {
      const message = error.response?.data?.message || 'Failed to add item to cart';
      toast.error(message);
      throw error;
    }
  };

  const updateCartItem = async (productId: number, quantity: number) => {
    if (!user) return;

    try {
      const updatedCart = await cartService.updateCartItem(user.userId, productId, quantity);
      setCart(updatedCart);
      toast.success('Cart updated');
    } catch (error: any) {
      const message = error.response?.data?.message || 'Failed to update cart';
      toast.error(message);
      throw error;
    }
  };

  const removeFromCart = async (productId: number) => {
    if (!user) return;

    try {
      const updatedCart = await cartService.removeFromCart(user.userId, productId);
      setCart(updatedCart);
      toast.success('Item removed from cart');
    } catch (error: any) {
      const message = error.response?.data?.message || 'Failed to remove item';
      toast.error(message);
      throw error;
    }
  };

  const clearCart = async () => {
    if (!user) return;

    try {
      await cartService.clearCart(user.userId);
      setCart(null);
      toast.success('Cart cleared');
    } catch (error: any) {
      toast.error('Failed to clear cart');
      throw error;
    }
  };

  const getCartItemCount = (): number => {
    return cart?.totalItems || 0;
  };

  return (
    <CartContext.Provider
      value={{
        cart,
        isLoading,
        fetchCart,
        addToCart,
        updateCartItem,
        removeFromCart,
        clearCart,
        getCartItemCount,
      }}
    >
      {children}
    </CartContext.Provider>
  );
};
