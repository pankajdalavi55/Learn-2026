import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  FaBox,
  FaTags,
  FaUsers,
  FaShoppingCart,
  FaDollarSign,
  FaClock,
  FaExclamationTriangle,
  FaArrowUp,
  FaArrowDown,
  FaChartLine,
  FaCalendarDay,
} from 'react-icons/fa';
import { productService } from '../services/product.service';
import { categoryService } from '../services/category.service';
import { orderService } from '../services/order.service';
import type { Order, Product } from '../types';
import Loading from '../components/common/Loading';
import { toast } from 'react-toastify';

interface Stats {
  totalProducts: number;
  totalCategories: number;
  totalOrders: number;
  todayOrders: number;
  totalRevenue: number;
  todayRevenue: number;
  lowStockProducts: number;
  outOfStockProducts: number;
}

const AdminDashboard: React.FC = () => {
  const [stats, setStats] = useState<Stats>({
    totalProducts: 0,
    totalCategories: 0,
    totalOrders: 0,
    todayOrders: 0,
    totalRevenue: 0,
    todayRevenue: 0,
    lowStockProducts: 0,
    outOfStockProducts: 0,
  });
  const [recentOrders, setRecentOrders] = useState<Order[]>([]);
  const [lowStockProducts, setLowStockProducts] = useState<Product[]>([]);
  const [outOfStockProducts, setOutOfStockProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [showLowStockModal, setShowLowStockModal] = useState(false);
  const [showOutOfStockModal, setShowOutOfStockModal] = useState(false);
  const [outOfStockPage, setOutOfStockPage] = useState(0);
  const [lowStockPage, setLowStockPage] = useState(0);
  const [outOfStockTotal, setOutOfStockTotal] = useState(0);
  const [lowStockTotal, setLowStockTotal] = useState(0);
  const pageSize = 10;

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const fetchOutOfStockProducts = async (page: number) => {
    try {
      const response = await productService.getOutOfStockProducts(page, pageSize);
      setOutOfStockProducts(response.content);
      setOutOfStockTotal(response.totalElements);
    } catch (error) {
      console.error('Failed to fetch out of stock products:', error);
      setOutOfStockProducts([]);
    }
  };

  const fetchLowStockProducts = async (page: number) => {
    try {
      const response = await productService.getLowStockProducts(10, page, pageSize);
      setLowStockProducts(response.content);
      setLowStockTotal(response.totalElements);
    } catch (error) {
      console.error('Failed to fetch low stock products:', error);
      setLowStockProducts([]);
    }
  };

  const fetchDashboardData = async () => {
    setLoading(true);
    try {
      // Fetch data in parallel
      const [productsResponse, categories, ordersResponse, outOfStock, lowStock] = await Promise.all([
        productService.getAllProducts({ page: 0, size: 1 }), // Just get count
        categoryService.getAllCategories(),
        orderService.getAllOrders(0, 1000),
        productService.getOutOfStockProducts(0, 1).catch(err => {
          console.warn('Out of stock API not available yet, using default:', err.message);
          return { content: [], totalElements: 0, totalPages: 0, size: 0, number: 0 };
        }),
        productService.getLowStockProducts(10, 0, 1).catch(err => {
          console.warn('Low stock API not available yet, using default:', err.message);
          return { content: [], totalElements: 0, totalPages: 0, size: 0, number: 0 };
        }),
      ]);

      const allOrders = ordersResponse.content;

      // Calculate order stats
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      const todayOrders = allOrders.filter((order) => {
        const orderDate = new Date(order.createdAt);
        orderDate.setHours(0, 0, 0, 0);
        return orderDate.getTime() === today.getTime();
      });

      const totalRevenue = allOrders.reduce((sum, order) => sum + order.totalAmount, 0);
      const todayRevenue = todayOrders.reduce((sum, order) => sum + order.totalAmount, 0);

      console.log('Out of stock products:', outOfStock.totalElements);
      console.log('Low stock products:', lowStock.totalElements);

      setStats({
        totalProducts: productsResponse.totalElements,
        totalCategories: categories.length,
        totalOrders: allOrders.length,
        todayOrders: todayOrders.length,
        totalRevenue: totalRevenue,
        todayRevenue: todayRevenue,
        lowStockProducts: lowStock.totalElements,
        outOfStockProducts: outOfStock.totalElements,
      });

      setRecentOrders(allOrders.slice(0, 5));
      setOutOfStockTotal(outOfStock.totalElements);
      setLowStockTotal(lowStock.totalElements);
    } catch (error) {
      toast.error('Failed to load dashboard data');
      console.error('Failed to fetch dashboard data:', error);
    } finally {
      setLoading(false);
    }
  };

  const getOrderStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      PENDING: 'bg-yellow-100 text-yellow-800',
      PROCESSING: 'bg-blue-100 text-blue-800',
      SHIPPED: 'bg-purple-100 text-purple-800',
      DELIVERED: 'bg-green-100 text-green-800',
      CANCELLED: 'bg-red-100 text-red-800',
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  if (loading) {
    return <Loading message="Loading dashboard..." />;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex justify-between items-center mb-8">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Admin Dashboard</h1>
          <p className="text-gray-600 mt-1">Welcome back! Here's what's happening today.</p>
        </div>
        <div className="flex items-center space-x-2 text-sm text-gray-600">
          <FaCalendarDay />
          <span>{new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}</span>
        </div>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        {/* Total Products */}
        <div className="card hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Products</p>
              <h3 className="text-3xl font-bold text-gray-900">{stats.totalProducts}</h3>
              <p className="text-xs text-green-600 mt-2 flex items-center">
                <FaArrowUp className="mr-1" /> Active
              </p>
            </div>
            <div className="p-4 bg-primary-100 rounded-lg">
              <FaBox className="h-8 w-8 text-primary-600" />
            </div>
          </div>
        </div>

        {/* Total Categories */}
        <div className="card hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Categories</p>
              <h3 className="text-3xl font-bold text-gray-900">{stats.totalCategories}</h3>
              <p className="text-xs text-gray-500 mt-2">Active categories</p>
            </div>
            <div className="p-4 bg-green-100 rounded-lg">
              <FaTags className="h-8 w-8 text-green-600" />
            </div>
          </div>
        </div>

        {/* Total Orders */}
        <div className="card hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Orders</p>
              <h3 className="text-3xl font-bold text-gray-900">{stats.totalOrders}</h3>
              <p className="text-xs text-blue-600 mt-2 flex items-center">
                <FaClock className="mr-1" /> {stats.todayOrders} today
              </p>
            </div>
            <div className="p-4 bg-blue-100 rounded-lg">
              <FaShoppingCart className="h-8 w-8 text-blue-600" />
            </div>
          </div>
        </div>

        {/* Total Revenue */}
        <div className="card hover:shadow-xl transition-shadow">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-sm text-gray-600 mb-1">Total Revenue</p>
              <h3 className="text-3xl font-bold text-gray-900">${stats.totalRevenue.toFixed(2)}</h3>
              <p className="text-xs text-green-600 mt-2 flex items-center">
                <FaArrowUp className="mr-1" /> ${stats.todayRevenue.toFixed(2)} today
              </p>
            </div>
            <div className="p-4 bg-purple-100 rounded-lg">
              <FaDollarSign className="h-8 w-8 text-purple-600" />
            </div>
          </div>
        </div>
      </div>

      {/* Inventory Alerts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Stock Alerts */}
        <div className="card">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-bold text-gray-900">Inventory Alerts</h2>
            <FaExclamationTriangle className="text-orange-500" />
          </div>
          <div className="space-y-3">
            <button
              onClick={() => {
                console.log('Out of stock clicked, count:', stats.outOfStockProducts);
                setOutOfStockPage(0);
                fetchOutOfStockProducts(0);
                setShowOutOfStockModal(true);
              }}
              disabled={stats.outOfStockProducts === 0}
              className="w-full flex items-center justify-between p-3 bg-red-50 rounded-lg hover:bg-red-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
            >
              <div className="text-left">
                <p className="text-sm font-semibold text-red-900">Out of Stock</p>
                <p className="text-xs text-red-600">Requires immediate attention</p>
              </div>
              <span className="text-2xl font-bold text-red-600">{stats.outOfStockProducts}</span>
            </button>
            <button
              onClick={() => {
                console.log('Low stock clicked, count:', stats.lowStockProducts);
                setLowStockPage(0);
                fetchLowStockProducts(0);
                setShowLowStockModal(true);
              }}
              disabled={stats.lowStockProducts === 0}
              className="w-full flex items-center justify-between p-3 bg-orange-50 rounded-lg hover:bg-orange-100 transition-colors disabled:opacity-50 disabled:cursor-not-allowed cursor-pointer"
            >
              <div className="text-left">
                <p className="text-sm font-semibold text-orange-900">Low Stock</p>
                <p className="text-xs text-orange-600">Less than 10 items remaining</p>
              </div>
              <span className="text-2xl font-bold text-orange-600">{stats.lowStockProducts}</span>
            </button>
          </div>
        </div>

        {/* Quick Actions */}
        <div className="card">
          <h2 className="text-xl font-bold text-gray-900 mb-4">Quick Actions</h2>
          <div className="grid grid-cols-2 gap-3">
            <Link to="/admin/products" className="btn-primary text-center py-3 text-sm">
              <FaBox className="inline mr-2" />
              Manage Products
            </Link>
            <Link to="/admin/categories" className="btn-primary text-center py-3 text-sm">
              <FaTags className="inline mr-2" />
              Manage Categories
            </Link>
            <Link to="/orders" className="btn-secondary text-center py-3 text-sm">
              <FaShoppingCart className="inline mr-2" />
              View Orders
            </Link>
            <Link to="/" className="btn-secondary text-center py-3 text-sm">
              <FaChartLine className="inline mr-2" />
              Analytics
            </Link>
          </div>
        </div>
      </div>



      {/* Recent Orders */}
      {recentOrders.length > 0 && (
        <div className="card mb-8">
          <div className="flex justify-between items-center mb-4">
            <h2 className="text-xl font-bold text-gray-900">Recent Orders</h2>
            <Link to="/orders" className="text-sm text-primary-600 hover:text-primary-700">
              View All →
            </Link>
          </div>
          <div className="overflow-x-auto">
            <table className="min-w-full divide-y divide-gray-200">
              <thead>
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Order Number
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    User ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Items
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Total
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Status
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                    Date
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {recentOrders.map((order) => (
                  <tr key={order.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap">
                      <Link
                        to={`/orders/${order.id}`}
                        className="text-sm font-medium text-primary-600 hover:text-primary-700"
                      >
                        {order.orderNumber}
                      </Link>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      #{order.userId}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {order.totalItems}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      ${order.totalAmount.toFixed(2)}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getOrderStatusColor(order.status)}`}>
                        {order.status}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(order.createdAt).toLocaleDateString()}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Activity Summary */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">Today's Activity</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">New Orders</span>
              <span className="text-lg font-bold text-gray-900">{stats.todayOrders}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Revenue</span>
              <span className="text-lg font-bold text-green-600">
                ${stats.todayRevenue.toFixed(2)}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Products Sold</span>
              <span className="text-lg font-bold text-gray-900">
                {recentOrders.reduce((sum, order) => sum + order.totalItems, 0)}
              </span>
            </div>
          </div>
        </div>

        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">Order Status</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Pending</span>
              <span className="text-lg font-bold text-yellow-600">
                {recentOrders.filter((o) => o.status === 'PENDING').length}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Processing</span>
              <span className="text-lg font-bold text-blue-600">
                {recentOrders.filter((o) => o.status === 'PROCESSING').length}
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Shipped</span>
              <span className="text-lg font-bold text-purple-600">
                {recentOrders.filter((o) => o.status === 'SHIPPED').length}
              </span>
            </div>
          </div>
        </div>

        <div className="card">
          <h3 className="text-lg font-semibold text-gray-900 mb-3">System Status</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Database</span>
              <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                Healthy
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">API Status</span>
              <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                Online
              </span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-sm text-gray-600">Last Backup</span>
              <span className="text-xs text-gray-500">2 hours ago</span>
            </div>
          </div>
        </div>
      </div>

      {/* Out of Stock Modal */}
      {showOutOfStockModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-6xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b">
              <h2 className="text-2xl font-bold text-gray-900">Out of Stock Products</h2>
              <button
                onClick={() => setShowOutOfStockModal(false)}
                className="text-gray-400 hover:text-gray-600 text-2xl"
              >
                ×
              </button>
            </div>
            <div className="overflow-y-auto max-h-[calc(90vh-140px)] p-6">
              {outOfStockProducts.length === 0 ? (
                <p className="text-center text-gray-500 py-8">No out of stock products</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          Product
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          Category
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          Brand
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          Price
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          Stock
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {outOfStockProducts.map((product) => (
                        <tr key={product.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="flex-shrink-0 h-12 w-12 bg-gray-200 rounded">
                                {product.imageUrl ? (
                                  <img
                                    src={product.imageUrl}
                                    alt={product.name}
                                    className="h-12 w-12 rounded object-cover"
                                  />
                                ) : (
                                  <div className="h-12 w-12 flex items-center justify-center text-gray-400 text-xs">
                                    No img
                                  </div>
                                )}
                              </div>
                              <div className="ml-4">
                                <div className="text-sm font-medium text-gray-900">{product.name}</div>
                                <div className="text-xs text-gray-500">ID: {product.id}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {product.category?.name || product.categoryName || 'N/A'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {product.brand || 'N/A'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-semibold">
                            ${product.price.toFixed(2)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="text-sm font-bold text-red-600">
                              {product.stockQuantity}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-red-100 text-red-800">
                              Out of Stock
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
            <div className="flex justify-between items-center p-6 border-t bg-gray-50">
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => {
                    const newPage = outOfStockPage - 1;
                    setOutOfStockPage(newPage);
                    fetchOutOfStockProducts(newPage);
                  }}
                  disabled={outOfStockPage === 0}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Previous
                </button>
                <span className="text-sm text-gray-700">
                  Page {outOfStockPage + 1} of {Math.ceil(outOfStockTotal / pageSize) || 1}
                </span>
                <button
                  onClick={() => {
                    const newPage = outOfStockPage + 1;
                    setOutOfStockPage(newPage);
                    fetchOutOfStockProducts(newPage);
                  }}
                  disabled={(outOfStockPage + 1) * pageSize >= outOfStockTotal}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Next
                </button>
              </div>
              <button
                onClick={() => setShowOutOfStockModal(false)}
                className="btn-secondary"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Low Stock Modal */}
      {showLowStockModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-lg max-w-6xl w-full max-h-[90vh] overflow-hidden">
            <div className="flex items-center justify-between p-6 border-b">
              <h2 className="text-2xl font-bold text-gray-900">Low Stock Products</h2>
              <button
                onClick={() => setShowLowStockModal(false)}
                className="text-gray-400 hover:text-gray-600 text-2xl"
              >
                ×
              </button>
            </div>
            <div className="overflow-y-auto max-h-[calc(90vh-140px)] p-6">
              {lowStockProducts.length === 0 ? (
                <p className="text-center text-gray-500 py-8">No low stock products</p>
              ) : (
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-50">
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          Product
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          Category
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          Brand
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          Price
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          Stock
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                          Status
                        </th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {lowStockProducts.map((product) => (
                        <tr key={product.id} className="hover:bg-gray-50">
                          <td className="px-6 py-4 whitespace-nowrap">
                            <div className="flex items-center">
                              <div className="flex-shrink-0 h-12 w-12 bg-gray-200 rounded">
                                {product.imageUrl ? (
                                  <img
                                    src={product.imageUrl}
                                    alt={product.name}
                                    className="h-12 w-12 rounded object-cover"
                                  />
                                ) : (
                                  <div className="h-12 w-12 flex items-center justify-center text-gray-400 text-xs">
                                    No img
                                  </div>
                                )}
                              </div>
                              <div className="ml-4">
                                <div className="text-sm font-medium text-gray-900">{product.name}</div>
                                <div className="text-xs text-gray-500">ID: {product.id}</div>
                              </div>
                            </div>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {product.category?.name || product.categoryName || 'N/A'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                            {product.brand || 'N/A'}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900 font-semibold">
                            ${product.price.toFixed(2)}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="text-sm font-bold text-orange-600">
                              {product.stockQuantity}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className="px-3 py-1 inline-flex text-xs leading-5 font-semibold rounded-full bg-orange-100 text-orange-800">
                              Low Stock
                            </span>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
            <div className="flex justify-between items-center p-6 border-t bg-gray-50">
              <div className="flex items-center space-x-2">
                <button
                  onClick={() => {
                    const newPage = lowStockPage - 1;
                    setLowStockPage(newPage);
                    fetchLowStockProducts(newPage);
                  }}
                  disabled={lowStockPage === 0}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Previous
                </button>
                <span className="text-sm text-gray-700">
                  Page {lowStockPage + 1} of {Math.ceil(lowStockTotal / pageSize) || 1}
                </span>
                <button
                  onClick={() => {
                    const newPage = lowStockPage + 1;
                    setLowStockPage(newPage);
                    fetchLowStockProducts(newPage);
                  }}
                  disabled={(lowStockPage + 1) * pageSize >= lowStockTotal}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-md hover:bg-gray-50 disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Next
                </button>
              </div>
              <button
                onClick={() => setShowLowStockModal(false)}
                className="btn-secondary"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminDashboard;
