import React, { useState, useEffect, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { FaUser, FaEnvelope, FaPhone, FaMapMarkerAlt, FaEdit, FaSave, FaTimes, FaShieldAlt, FaPlus, FaCreditCard, FaTrash, FaStar, FaRegStar, FaCamera } from 'react-icons/fa';
import { toast } from 'react-toastify';
import axios from '../services/axios';

interface Address {
  id: number;
  label: string;
  fullName: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  isDefault: boolean;
}

interface PaymentCard {
  id: number;
  label: string;
  cardholderName: string;
  maskedCardNumber: string;
  cardLastFour: string;
  cardType: string;
  expiryMonth: string;
  expiryYear: string;
  isDefault: boolean;
}

const Profile: React.FC = () => {
  const { user, setUser } = useAuth();
  const [isEditing, setIsEditing] = useState(false);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    phone: user?.phone || '',
    address: user?.address || '',
  });

  // Profile picture state
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [profilePicture, setProfilePicture] = useState<string | null>(user?.profilePictureUrl || null);
  const [uploadingPicture, setUploadingPicture] = useState(false);

  // Addresses state
  const [addresses, setAddresses] = useState<Address[]>([]);
  const [showAddressModal, setShowAddressModal] = useState(false);
  const [editingAddress, setEditingAddress] = useState<Address | null>(null);

  // Payment cards state
  const [paymentCards, setPaymentCards] = useState<PaymentCard[]>([]);
  const [showCardModal, setShowCardModal] = useState(false);
  const [editingCard, setEditingCard] = useState<PaymentCard | null>(null);

  useEffect(() => {
    if (user) {
      fetchAddresses();
      fetchPaymentCards();
      setProfilePicture(user.profilePictureUrl || null);
    }
  }, [user]);

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSave = () => {
    // TODO: Implement API call to update user profile
    toast.success('Profile updated successfully!');
    setIsEditing(false);
  };

  const handleCancel = () => {
    setFormData({
      name: user?.name || '',
      email: user?.email || '',
      phone: user?.phone || '',
      address: user?.address || '',
    });
    setIsEditing(false);
  };

  // Fetch Addresses
  const fetchAddresses = async () => {
    try {
      const response = await axios.get('/user/addresses');
      setAddresses(response.data);
    } catch (error: any) {
      console.error('Error fetching addresses:', error);
      // Only show error if it's not a 401/403 (authentication issue)
      if (error.response && error.response.status !== 401 && error.response.status !== 403) {
        toast.error('Error loading addresses');
      }
    }
  };

  // Fetch Payment Cards
  const fetchPaymentCards = async () => {
    try {
      const response = await axios.get('/user/cards');
      setPaymentCards(response.data);
    } catch (error: any) {
      console.error('Error fetching payment cards:', error);
      // Only show error if it's not a 401/403 (authentication issue)
      if (error.response && error.response.status !== 401 && error.response.status !== 403) {
        toast.error('Error loading payment cards');
      }
    }
  };

  // Delete Address
  const handleDeleteAddress = async (addressId: number) => {
    if (!window.confirm('Are you sure you want to delete this address?')) return;
    
    try {
      await axios.delete(`/user/addresses/${addressId}`);
      toast.success('Address deleted successfully!');
      fetchAddresses();
    } catch (error) {
      toast.error('Error deleting address');
    }
  };

  // Set Default Address
  const handleSetDefaultAddress = async (addressId: number) => {
    try {
      await axios.patch(`/user/addresses/${addressId}/set-default`);
      toast.success('Default address updated!');
      fetchAddresses();
    } catch (error) {
      toast.error('Error setting default address');
    }
  };

  // Delete Payment Card
  const handleDeleteCard = async (cardId: number) => {
    if (!window.confirm('Are you sure you want to delete this card?')) return;
    
    try {
      await axios.delete(`/user/cards/${cardId}`);
      toast.success('Card deleted successfully!');
      fetchPaymentCards();
    } catch (error) {
      toast.error('Error deleting card');
    }
  };

  // Set Default Card
  const handleSetDefaultCard = async (cardId: number) => {
    try {
      await axios.patch(`/user/cards/${cardId}/set-default`);
      toast.success('Default card updated!');
      fetchPaymentCards();
    } catch (error) {
      toast.error('Error setting default card');
    }
  };

  // Profile Picture Upload
  const handleProfilePictureClick = () => {
    fileInputRef.current?.click();
  };

  const handleProfilePictureChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    // Validate file type
    const allowedTypes = ['image/jpeg', 'image/jpg', 'image/png', 'image/gif'];
    if (!allowedTypes.includes(file.type)) {
      toast.error('Invalid file type. Only JPG, PNG, and GIF are allowed.');
      return;
    }

    // Validate file size (max 5MB)
    if (file.size > 5 * 1024 * 1024) {
      toast.error('File size too large. Maximum size is 5MB.');
      return;
    }

    setUploadingPicture(true);

    try {
      const formData = new FormData();
      formData.append('file', file);

      const response = await axios.post('/users/profile-picture', formData, {
        headers: {
          'Content-Type': 'multipart/form-data',
        },
      });

      setProfilePicture(response.data.profilePictureUrl);
      
      // Update user context with new profile picture
      if (setUser && user) {
        setUser({ ...user, profilePictureUrl: response.data.profilePictureUrl });
      }
      
      toast.success('Profile picture updated successfully!');
    } catch (error) {
      console.error('Error uploading profile picture:', error);
      toast.error('Error uploading profile picture');
    } finally {
      setUploadingPicture(false);
    }
  };

  const handleDeleteProfilePicture = async () => {
    if (!window.confirm('Are you sure you want to delete your profile picture?')) return;

    try {
      await axios.delete('/users/profile-picture');
      setProfilePicture(null);
      
      // Update user context
      if (setUser && user) {
        setUser({ ...user, profilePictureUrl: null });
      }
      
      toast.success('Profile picture deleted successfully!');
    } catch (error) {
      console.error('Error deleting profile picture:', error);
      toast.error('Error deleting profile picture');
    }
  };

  if (!user) {
    return (
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <p className="text-gray-600">Please log in to view your profile.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
      <div className="mb-6">
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">My Profile</h1>
        <p className="text-sm sm:text-base text-gray-600 mt-1">Manage your account information</p>
      </div>

      {/* Profile Header Card */}
      <div className="card mb-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div className="flex items-center space-x-3 sm:space-x-4">
            <div className="relative">
              <div className="h-16 w-16 sm:h-20 sm:w-20 bg-primary-100 rounded-full flex items-center justify-center overflow-hidden border-4 border-white shadow-lg">
                {profilePicture ? (
                  <img 
                    src={`http://localhost:8080${profilePicture}`} 
                    alt="Profile" 
                    className="h-full w-full object-cover"
                  />
                ) : (
                  <FaUser className="h-10 w-10 text-primary-600" />
                )}
              </div>
              <button
                onClick={handleProfilePictureClick}
                disabled={uploadingPicture}
                className="absolute bottom-0 right-0 bg-primary-600 text-white p-1.5 sm:p-2 rounded-full hover:bg-primary-700 transition shadow-lg disabled:opacity-50 touch-manipulation"
                title="Change profile picture"
              >
                <FaCamera className="h-2.5 w-2.5 sm:h-3 sm:w-3" />
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/jpeg,image/jpg,image/png,image/gif"
                onChange={handleProfilePictureChange}
                className="hidden"
              />
            </div>
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-gray-900">{user.name}</h2>
              <div className="flex items-center space-x-2 mt-1">
                <FaShieldAlt className="h-3 w-3 sm:h-4 sm:w-4 text-gray-500" />
                <span className="text-xs sm:text-sm text-gray-600">Role: <span className="font-semibold text-primary-600">{user.role}</span></span>
              </div>
              {profilePicture && (
                <button
                  onClick={handleDeleteProfilePicture}
                  className="text-xs text-red-600 hover:text-red-800 mt-1 touch-manipulation"
                >
                  Remove picture
                </button>
              )}
            </div>
          </div>
          {!isEditing && (
            <button
              onClick={() => setIsEditing(true)}
              className="btn-primary flex items-center space-x-2 w-full sm:w-auto justify-center touch-manipulation"
            >
              <FaEdit />
              <span>Edit Profile</span>
            </button>
          )}
        </div>
      </div>

      {/* Profile Details Card */}
      <div className="card">
        <h3 className="text-xl font-bold text-gray-900 mb-6">Profile Information</h3>
        
        <div className="space-y-6">
          {/* Name */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <FaUser className="mr-2 text-gray-400" />
              Full Name
            </label>
            {isEditing ? (
              <input
                type="text"
                name="name"
                value={formData.name}
                onChange={handleInputChange}
                className="input-field"
                placeholder="Enter your full name"
              />
            ) : (
              <p className="text-gray-900 bg-gray-50 px-4 py-3 rounded-lg">{user.name}</p>
            )}
          </div>

          {/* Email */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <FaEnvelope className="mr-2 text-gray-400" />
              Email Address
            </label>
            {isEditing ? (
              <input
                type="email"
                name="email"
                value={formData.email}
                onChange={handleInputChange}
                className="input-field"
                placeholder="Enter your email"
                disabled
              />
            ) : (
              <p className="text-gray-900 bg-gray-50 px-4 py-3 rounded-lg">{user.email}</p>
            )}
            <p className="text-xs text-gray-500 mt-1">Email cannot be changed</p>
          </div>

          {/* Phone */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <FaPhone className="mr-2 text-gray-400" />
              Phone Number
            </label>
            {isEditing ? (
              <input
                type="tel"
                name="phone"
                value={formData.phone}
                onChange={handleInputChange}
                className="input-field"
                placeholder="Enter your phone number"
              />
            ) : (
              <p className="text-gray-900 bg-gray-50 px-4 py-3 rounded-lg">
                {user.phone || 'Not provided'}
              </p>
            )}
          </div>

          {/* Address */}
          <div>
            <label className="flex items-center text-sm font-medium text-gray-700 mb-2">
              <FaMapMarkerAlt className="mr-2 text-gray-400" />
              Address
            </label>
            {isEditing ? (
              <textarea
                name="address"
                value={formData.address}
                onChange={handleInputChange}
                className="input-field"
                rows={3}
                placeholder="Enter your address"
              />
            ) : (
              <p className="text-gray-900 bg-gray-50 px-4 py-3 rounded-lg">
                {user.address || 'Not provided'}
              </p>
            )}
          </div>

          {/* Account Information */}
          <div className="pt-6 border-t">
            <h4 className="text-lg font-semibold text-gray-900 mb-4">Account Information</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700">User ID</label>
                <p className="text-gray-900 bg-gray-50 px-4 py-3 rounded-lg mt-1">#{user.id}</p>
              </div>
              <div>
                <label className="text-sm font-medium text-gray-700">Account Role</label>
                <p className="text-gray-900 bg-gray-50 px-4 py-3 rounded-lg mt-1">
                  <span className="inline-flex items-center px-3 py-1 rounded-full text-sm font-semibold bg-primary-100 text-primary-800">
                    {user.role}
                  </span>
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        {isEditing && (
          <div className="flex space-x-4 mt-6 pt-6 border-t">
            <button
              onClick={handleSave}
              className="btn-primary flex items-center space-x-2"
            >
              <FaSave />
              <span>Save Changes</span>
            </button>
            <button
              onClick={handleCancel}
              className="btn-secondary flex items-center space-x-2"
            >
              <FaTimes />
              <span>Cancel</span>
            </button>
          </div>
        )}
      </div>

      {/* Saved Addresses Section */}
      <div className="card mt-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-gray-900">Saved Addresses</h3>
          <button
            onClick={() => {
              setEditingAddress(null);
              setShowAddressModal(true);
            }}
            className="btn-primary flex items-center space-x-2"
          >
            <FaPlus />
            <span>Add Address</span>
          </button>
        </div>

        {addresses.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <FaMapMarkerAlt className="h-12 w-12 mx-auto mb-3 text-gray-300" />
            <p>No saved addresses yet</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {addresses.map((address) => (
              <div
                key={address.id}
                className={`relative border-2 rounded-lg p-4 ${
                  address.isDefault ? 'border-primary-500 bg-primary-50' : 'border-gray-200'
                }`}
              >
                {address.isDefault && (
                  <div className="absolute top-2 right-2">
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold bg-primary-500 text-white">
                      Default
                    </span>
                  </div>
                )}
                <div className="mb-2">
                  <span className="text-xs font-semibold text-gray-500 uppercase">{address.label}</span>
                </div>
                <p className="font-semibold text-gray-900">{address.fullName}</p>
                <p className="text-sm text-gray-600">{address.phone}</p>
                <p className="text-sm text-gray-600 mt-2">
                  {address.addressLine1}
                  {address.addressLine2 && `, ${address.addressLine2}`}
                </p>
                <p className="text-sm text-gray-600">
                  {address.city}, {address.state} {address.postalCode}
                </p>
                <p className="text-sm text-gray-600">{address.country}</p>

                <div className="flex space-x-2 mt-4">
                  {!address.isDefault && (
                    <button
                      onClick={() => handleSetDefaultAddress(address.id)}
                      className="text-xs text-primary-600 hover:text-primary-800 flex items-center"
                    >
                      <FaRegStar className="mr-1" /> Set as Default
                    </button>
                  )}
                  <button
                    onClick={() => handleDeleteAddress(address.id)}
                    className="text-xs text-red-600 hover:text-red-800 flex items-center ml-auto"
                  >
                    <FaTrash className="mr-1" /> Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Saved Payment Cards Section */}
      <div className="card mt-6">
        <div className="flex justify-between items-center mb-6">
          <h3 className="text-xl font-bold text-gray-900">Saved Payment Cards</h3>
          <button
            onClick={() => {
              setEditingCard(null);
              setShowCardModal(true);
            }}
            className="btn-primary flex items-center space-x-2"
          >
            <FaPlus />
            <span>Add Card</span>
          </button>
        </div>

        {paymentCards.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <FaCreditCard className="h-12 w-12 mx-auto mb-3 text-gray-300" />
            <p>No saved payment cards yet</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {paymentCards.map((card) => (
              <div
                key={card.id}
                className={`relative border-2 rounded-lg p-4 ${
                  card.isDefault ? 'border-primary-500 bg-primary-50' : 'border-gray-200'
                }`}
              >
                {card.isDefault && (
                  <div className="absolute top-2 right-2">
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-semibold bg-primary-500 text-white">
                      Default
                    </span>
                  </div>
                )}
                <div className="mb-2">
                  <span className="text-xs font-semibold text-gray-500 uppercase">{card.label}</span>
                </div>
                <div className="flex items-center space-x-2 mb-2">
                  <FaCreditCard className="text-2xl text-gray-600" />
                  <span className="text-lg font-mono font-semibold">{card.maskedCardNumber}</span>
                </div>
                <p className="text-sm text-gray-600">{card.cardholderName}</p>
                <div className="flex justify-between items-center mt-2">
                  <span className="text-xs text-gray-500">
                    {card.cardType} • Expires {card.expiryMonth}/{card.expiryYear}
                  </span>
                </div>

                <div className="flex space-x-2 mt-4">
                  {!card.isDefault && (
                    <button
                      onClick={() => handleSetDefaultCard(card.id)}
                      className="text-xs text-primary-600 hover:text-primary-800 flex items-center"
                    >
                      <FaRegStar className="mr-1" /> Set as Default
                    </button>
                  )}
                  <button
                    onClick={() => handleDeleteCard(card.id)}
                    className="text-xs text-red-600 hover:text-red-800 flex items-center ml-auto"
                  >
                    <FaTrash className="mr-1" /> Delete
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Additional Sections */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-6">
        {/* Quick Stats */}
        <div className="card">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Quick Stats</h3>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Saved Addresses</span>
              <span className="text-xl font-bold text-primary-600">{addresses.length}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Payment Cards</span>
              <span className="text-xl font-bold text-blue-600">{paymentCards.length}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-600">Total Orders</span>
              <span className="text-xl font-bold text-orange-600">0</span>
            </div>
          </div>
        </div>

        {/* Security */}
        <div className="card">
          <h3 className="text-lg font-bold text-gray-900 mb-4">Security</h3>
          <div className="space-y-4">
            <button className="w-full text-left px-4 py-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition">
              <p className="font-medium text-gray-900">Change Password</p>
              <p className="text-sm text-gray-600">Update your account password</p>
            </button>
            <button className="w-full text-left px-4 py-3 bg-gray-50 hover:bg-gray-100 rounded-lg transition">
              <p className="font-medium text-gray-900">Two-Factor Authentication</p>
              <p className="text-sm text-gray-600">Add an extra layer of security</p>
            </button>
          </div>
        </div>
      </div>

      {/* Address Modal */}
      <AddressModal
        show={showAddressModal}
        onClose={() => setShowAddressModal(false)}
        onSave={fetchAddresses}
        address={editingAddress}
      />

      {/* Card Modal */}
      <CardModal
        show={showCardModal}
        onClose={() => setShowCardModal(false)}
        onSave={fetchPaymentCards}
        card={editingCard}
      />
    </div>
  );
};

// Address Modal Component
const AddressModal: React.FC<{
  show: boolean;
  onClose: () => void;
  onSave: () => void;
  address: Address | null;
}> = ({ show, onClose, onSave, address }) => {
  const [formData, setFormData] = useState({
    label: '',
    fullName: '',
    phone: '',
    addressLine1: '',
    addressLine2: '',
    city: '',
    state: '',
    postalCode: '',
    country: '',
    isDefault: false,
  });

  useEffect(() => {
    if (address) {
      setFormData({
        ...address,
        addressLine2: address.addressLine2 || '',
      });
    } else {
      setFormData({
        label: '',
        fullName: '',
        phone: '',
        addressLine1: '',
        addressLine2: '',
        city: '',
        state: '',
        postalCode: '',
        country: '',
        isDefault: false,
      });
    }
  }, [address]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (address) {
        await axios.put(`/user/addresses/${address.id}`, formData);
        toast.success('Address updated successfully!');
      } else {
        await axios.post('/user/addresses', formData);
        toast.success('Address added successfully!');
      }
      onSave();
      onClose();
    } catch (error: any) {
      console.error('Error saving address:', error);
      const message = error.response?.data?.message || error.response?.data || 'Error saving address';
      toast.error(message);
    }
  };

  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="p-6">
          <h3 className="text-2xl font-bold mb-4">{address ? 'Edit Address' : 'Add New Address'}</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Label *</label>
                <input
                  type="text"
                  value={formData.label}
                  onChange={(e) => setFormData({ ...formData, label: e.target.value })}
                  className="input-field"
                  placeholder="e.g., Home, Work"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Full Name *</label>
                <input
                  type="text"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  className="input-field"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Phone *</label>
              <input
                type="tel"
                value={formData.phone}
                onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                className="input-field"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Address Line 1 *</label>
              <input
                type="text"
                value={formData.addressLine1}
                onChange={(e) => setFormData({ ...formData, addressLine1: e.target.value })}
                className="input-field"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Address Line 2</label>
              <input
                type="text"
                value={formData.addressLine2}
                onChange={(e) => setFormData({ ...formData, addressLine2: e.target.value })}
                className="input-field"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">City *</label>
                <input
                  type="text"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  className="input-field"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">State *</label>
                <input
                  type="text"
                  value={formData.state}
                  onChange={(e) => setFormData({ ...formData, state: e.target.value })}
                  className="input-field"
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Postal Code *</label>
                <input
                  type="text"
                  value={formData.postalCode}
                  onChange={(e) => setFormData({ ...formData, postalCode: e.target.value })}
                  className="input-field"
                  required
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Country *</label>
              <input
                type="text"
                value={formData.country}
                onChange={(e) => setFormData({ ...formData, country: e.target.value })}
                className="input-field"
                required
              />
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="isDefault"
                checked={formData.isDefault}
                onChange={(e) => setFormData({ ...formData, isDefault: e.target.checked })}
                className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
              />
              <label htmlFor="isDefault" className="ml-2 block text-sm text-gray-900">
                Set as default address
              </label>
            </div>

            <div className="flex space-x-4 pt-4">
              <button type="submit" className="btn-primary flex-1">
                {address ? 'Update Address' : 'Add Address'}
              </button>
              <button type="button" onClick={onClose} className="btn-secondary flex-1">
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

// Card Modal Component
const CardModal: React.FC<{
  show: boolean;
  onClose: () => void;
  onSave: () => void;
  card: PaymentCard | null;
}> = ({ show, onClose, onSave, card }) => {
  const [formData, setFormData] = useState({
    label: '',
    cardholderName: '',
    cardNumber: '',
    cardType: 'VISA',
    expiryMonth: '',
    expiryYear: '',
    isDefault: false,
  });

  useEffect(() => {
    if (card) {
      setFormData({
        label: card.label,
        cardholderName: card.cardholderName,
        cardNumber: '',
        cardType: card.cardType,
        expiryMonth: card.expiryMonth,
        expiryYear: card.expiryYear,
        isDefault: card.isDefault,
      });
    } else {
      setFormData({
        label: '',
        cardholderName: '',
        cardNumber: '',
        cardType: 'VISA',
        expiryMonth: '',
        expiryYear: '',
        isDefault: false,
      });
    }
  }, [card]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validate card number for new cards
    if (!card && formData.cardNumber.length < 13) {
      toast.error('Card number must be at least 13 digits');
      return;
    }
    
    // Validate expiry month
    const month = parseInt(formData.expiryMonth);
    if (isNaN(month) || month < 1 || month > 12) {
      toast.error('Invalid expiry month (01-12)');
      return;
    }
    
    // Format month with leading zero
    const formattedMonth = month < 10 ? `0${month}` : `${month}`;
    
    // Validate expiry year
    const year = parseInt(formData.expiryYear);
    const currentYear = new Date().getFullYear();
    if (isNaN(year) || year < currentYear || year > currentYear + 20) {
      toast.error(`Invalid expiry year (${currentYear}-${currentYear + 20})`);
      return;
    }
    
    const submitData = {
      ...formData,
      expiryMonth: formattedMonth,
      expiryYear: formData.expiryYear,
    };
    
    try {
      if (card) {
        await axios.put(`/user/cards/${card.id}`, submitData);
        toast.success('Card updated successfully!');
      } else {
        await axios.post('/user/cards', submitData);
        toast.success('Card added successfully!');
      }
      onSave();
      onClose();
    } catch (error: any) {
      console.error('Error saving card:', error);
      const message = error.response?.data?.message || error.response?.data || 'Error saving card';
      toast.error(message);
    }
  };

  if (!show) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-lg w-full">
        <div className="p-6">
          <h3 className="text-2xl font-bold mb-4">{card ? 'Edit Card' : 'Add New Card'}</h3>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Label *</label>
              <input
                type="text"
                value={formData.label}
                onChange={(e) => setFormData({ ...formData, label: e.target.value })}
                className="input-field"
                placeholder="e.g., Personal, Business"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Cardholder Name *</label>
              <input
                type="text"
                value={formData.cardholderName}
                onChange={(e) => setFormData({ ...formData, cardholderName: e.target.value })}
                className="input-field"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Card Number * {card && '(leave empty to keep existing)'}
              </label>
              <input
                type="text"
                value={formData.cardNumber}
                onChange={(e) => setFormData({ ...formData, cardNumber: e.target.value.replace(/\D/g, '') })}
                className="input-field"
                placeholder="1234567890123456"
                maxLength={19}
                required={!card}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Card Type *</label>
              <select
                value={formData.cardType}
                onChange={(e) => setFormData({ ...formData, cardType: e.target.value })}
                className="input-field"
                required
              >
                <option value="VISA">Visa</option>
                <option value="MASTERCARD">Mastercard</option>
                <option value="AMEX">American Express</option>
                <option value="DISCOVER">Discover</option>
              </select>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Expiry Month *</label>
                <input
                  type="text"
                  value={formData.expiryMonth}
                  onChange={(e) => setFormData({ ...formData, expiryMonth: e.target.value })}
                  className="input-field"
                  placeholder="MM"
                  maxLength={2}
                  required
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Expiry Year *</label>
                <input
                  type="text"
                  value={formData.expiryYear}
                  onChange={(e) => setFormData({ ...formData, expiryYear: e.target.value })}
                  className="input-field"
                  placeholder="YYYY"
                  maxLength={4}
                  required
                />
              </div>
            </div>

            <div className="flex items-center">
              <input
                type="checkbox"
                id="isDefaultCard"
                checked={formData.isDefault}
                onChange={(e) => setFormData({ ...formData, isDefault: e.target.checked })}
                className="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded"
              />
              <label htmlFor="isDefaultCard" className="ml-2 block text-sm text-gray-900">
                Set as default card
              </label>
            </div>

            <div className="flex space-x-4 pt-4">
              <button type="submit" className="btn-primary flex-1">
                {card ? 'Update Card' : 'Add Card'}
              </button>
              <button type="button" onClick={onClose} className="btn-secondary flex-1">
                Cancel
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default Profile;
