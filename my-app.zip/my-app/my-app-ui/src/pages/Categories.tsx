import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { categoryService } from '../services/category.service';
import { productService } from '../services/product.service';
import type { Category, Product, PageResponse } from '../types';
import Loading from '../components/common/Loading';
import ProductCard from '../components/product/ProductCard';
import { FaLayerGroup, FaTh } from 'react-icons/fa';
import { toast } from 'react-toastify';

const Categories: React.FC = () => {
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();
  const categoryIdParam = searchParams.get('categoryId');

  const [categories, setCategories] = useState<Category[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<Category | null>(null);
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [productsLoading, setProductsLoading] = useState(false);
  const [pagination, setPagination] = useState({
    page: 0,
    size: 12,
    totalPages: 0,
  });

  useEffect(() => {
    fetchCategories();
  }, []);

  useEffect(() => {
    if (categoryIdParam) {
      const categoryId = Number(categoryIdParam);
      fetchCategoryById(categoryId);
      fetchProductsByCategory(categoryId);
    } else {
      setSelectedCategory(null);
      setProducts([]);
    }
  }, [categoryIdParam, pagination.page]);

  const fetchCategories = async () => {
    setLoading(true);
    try {
      const data = await categoryService.getAllCategories(true);
      setCategories(data);
    } catch (error) {
      toast.error('Failed to load categories');
      console.error('Failed to fetch categories:', error);
    } finally {
      setLoading(false);
    }
  };

  const fetchCategoryById = async (id: number) => {
    try {
      const data = await categoryService.getCategoryById(id);
      setSelectedCategory(data);
    } catch (error) {
      console.error('Failed to fetch category:', error);
    }
  };

  const fetchProductsByCategory = async (categoryId: number) => {
    setProductsLoading(true);
    try {
      const response: PageResponse<Product> = await productService.getProducts({
        page: pagination.page,
        size: pagination.size,
        category: categoryId,
      });
      setProducts(response.content);
      setPagination((prev) => ({ ...prev, totalPages: response.totalPages }));
    } catch (error) {
      toast.error('Failed to load products');
      console.error('Failed to fetch products:', error);
    } finally {
      setProductsLoading(false);
    }
  };

  const handleCategoryClick = (categoryId: number) => {
    setSearchParams({ categoryId: categoryId.toString() });
    setPagination((prev) => ({ ...prev, page: 0 }));
  };

  const handleViewAll = () => {
    navigate('/');
  };

  if (loading) {
    return <Loading message="Loading categories..." />;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
      <div className="mb-6 sm:mb-8">
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">Shop by Category</h1>
        <p className="text-sm sm:text-base text-gray-600">Browse our wide selection of products</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* Categories Sidebar */}
        <div className="lg:col-span-1">
          <div className="card lg:sticky lg:top-20">
            <div className="flex items-center space-x-2 mb-4">
              <FaLayerGroup className="text-primary-600" />
              <h2 className="text-lg sm:text-xl font-bold text-gray-900">Categories</h2>
            </div>

            <div className="space-y-2">
              <button
                onClick={handleViewAll}
                className={`w-full text-left px-3 sm:px-4 py-2.5 sm:py-3 rounded-lg transition text-sm sm:text-base touch-manipulation ${
                  !selectedCategory
                    ? 'bg-primary-100 text-primary-700 font-semibold'
                    : 'hover:bg-gray-100 text-gray-700'
                }`}
              >
                All Products
              </button>

              {categories.map((category) => (
                <button
                  key={category.id}
                  onClick={() => handleCategoryClick(category.id)}
                  className={`w-full text-left px-3 sm:px-4 py-2.5 sm:py-3 rounded-lg transition flex items-center justify-between text-sm sm:text-base touch-manipulation ${
                    selectedCategory?.id === category.id
                      ? 'bg-primary-100 text-primary-700 font-semibold'
                      : 'hover:bg-gray-100 text-gray-700'
                  }`}
                >
                  <span>{category.name}</span>
                  {category.productCount !== undefined && (
                    <span className={`text-xs px-1.5 sm:px-2 py-0.5 sm:py-1 rounded-full ${
                      selectedCategory?.id === category.id
                        ? 'bg-primary-200 text-primary-800'
                        : 'bg-gray-200 text-gray-600'
                    }`}>
                      {category.productCount}
                    </span>
                  )}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Products Grid */}
        <div className="lg:col-span-3">
          {selectedCategory ? (
            <>
              <div className="mb-6">
                <h2 className="text-2xl font-bold text-gray-900">{selectedCategory.name}</h2>
                {selectedCategory.description && (
                  <p className="text-gray-600 mt-2">{selectedCategory.description}</p>
                )}
                <p className="text-sm text-gray-500 mt-2">
                  {products.length} {products.length === 1 ? 'product' : 'products'} found
                </p>
              </div>

              {productsLoading ? (
                <Loading message="Loading products..." />
              ) : products.length > 0 ? (
                <>
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {products.map((product) => (
                      <ProductCard key={product.id} product={product} />
                    ))}
                  </div>

                  {/* Pagination */}
                  {pagination.totalPages > 1 && (
                    <div className="flex flex-col sm:flex-row justify-center items-center gap-3 sm:gap-2 mt-8">
                      <button
                        onClick={() =>
                          setPagination((prev) => ({ ...prev, page: prev.page - 1 }))
                        }
                        disabled={pagination.page === 0}
                        className="btn-secondary disabled:opacity-50 w-full sm:w-auto min-w-[100px] touch-manipulation"
                      >
                        Previous
                      </button>
                      <span className="text-gray-600 text-sm sm:text-base font-medium order-first sm:order-none">
                        Page {pagination.page + 1} of {pagination.totalPages}
                      </span>
                      <button
                        onClick={() =>
                          setPagination((prev) => ({ ...prev, page: prev.page + 1 }))
                        }
                        disabled={pagination.page >= pagination.totalPages - 1}
                        className="btn-secondary disabled:opacity-50 w-full sm:w-auto min-w-[100px] touch-manipulation"
                      >
                        Next
                      </button>
                    </div>
                  )}
                </>
              ) : (
                <div className="text-center py-16">
                  <FaTh className="mx-auto h-16 w-16 text-gray-400 mb-4" />
                  <h3 className="text-xl font-semibold text-gray-900 mb-2">
                    No products found
                  </h3>
                  <p className="text-gray-600 mb-6">
                    This category doesn't have any products yet
                  </p>
                  <button onClick={handleViewAll} className="btn-primary">
                    View All Products
                  </button>
                </div>
              )}
            </>
          ) : (
            <div className="text-center py-16">
              <FaLayerGroup className="mx-auto h-16 w-16 text-primary-600 mb-4" />
              <h2 className="text-2xl font-bold text-gray-900 mb-2">
                Browse Our Categories
              </h2>
              <p className="text-gray-600 mb-8">
                Select a category from the sidebar to see products
              </p>

              {/* Category Cards Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4 sm:gap-6 mt-8">
                {categories.map((category) => (
                  <div
                    key={category.id}
                    onClick={() => handleCategoryClick(category.id)}
                    className="card hover:shadow-xl transition-shadow cursor-pointer touch-manipulation"
                  >
                    <div className="relative h-48 bg-gray-200 rounded-t-lg overflow-hidden">
                      {category.imageUrl ? (
                        <img
                          src={category.imageUrl}
                          alt={category.name}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <div className="h-full bg-gradient-to-br from-primary-400 to-primary-600 flex items-center justify-center">
                          <FaLayerGroup className="text-white text-4xl" />
                        </div>
                      )}
                      <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent flex items-end">
                        <h3 className="text-white text-xl font-bold p-4 w-full">
                          {category.name}
                        </h3>
                      </div>
                    </div>
                    <div className="p-4">
                      {category.description && (
                        <p className="text-sm text-gray-600 line-clamp-2">
                          {category.description}
                        </p>
                      )}
                      {category.productCount !== undefined && (
                        <p className="text-xs text-gray-500 mt-2">
                          {category.productCount} {category.productCount === 1 ? 'product' : 'products'}
                        </p>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Categories;
