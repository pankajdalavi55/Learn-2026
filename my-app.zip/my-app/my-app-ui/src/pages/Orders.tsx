import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { orderService } from '../services/order.service';
import type { Order } from '../types';
import Loading from '../components/common/Loading';
import { FaBox, FaEye } from 'react-icons/fa';
import { toast } from 'react-toastify';

const Orders: React.FC = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [orders, setOrders] = useState<Order[]>([]);
  const [loading, setLoading] = useState(true);
  const [pagination, setPagination] = useState({
    page: 0,
    size: 10,
    totalPages: 0,
  });

  useEffect(() => {
    fetchOrders();
  }, [pagination.page]);

  const fetchOrders = async () => {
    if (!user) return;

    setLoading(true);
    try {
      const response = await orderService.getUserOrders(
        user.userId,
        pagination.page,
        pagination.size
      );
      setOrders(response.content);
      setPagination((prev) => ({ ...prev, totalPages: response.totalPages }));
    } catch (error: any) {
      toast.error('Failed to load orders');
      console.error('Failed to fetch orders:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      PENDING: 'bg-yellow-100 text-yellow-800',
      PROCESSING: 'bg-blue-100 text-blue-800',
      SHIPPED: 'bg-purple-100 text-purple-800',
      DELIVERED: 'bg-green-100 text-green-800',
      CANCELLED: 'bg-red-100 text-red-800',
    };
    return colors[status] || 'bg-gray-100 text-gray-800';
  };

  if (loading) {
    return <Loading message="Loading orders..." />;
  }

  if (orders.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <FaBox className="mx-auto h-24 w-24 text-gray-400 mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-4">No orders yet</h2>
          <p className="text-gray-600 mb-8">Start shopping to place your first order</p>
          <button onClick={() => navigate('/')} className="btn-primary">
            Browse Products
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <h1 className="text-3xl font-bold text-gray-900 mb-8">My Orders</h1>

      <div className="space-y-4">
        {orders.map((order) => (
          <div key={order.id} className="card hover:shadow-lg transition-shadow">
            <div className="flex flex-col sm:flex-row justify-between items-start gap-3 sm:gap-0 mb-4">
              <div>
                <h3 className="text-lg sm:text-xl font-bold text-gray-900">
                  Order #{order.orderNumber}
                </h3>
                <p className="text-xs sm:text-sm text-gray-600">
                  Placed on {new Date(order.createdAt).toLocaleDateString()}
                </p>
              </div>
              <span
                className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-full text-xs sm:text-sm font-semibold ${getStatusColor(
                  order.status
                )} whitespace-nowrap`}
              >
                {order.status}
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 sm:gap-4 mb-4">
              <div>
                <p className="text-sm text-gray-600">Total Items</p>
                <p className="font-semibold">{order.totalItems}</p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Total Price</p>
                <p className="font-semibold text-primary-600 text-lg">
                  ${order.totalAmount.toFixed(2)}
                </p>
              </div>
              <div>
                <p className="text-sm text-gray-600">Payment Method</p>
                <p className="font-semibold">{order.paymentMethod.replace('_', ' ')}</p>
              </div>
            </div>

            <div className="mb-4">
              <p className="text-xs sm:text-sm text-gray-600 mb-1">Shipping Address</p>
              <p className="text-sm sm:text-base text-gray-900 break-words">
                {order.shippingAddress}, {order.shippingCity}, {order.shippingState}{' '}
                {order.shippingPostalCode}, {order.shippingCountry}
              </p>
            </div>

            <div className="flex justify-end">
              <button
                onClick={() => navigate(`/orders/${order.id}`)}
                className="btn-primary flex items-center space-x-2 w-full sm:w-auto justify-center touch-manipulation"
              >
                <FaEye />
                <span>View Details</span>
              </button>
            </div>
          </div>
        ))}
      </div>

      {/* Pagination */}
      {pagination.totalPages > 1 && (
        <div className="flex flex-col sm:flex-row justify-center items-center gap-3 sm:gap-2 mt-8">
          <button
            onClick={() => setPagination((prev) => ({ ...prev, page: prev.page - 1 }))}
            disabled={pagination.page === 0}
            className="btn-secondary disabled:opacity-50 w-full sm:w-auto min-w-[100px] touch-manipulation"
          >
            Previous
          </button>
          <span className="text-gray-600 text-sm sm:text-base font-medium order-first sm:order-none">
            Page {pagination.page + 1} of {pagination.totalPages}
          </span>
          <button
            onClick={() => setPagination((prev) => ({ ...prev, page: prev.page + 1 }))}
            disabled={pagination.page >= pagination.totalPages - 1}
            className="btn-secondary disabled:opacity-50 w-full sm:w-auto min-w-[100px] touch-manipulation"
          >
            Next
          </button>
        </div>
      )}
    </div>
  );
};

export default Orders;
