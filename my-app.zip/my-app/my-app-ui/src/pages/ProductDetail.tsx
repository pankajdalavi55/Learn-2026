import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { productService } from '../services/product.service';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import type { Product } from '../types';
import Loading from '../components/common/Loading';
import { FaShoppingCart, FaArrowLeft } from 'react-icons/fa';
import { toast } from 'react-toastify';

const ProductDetail: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { isAuthenticated } = useAuth();
  const [product, setProduct] = useState<Product | null>(null);
  const [loading, setLoading] = useState(true);
  const [quantity, setQuantity] = useState(1);

  useEffect(() => {
    fetchProduct();
  }, [id]);

  const fetchProduct = async () => {
    if (!id) return;

    try {
      const data = await productService.getProductById(Number(id));
      setProduct(data);
    } catch (error: any) {
      toast.error('Failed to load product');
      console.error('Failed to fetch product:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleAddToCart = async () => {
    if (!product || !isAuthenticated) return;

    try {
      await addToCart({ productId: product.id, quantity });
      setQuantity(1);
    } catch (error) {
      console.error('Failed to add to cart:', error);
    }
  };

  if (loading) {
    return <Loading message="Loading product details..." />;
  }

  if (!product) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Product not found</h2>
          <button onClick={() => navigate('/')} className="btn-primary">
            Back to Products
          </button>
        </div>
      </div>
    );
  }

  const isOutOfStock = product.stockQuantity === 0;

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <button
        onClick={() => navigate(-1)}
        className="flex items-center space-x-2 text-gray-600 hover:text-gray-900 mb-6"
      >
        <FaArrowLeft />
        <span>Back</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 lg:gap-8">
        {/* Product Image */}
        <div className="bg-gray-200 rounded-lg overflow-hidden aspect-square w-full max-w-2xl mx-auto lg:max-w-none">
          {product.imageUrl ? (
            <img
              src={product.imageUrl}
              alt={product.name}
              className="w-full h-full object-cover"
            />
          ) : (
            <div className="flex items-center justify-center h-full text-gray-400 text-xl">
              No Image Available
            </div>
          )}
        </div>

        {/* Product Details */}
        <div className="flex flex-col">
          <div className="mb-4">
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-bold text-gray-900 mb-2 leading-tight">{product.name}</h1>
            <p className="text-lg sm:text-xl text-gray-600">{product.brand}</p>
          </div>

          <div className="mb-6">
            <p className="text-3xl sm:text-4xl font-bold text-primary-600 mb-2">
              ${product.price.toFixed(2)}
            </p>
            <p className={`text-sm ${isOutOfStock ? 'text-red-600' : 'text-green-600'}`}>
              {isOutOfStock ? 'Out of Stock' : `${product.stockQuantity} available`}
            </p>
          </div>

          <div className="mb-6">
            <h2 className="text-lg font-semibold mb-2">Description</h2>
            <p className="text-gray-600 leading-relaxed">{product.description}</p>
          </div>

          <div className="mb-6">
            <h2 className="text-lg font-semibold mb-2">Category</h2>
            <span className="inline-block bg-primary-100 text-primary-800 px-4 py-2 rounded-lg">
              {product.category?.name || product.categoryName || 'N/A'}
            </span>
          </div>

          {isAuthenticated && !isOutOfStock && (
            <div className="mt-auto">
              <div className="flex flex-col sm:flex-row sm:items-center gap-2 sm:gap-4 mb-4">
                <label htmlFor="quantity" className="font-medium text-gray-700">
                  Quantity:
                </label>
                <select
                  id="quantity"
                  value={quantity}
                  onChange={(e) => setQuantity(Number(e.target.value))}
                  className="input-field w-full sm:w-32"
                >
                  {Array.from({ length: Math.min(10, product.stockQuantity) }, (_, i) => i + 1).map(
                    (num) => (
                      <option key={num} value={num}>
                        {num}
                      </option>
                    )
                  )}
                </select>
              </div>

              <button
                onClick={handleAddToCart}
                className="btn-primary w-full py-4 text-base sm:text-lg flex items-center justify-center space-x-3 touch-manipulation"
              >
                <FaShoppingCart className="text-xl" />
                <span>Add to Cart</span>
              </button>
            </div>
          )}

          {!isAuthenticated && (
            <div className="mt-auto bg-gray-100 p-4 rounded-lg">
              <p className="text-gray-700 text-center">
                Please{' '}
                <button
                  onClick={() => navigate('/login')}
                  className="text-primary-600 font-semibold hover:underline"
                >
                  login
                </button>{' '}
                to purchase this product
              </p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;
