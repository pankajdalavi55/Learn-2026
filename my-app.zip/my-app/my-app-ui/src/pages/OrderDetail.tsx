import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { orderService } from '../services/order.service';
import type { Order } from '../types';
import Loading from '../components/common/Loading';
import { FaArrowLeft, FaBox, FaCheckCircle } from 'react-icons/fa';
import { toast } from 'react-toastify';
import { getOrderStatusColor } from '../utils/helpers';

const OrderDetail: React.FC = () => {
  const { orderId } = useParams<{ orderId: string }>();
  const navigate = useNavigate();
  const { user } = useAuth();
  const [order, setOrder] = useState<Order | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchOrderDetail();
  }, [orderId]);

  const fetchOrderDetail = async () => {
    if (!user || !orderId) return;

    setLoading(true);
    try {
      const orderData = await orderService.getOrderById(Number(orderId), user.userId);
      setOrder(orderData);
    } catch (error: any) {
      toast.error('Failed to load order details');
      console.error('Failed to fetch order:', error);
      navigate('/orders');
    } finally {
      setLoading(false);
    }
  };

  if (loading) {
    return <Loading message="Loading order details..." />;
  }

  if (!order) {
    return null;
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
      <button
        onClick={() => navigate('/orders')}
        className="btn-secondary flex items-center space-x-2 mb-6 touch-manipulation"
      >
        <FaArrowLeft />
        <span>Back to Orders</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Order Details */}
        <div className="lg:col-span-2 space-y-6">
          {/* Order Header */}
          <div className="card">
            <div className="flex flex-col sm:flex-row justify-between items-start gap-3 sm:gap-0 mb-4">
              <div>
                <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">
                  Order #{order.orderNumber}
                </h1>
                <p className="text-xs sm:text-sm text-gray-600">
                  Placed on {new Date(order.createdAt).toLocaleString()}
                </p>
              </div>
              <span
                className={`px-3 sm:px-4 py-1.5 sm:py-2 rounded-full text-xs sm:text-sm font-semibold ${getOrderStatusColor(
                  order.status
                )} whitespace-nowrap`}
              >
                {order.status}
              </span>
            </div>
          </div>

          {/* Order Items */}
          <div className="card">
            <h2 className="text-lg sm:text-xl font-bold text-gray-900 mb-4">Order Items</h2>
            <div className="space-y-3 sm:space-y-4">
              {order.items.map((item) => (
                <div
                  key={item.id}
                  className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 p-3 sm:p-4 bg-gray-50 rounded-lg"
                >
                  <div className="flex-grow">
                    <h3 className="text-sm sm:text-base font-semibold text-gray-900">{item.productName}</h3>
                    <p className="text-xs sm:text-sm text-gray-600">
                      ${item.price.toFixed(2)} × {item.quantity}
                    </p>
                  </div>
                  <div className="text-right sm:text-left">
                    <p className="text-base sm:text-lg font-bold text-gray-900">${item.subtotal.toFixed(2)}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Shipping Information */}
          <div className="card">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Shipping Information</h2>
            <div className="space-y-2">
              <p className="text-gray-900">{order.shippingAddress}</p>
              <p className="text-gray-900">
                {order.shippingCity}, {order.shippingState} {order.shippingPostalCode}
              </p>
              <p className="text-gray-900">{order.shippingCountry}</p>
              {order.phoneNumber && (
                <p className="text-gray-600 mt-2">Phone: {order.phoneNumber}</p>
              )}
            </div>
          </div>

          {/* Notes */}
          {order.notes && (
            <div className="card">
              <h2 className="text-xl font-bold text-gray-900 mb-4">Order Notes</h2>
              <p className="text-gray-700">{order.notes}</p>
            </div>
          )}
        </div>

        {/* Order Summary Sidebar */}
        <div className="lg:col-span-1">
          <div className="card lg:sticky lg:top-20">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Order Summary</h2>

            <div className="space-y-3 mb-6">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal ({order.totalItems} items)</span>
                <span>${order.totalAmount.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Shipping</span>
                <span>Free</span>
              </div>
              <div className="border-t pt-3 flex justify-between text-xl font-bold text-gray-900">
                <span>Total</span>
                <span>${order.totalAmount.toFixed(2)}</span>
              </div>
            </div>

            <div className="border-t pt-4 space-y-2">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Payment Method</span>
                <span className="font-semibold">{order.paymentMethod.replace('_', ' ')}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Payment Status</span>
                <span className="font-semibold">{order.paymentStatus || 'PENDING'}</span>
              </div>
            </div>

            {order.status === 'DELIVERED' && order.deliveredAt && (
              <div className="mt-6 p-4 bg-green-50 rounded-lg flex items-start space-x-3">
                <FaCheckCircle className="text-green-600 text-xl mt-1" />
                <div>
                  <p className="font-semibold text-green-900">Order Delivered</p>
                  <p className="text-sm text-green-700">
                    {new Date(order.deliveredAt).toLocaleDateString()}
                  </p>
                </div>
              </div>
            )}

            {order.status === 'PENDING' && (
              <button className="btn-danger w-full mt-6 touch-manipulation">Cancel Order</button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default OrderDetail;
