import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { orderService } from '../services/order.service';
import type { OrderRequest } from '../types';
import { toast } from 'react-toastify';
import { FaCreditCard, FaMoneyBillWave, FaPlus, FaStar } from 'react-icons/fa';
import axios from '../services/axios';

interface SavedAddress {
  id: number;
  label: string;
  fullName: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  isDefault: boolean;
}

interface SavedCard {
  id: number;
  label: string;
  cardholderName: string;
  maskedCardNumber: string;
  cardLastFour: string;
  cardType: string;
  expiryMonth: string;
  expiryYear: string;
  isDefault: boolean;
}

const Checkout: React.FC = () => {
  const navigate = useNavigate();
  const { cart, clearCart } = useCart();
  const { user } = useAuth();
  const [isSubmitting, setIsSubmitting] = useState(false);

  const [savedAddresses, setSavedAddresses] = useState<SavedAddress[]>([]);
  const [savedCards, setSavedCards] = useState<SavedCard[]>([]);
  const [selectedAddressId, setSelectedAddressId] = useState<number | null>(null);
  const [selectedCardId, setSelectedCardId] = useState<number | null>(null);
  const [useNewAddress, setUseNewAddress] = useState(false);
  const [useNewCard, setUseNewCard] = useState(false);

  const [formData, setFormData] = useState<OrderRequest>({
    shippingAddress: '',
    shippingCity: '',
    shippingState: '',
    shippingPostalCode: '',
    shippingCountry: 'USA',
    paymentMethod: 'CREDIT_CARD',
  });

  useEffect(() => {
    if (user) {
      fetchSavedAddresses();
      fetchSavedCards();
    }
  }, [user]);

  const fetchSavedAddresses = async () => {
    try {
      const response = await axios.get('/user/addresses');
      setSavedAddresses(response.data);
      // Auto-select default address
      const defaultAddress = response.data.find((addr: SavedAddress) => addr.isDefault);
      if (defaultAddress) {
        setSelectedAddressId(defaultAddress.id);
        fillAddressForm(defaultAddress);
      } else if (response.data.length > 0) {
        setUseNewAddress(true);
      } else {
        setUseNewAddress(true);
      }
    } catch (error) {
      console.error('Error fetching addresses:', error);
      setUseNewAddress(true);
    }
  };

  const fetchSavedCards = async () => {
    try {
      const response = await axios.get('/user/cards');
      setSavedCards(response.data);
      // Auto-select default card
      const defaultCard = response.data.find((card: SavedCard) => card.isDefault);
      if (defaultCard) {
        setSelectedCardId(defaultCard.id);
      } else if (response.data.length === 0) {
        setUseNewCard(true);
      }
    } catch (error) {
      console.error('Error fetching cards:', error);
      setUseNewCard(true);
    }
  };

  const fillAddressForm = (address: SavedAddress) => {
    setFormData({
      ...formData,
      shippingAddress: `${address.addressLine1}${address.addressLine2 ? ', ' + address.addressLine2 : ''}`,
      shippingCity: address.city,
      shippingState: address.state,
      shippingPostalCode: address.postalCode,
      shippingCountry: address.country,
    });
  };

  const handleAddressSelect = (address: SavedAddress) => {
    setSelectedAddressId(address.id);
    setUseNewAddress(false);
    fillAddressForm(address);
  };

  const handleCardSelect = (cardId: number) => {
    setSelectedCardId(cardId);
    setUseNewCard(false);
    setFormData({ ...formData, paymentMethod: 'CREDIT_CARD' });
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !cart) return;

    setIsSubmitting(true);
    try {
      // Backend only needs shipping info and payment method (not card details)
      const order = await orderService.placeOrder(user.userId, formData);
      await clearCart();
      toast.success(`Order placed successfully! Order #${order.orderNumber}`);
      navigate('/orders');
    } catch (error: any) {
      const message = error.response?.data?.message || 'Failed to place order';
      toast.error(message);
      console.error('Failed to place order:', error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!cart || cart.items.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Your cart is empty</h2>
          <button onClick={() => navigate('/')} className="btn-primary">
            Browse Products
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8">
      <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-6 sm:mb-8">Checkout</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Checkout Form */}
        <div className="lg:col-span-2">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Shipping Information */}
            <div className="card">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-900">Shipping Information</h2>
                {savedAddresses.length > 0 && !useNewAddress && (
                  <button
                    type="button"
                    onClick={() => setUseNewAddress(true)}
                    className="text-sm text-primary-600 hover:text-primary-800 flex items-center"
                  >
                    <FaPlus className="mr-1" /> New Address
                  </button>
                )}
              </div>

              {/* Saved Addresses */}
              {savedAddresses.length > 0 && !useNewAddress && (
                <div className="space-y-3 mb-4">
                  {savedAddresses.map((address) => (
                    <label
                      key={address.id}
                      className={`block p-4 border-2 rounded-lg cursor-pointer transition ${
                        selectedAddressId === address.id
                          ? 'border-primary-500 bg-primary-50'
                          : 'border-gray-300 hover:border-primary-300'
                      }`}
                    >
                      <div className="flex items-start">
                        <input
                          type="radio"
                          name="selectedAddress"
                          checked={selectedAddressId === address.id}
                          onChange={() => handleAddressSelect(address)}
                          className="mt-1 w-4 h-4 text-primary-600"
                        />
                        <div className="ml-3 flex-1">
                          <div className="flex items-center justify-between">
                            <div>
                              <span className="text-xs font-semibold text-gray-500 uppercase">{address.label}</span>
                              {address.isDefault && (
                                <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-primary-100 text-primary-800">
                                  <FaStar className="mr-1" /> Default
                                </span>
                              )}
                            </div>
                          </div>
                          <p className="font-semibold text-gray-900 mt-1">{address.fullName}</p>
                          <p className="text-sm text-gray-600">{address.phone}</p>
                          <p className="text-sm text-gray-600 mt-1">
                            {address.addressLine1}
                            {address.addressLine2 && `, ${address.addressLine2}`}
                          </p>
                          <p className="text-sm text-gray-600">
                            {address.city}, {address.state} {address.postalCode}
                          </p>
                          <p className="text-sm text-gray-600">{address.country}</p>
                        </div>
                      </div>
                    </label>
                  ))}
                </div>
              )}

              {/* New Address Form */}
              {(useNewAddress || savedAddresses.length === 0) && (
                <div>
                  {savedAddresses.length > 0 && (
                    <button
                      type="button"
                      onClick={() => {
                        setUseNewAddress(false);
                        if (savedAddresses[0]) {
                          handleAddressSelect(savedAddresses[0]);
                        }
                      }}
                      className="text-sm text-primary-600 hover:text-primary-800 mb-3"
                    >
                      ← Use saved address
                    </button>
                  )}
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="md:col-span-2">
                      <label htmlFor="shippingAddress" className="block text-sm font-medium text-gray-700 mb-1">
                        Street Address *
                      </label>
                      <input
                        type="text"
                        id="shippingAddress"
                        name="shippingAddress"
                        required
                        value={formData.shippingAddress}
                        onChange={handleChange}
                        className="input-field"
                        placeholder="123 Main St, Apt 4B"
                      />
                    </div>

                    <div>
                      <label htmlFor="shippingCity" className="block text-sm font-medium text-gray-700 mb-1">
                        City *
                      </label>
                      <input
                        type="text"
                        id="shippingCity"
                        name="shippingCity"
                        required
                        value={formData.shippingCity}
                        onChange={handleChange}
                        className="input-field"
                        placeholder="New York"
                      />
                    </div>

                    <div>
                      <label htmlFor="shippingState" className="block text-sm font-medium text-gray-700 mb-1">
                        State/Province *
                      </label>
                      <input
                        type="text"
                        id="shippingState"
                        name="shippingState"
                        required
                        value={formData.shippingState}
                        onChange={handleChange}
                        className="input-field"
                        placeholder="NY"
                      />
                    </div>

                    <div>
                      <label htmlFor="shippingPostalCode" className="block text-sm font-medium text-gray-700 mb-1">
                        ZIP/Postal Code *
                      </label>
                      <input
                        type="text"
                        id="shippingPostalCode"
                        name="shippingPostalCode"
                        required
                        value={formData.shippingPostalCode}
                        onChange={handleChange}
                        className="input-field"
                        placeholder="10001"
                      />
                    </div>

                    <div>
                      <label htmlFor="shippingCountry" className="block text-sm font-medium text-gray-700 mb-1">
                        Country *
                      </label>
                      <input
                        type="text"
                        id="shippingCountry"
                        name="shippingCountry"
                        required
                        value={formData.shippingCountry}
                        onChange={handleChange}
                        className="input-field"
                      />
                    </div>
                  </div>
                </div>
              )}
            </div>

            {/* Payment Method */}
            <div className="card">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold text-gray-900">Payment Method</h2>
                {savedCards.length > 0 && !useNewCard && formData.paymentMethod === 'CREDIT_CARD' && (
                  <button
                    type="button"
                    onClick={() => setUseNewCard(true)}
                    className="text-sm text-primary-600 hover:text-primary-800 flex items-center"
                  >
                    <FaPlus className="mr-1" /> New Card
                  </button>
                )}
              </div>

              {/* Payment Method Selection */}
              <div className="space-y-3 mb-4">
                <label className={`flex items-center space-x-3 p-4 border-2 rounded-lg cursor-pointer transition ${
                  formData.paymentMethod === 'CREDIT_CARD' ? 'border-primary-500 bg-primary-50' : 'border-gray-300 hover:border-primary-300'
                }`}>
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="CREDIT_CARD"
                    checked={formData.paymentMethod === 'CREDIT_CARD'}
                    onChange={(e) => {
                      handleChange(e);
                      setUseNewCard(savedCards.length === 0);
                    }}
                    className="w-4 h-4 text-primary-600"
                  />
                  <FaCreditCard className="text-2xl text-gray-600" />
                  <span className="font-medium">Credit Card</span>
                </label>

                <label className={`flex items-center space-x-3 p-4 border-2 rounded-lg cursor-pointer transition ${
                  formData.paymentMethod === 'CASH_ON_DELIVERY' ? 'border-primary-500 bg-primary-50' : 'border-gray-300 hover:border-primary-300'
                }`}>
                  <input
                    type="radio"
                    name="paymentMethod"
                    value="CASH_ON_DELIVERY"
                    checked={formData.paymentMethod === 'CASH_ON_DELIVERY'}
                    onChange={handleChange}
                    className="w-4 h-4 text-primary-600"
                  />
                  <FaMoneyBillWave className="text-2xl text-gray-600" />
                  <span className="font-medium">Cash on Delivery</span>
                </label>
              </div>

              {/* Saved Cards for Credit Card */}
              {formData.paymentMethod === 'CREDIT_CARD' && savedCards.length > 0 && !useNewCard && (
                <div className="space-y-3 mb-4">
                  <h3 className="text-sm font-semibold text-gray-700">Select a saved card</h3>
                  {savedCards.map((card) => (
                    <label
                      key={card.id}
                      className={`block p-4 border-2 rounded-lg cursor-pointer transition ${
                        selectedCardId === card.id
                          ? 'border-primary-500 bg-primary-50'
                          : 'border-gray-300 hover:border-primary-300'
                      }`}
                    >
                      <div className="flex items-start">
                        <input
                          type="radio"
                          name="selectedCard"
                          checked={selectedCardId === card.id}
                          onChange={() => handleCardSelect(card.id)}
                          className="mt-1 w-4 h-4 text-primary-600"
                        />
                        <div className="ml-3 flex-1">
                          <div className="flex items-center justify-between">
                            <div className="flex items-center">
                              <FaCreditCard className="text-gray-600 mr-2" />
                              <span className="text-xs font-semibold text-gray-500 uppercase">{card.label}</span>
                              {card.isDefault && (
                                <span className="ml-2 inline-flex items-center px-2 py-0.5 rounded text-xs font-semibold bg-primary-100 text-primary-800">
                                  <FaStar className="mr-1" /> Default
                                </span>
                              )}
                            </div>
                            <span className="text-xs font-semibold text-gray-500 uppercase">{card.cardType}</span>
                          </div>
                          <p className="font-semibold text-gray-900 mt-1">{card.maskedCardNumber}</p>
                          <p className="text-sm text-gray-600">{card.cardholderName}</p>
                          <p className="text-sm text-gray-600">Expires: {card.expiryMonth.toString().padStart(2, '0')}/{card.expiryYear}</p>
                        </div>
                      </div>
                    </label>
                  ))}
                </div>
              )}

              {/* Info Note for Credit Card */}
              {formData.paymentMethod === 'CREDIT_CARD' && savedCards.length > 0 && !useNewCard && selectedCardId && (
                <div className="mt-4 p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <p className="text-sm text-blue-800">
                    <strong>Note:</strong> You'll use your selected card for this order. Payment will be processed securely.
                  </p>
                </div>
              )}

              {/* Add Card Prompt for New Users */}
              {formData.paymentMethod === 'CREDIT_CARD' && savedCards.length === 0 && (
                <div className="mt-4 p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                  <p className="text-sm text-yellow-800">
                    <strong>Note:</strong> To save your card for future purchases, please add it to your profile after placing this order.
                  </p>
                </div>
              )}
            </div>

            <button
              type="submit"
              disabled={isSubmitting}
              className="btn-primary w-full py-3 sm:py-4 text-base sm:text-lg font-semibold touch-manipulation"
            >
              {isSubmitting ? 'Placing Order...' : 'Place Order'}
            </button>
          </form>
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="card lg:sticky lg:top-20">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Order Summary</h2>

            <div className="space-y-3 mb-6 max-h-60 overflow-y-auto">
              {cart.items.map((item) => (
                <div key={item.id} className="flex justify-between text-sm">
                  <span className="text-gray-600">
                    {item.productName} × {item.quantity}
                  </span>
                  <span className="font-semibold">${item.subtotal.toFixed(2)}</span>
                </div>
              ))}
            </div>

            <div className="border-t pt-3 space-y-2">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal</span>
                <span>${(cart.totalAmount || cart.totalPrice || 0).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Shipping</span>
                <span>Free</span>
              </div>
              <div className="flex justify-between text-xl font-bold text-gray-900">
                <span>Total</span>
                <span>${(cart.totalAmount || cart.totalPrice || 0).toFixed(2)}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Checkout;
