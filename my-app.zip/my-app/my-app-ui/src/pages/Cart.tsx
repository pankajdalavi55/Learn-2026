import React from 'react';
import { useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import Loading from '../components/common/Loading';
import { FaTrash, FaMinus, FaPlus, FaShoppingCart } from 'react-icons/fa';

const Cart: React.FC = () => {
  const navigate = useNavigate();
  const { cart, isLoading, updateCartItem, removeFromCart, clearCart } = useCart();

  console.log('Cart page - cart data:', cart);
  console.log('Cart page - isLoading:', isLoading);

  const handleQuantityChange = async (productId: number, newQuantity: number) => {
    if (newQuantity < 1) return;
    try {
      await updateCartItem(productId, newQuantity);
    } catch (error) {
      console.error('Failed to update quantity:', error);
    }
  };

  const handleRemoveItem = async (productId: number) => {
    try {
      await removeFromCart(productId);
    } catch (error) {
      console.error('Failed to remove item:', error);
    }
  };

  const handleClearCart = async () => {
    if (window.confirm('Are you sure you want to clear your cart?')) {
      try {
        await clearCart();
      } catch (error) {
        console.error('Failed to clear cart:', error);
      }
    }
  };

  if (isLoading) {
    return <Loading message="Loading cart..." />;
  }

  if (!cart || !cart.items || cart.items.length === 0) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="text-center">
          <FaShoppingCart className="mx-auto h-24 w-24 text-gray-400 mb-4" />
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Your cart is empty</h2>
          <p className="text-gray-600 mb-8">Start shopping to add items to your cart</p>
          <button onClick={() => navigate('/')} className="btn-primary">
            Browse Products
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-8">
        <h1 className="text-2xl sm:text-3xl font-bold text-gray-900">Shopping Cart</h1>
        <button onClick={handleClearCart} className="btn-danger flex items-center space-x-2 w-full sm:w-auto justify-center">
          <FaTrash />
          <span>Clear Cart</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-4">
          {cart.items && cart.items.map((item) => (
            <div key={item.id} className="card">
              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-4">
              <div className="w-full sm:w-24 h-32 sm:h-24 bg-gray-200 rounded-lg overflow-hidden flex-shrink-0">
                {item.productImageUrl ? (
                  <img
                    src={item.productImageUrl}
                    alt={item.productName}
                    className="w-full h-full object-cover"
                  />
                ) : (
                  <div className="flex items-center justify-center h-full text-gray-400 text-xs">
                    No Image
                  </div>
                )}
              </div>

              <div className="flex-grow">
                <h3 className="text-base sm:text-lg font-semibold text-gray-900">{item.productName}</h3>
                <p className="text-lg font-bold text-primary-600 mt-1">
                  ${item.price.toFixed(2)}
                </p>
              </div>

              <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 sm:gap-4 w-full sm:w-auto">
                <div className="flex items-center space-x-3 w-full sm:w-auto justify-between sm:justify-start">
                  <span className="text-sm text-gray-600 sm:hidden">Quantity:</span>
                  <div className="flex items-center space-x-3">
                    <button
                      onClick={() => handleQuantityChange(item.productId, item.quantity - 1)}
                      className="p-2 sm:p-2.5 bg-gray-200 hover:bg-gray-300 rounded-lg transition touch-manipulation"
                      disabled={item.quantity <= 1}
                    >
                      <FaMinus className="text-sm" />
                    </button>
                    <span className="text-lg font-semibold w-12 text-center">{item.quantity}</span>
                    <button
                      onClick={() => handleQuantityChange(item.productId, item.quantity + 1)}
                      className="p-2 sm:p-2.5 bg-gray-200 hover:bg-gray-300 rounded-lg transition touch-manipulation"
                      disabled={item.quantity >= item.availableStock}
                    >
                      <FaPlus className="text-sm" />
                    </button>
                  </div>
                </div>

                <div className="flex justify-between items-center w-full sm:w-auto sm:text-right">
                  <div>
                    <p className="text-sm text-gray-600 sm:hidden">Subtotal:</p>
                    <p className="text-xl font-bold text-gray-900">
                      ${item.subtotal.toFixed(2)}
                    </p>
                  </div>
                  <button
                    onClick={() => handleRemoveItem(item.productId)}
                    className="text-red-600 hover:text-red-700 text-sm flex items-center space-x-1 sm:mt-2 touch-manipulation"
                  >
                    <FaTrash />
                    <span>Remove</span>
                  </button>
                </div>
              </div>
              </div>
            </div>
          ))}
        </div>

        {/* Order Summary */}
        <div className="lg:col-span-1">
          <div className="card lg:sticky lg:top-20">
            <h2 className="text-xl font-bold text-gray-900 mb-4">Order Summary</h2>

            <div className="space-y-3 mb-6">
              <div className="flex justify-between text-gray-600">
                <span>Subtotal ({cart.totalItems || 0} items)</span>
                <span>${(cart.totalAmount || cart.totalPrice || 0).toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-gray-600">
                <span>Shipping</span>
                <span>Free</span>
              </div>
              <div className="border-t pt-3 flex justify-between text-xl font-bold text-gray-900">
                <span>Total</span>
                <span>${(cart.totalAmount || cart.totalPrice || 0).toFixed(2)}</span>
              </div>
            </div>

            <button
              onClick={() => navigate('/checkout')}
              className="btn-primary w-full py-3 text-lg font-semibold"
            >
              Proceed to Checkout
            </button>

            <button
              onClick={() => navigate('/')}
              className="btn-secondary w-full mt-3"
            >
              Continue Shopping
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
