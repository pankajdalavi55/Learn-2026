import React, { useState, useEffect } from 'react';
import { productService } from '../services/product.service';
import { categoryService } from '../services/category.service';
import type { Product, Category, ProductFilter, PageRequest } from '../types';
import ProductCard from '../components/product/ProductCard';
import Loading from '../components/common/Loading';
import { FaSearch, FaFilter } from 'react-icons/fa';
import { toast } from 'react-toastify';

const Home: React.FC = () => {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchKeyword, setSearchKeyword] = useState('');
  const [filter, setFilter] = useState<ProductFilter>({});
  const [brands, setBrands] = useState<string[]>([]);
  const [showFilters, setShowFilters] = useState(false);
  
  const [pagination, setPagination] = useState({
    page: 0,
    size: 12,
    totalPages: 0,
    totalElements: 0,
  });

  useEffect(() => {
    fetchCategories();
    fetchBrands();
  }, []);

  useEffect(() => {
    fetchProducts();
  }, [pagination.page, filter]);

  const fetchCategories = async () => {
    try {
      const data = await categoryService.getAllCategories(true);
      setCategories(data);
    } catch (error) {
      console.error('Failed to fetch categories:', error);
    }
  };

  const fetchBrands = async () => {
    try {
      const data = await productService.getAllBrands();
      setBrands(data);
    } catch (error) {
      console.error('Failed to fetch brands:', error);
    }
  };

  const fetchProducts = async () => {
    setLoading(true);
    try {
      const pageRequest: PageRequest = {
        page: pagination.page,
        size: pagination.size,
        sortBy: 'createdAt',
        sortDir: 'DESC',
      };

      let response;
      if (Object.keys(filter).length > 0) {
        response = await productService.filterProducts(filter, pageRequest);
      } else {
        response = await productService.getAllProducts(pageRequest);
      }

      setProducts(response.content);
      setPagination((prev) => ({
        ...prev,
        totalPages: response.totalPages,
        totalElements: response.totalElements,
      }));
    } catch (error: any) {
      toast.error('Failed to load products');
      console.error('Failed to fetch products:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSearch = async () => {
    if (!searchKeyword.trim()) {
      setFilter({});
      return;
    }

    setFilter({ keyword: searchKeyword });
    setPagination((prev) => ({ ...prev, page: 0 }));
  };

  const handleFilterChange = (key: keyof ProductFilter, value: any) => {
    setFilter((prev) => {
      const newFilter = { ...prev };
      if (value === '' || value === undefined) {
        delete newFilter[key];
      } else {
        newFilter[key] = value;
      }
      return newFilter;
    });
    setPagination((prev) => ({ ...prev, page: 0 }));
  };

  const clearFilters = () => {
    setFilter({});
    setSearchKeyword('');
    setPagination((prev) => ({ ...prev, page: 0 }));
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900 mb-2">Products</h1>
        <p className="text-gray-600">Discover our wide range of products</p>
      </div>

      {/* Search Bar */}
      <div className="mb-6">
        <div className="flex flex-col sm:flex-row gap-3 sm:gap-4">
          <div className="flex-1 flex">
            <input
              type="text"
              placeholder="Search products..."
              value={searchKeyword}
              onChange={(e) => setSearchKeyword(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && handleSearch()}
              className="input-field rounded-r-none text-sm sm:text-base"
            />
            <button onClick={handleSearch} className="btn-primary rounded-l-none px-4 sm:px-6">
              <FaSearch className="text-lg" />
            </button>
          </div>
          <button
            onClick={() => setShowFilters(!showFilters)}
            className="btn-secondary flex items-center justify-center space-x-2 py-3 sm:py-2"
          >
            <FaFilter />
            <span className="font-medium">{showFilters ? 'Hide Filters' : 'Show Filters'}</span>
          </button>
        </div>
      </div>

      {/* Filters */}
      {showFilters && (
        <div className="card mb-6 animate-fadeIn">
          <h3 className="text-lg sm:text-xl font-semibold mb-4">Filters</h3>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Category
              </label>
              <select
                value={filter.category || ''}
                onChange={(e) =>
                  handleFilterChange('category', e.target.value ? Number(e.target.value) : undefined)
                }
                className="input-field"
              >
                <option value="">All Categories</option>
                {categories.map((cat) => (
                  <option key={cat.id} value={cat.id}>
                    {cat.name}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Brand</label>
              <select
                value={filter.brand || ''}
                onChange={(e) => handleFilterChange('brand', e.target.value || undefined)}
                className="input-field"
              >
                <option value="">All Brands</option>
                {brands.map((brand) => (
                  <option key={brand} value={brand}>
                    {brand}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Min Price
              </label>
              <input
                type="number"
                placeholder="0"
                value={filter.minPrice || ''}
                onChange={(e) =>
                  handleFilterChange('minPrice', e.target.value ? Number(e.target.value) : undefined)
                }
                className="input-field"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Max Price
              </label>
              <input
                type="number"
                placeholder="1000"
                value={filter.maxPrice || ''}
                onChange={(e) =>
                  handleFilterChange('maxPrice', e.target.value ? Number(e.target.value) : undefined)
                }
                className="input-field"
              />
            </div>
          </div>

          <div className="mt-4 flex flex-col sm:flex-row justify-end gap-2">
            <button onClick={clearFilters} className="btn-secondary w-full sm:w-auto">
              Clear Filters
            </button>
          </div>
        </div>
      )}

      {/* Products Grid */}
      {loading ? (
        <Loading message="Loading products..." />
      ) : products.length === 0 ? (
        <div className="text-center py-12">
          <p className="text-gray-600 text-lg">No products found</p>
          {Object.keys(filter).length > 0 && (
            <button onClick={clearFilters} className="btn-primary mt-4">
              Clear Filters
            </button>
          )}
        </div>
      ) : (
        <>
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6 mb-8">
            {products.map((product) => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>

          {/* Pagination */}
          {pagination.totalPages > 1 && (
            <div className="flex flex-col sm:flex-row justify-center items-center gap-3 sm:gap-2">
              <button
                onClick={() => setPagination((prev) => ({ ...prev, page: prev.page - 1 }))}
                disabled={pagination.page === 0}
                className="btn-secondary disabled:opacity-50 w-full sm:w-auto min-w-[100px]"
              >
                Previous
              </button>
              <span className="text-gray-600 text-sm sm:text-base font-medium order-first sm:order-none">
                Page {pagination.page + 1} of {pagination.totalPages}
              </span>
              <button
                onClick={() => setPagination((prev) => ({ ...prev, page: prev.page + 1 }))}
                disabled={pagination.page >= pagination.totalPages - 1}
                className="btn-secondary disabled:opacity-50 w-full sm:w-auto min-w-[100px]"
              >
                Next
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default Home;
