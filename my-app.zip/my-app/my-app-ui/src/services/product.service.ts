import axiosInstance from './axios';
import type { Product, ProductDTO, PageResponse, ProductFilter, PageRequest } from '../types';

export const productService = {
  getProducts: async (params: PageRequest & { category?: number }): Promise<PageResponse<Product>> => {
    if (params.category) {
      return productService.getProductsByCategory(params.category, params);
    }
    return productService.getAllProducts(params);
  },

  getAllProducts: async (params: PageRequest): Promise<PageResponse<Product>> => {
    const response = await axiosInstance.get<PageResponse<Product>>('/products', {
      params: {
        page: params.page,
        size: params.size,
        sortBy: params.sortBy || 'createdAt',
        sortDir: params.sortDir || 'DESC',
      },
    });
    return response.data;
  },

  filterProducts: async (
    filter: ProductFilter,
    params: PageRequest
  ): Promise<PageResponse<Product>> => {
    const response = await axiosInstance.get<PageResponse<Product>>('/products/filter', {
      params: {
        ...filter,
        page: params.page,
        size: params.size,
        sortBy: params.sortBy || 'createdAt',
        sortDir: params.sortDir || 'DESC',
      },
    });
    return response.data;
  },

  searchProducts: async (keyword: string, params: PageRequest): Promise<PageResponse<Product>> => {
    const response = await axiosInstance.get<PageResponse<Product>>('/products/search', {
      params: {
        keyword,
        page: params.page,
        size: params.size,
        sortBy: params.sortBy || 'createdAt',
        sortDir: params.sortDir || 'DESC',
      },
    });
    return response.data;
  },

  getProductsByCategory: async (
    categoryId: number,
    params: PageRequest
  ): Promise<PageResponse<Product>> => {
    const response = await axiosInstance.get<PageResponse<Product>>(
      `/products/category/${categoryId}`,
      {
        params: {
          page: params.page,
          size: params.size,
          sortBy: params.sortBy || 'createdAt',
          sortDir: params.sortDir || 'DESC',
        },
      }
    );
    return response.data;
  },

  getProductById: async (id: number): Promise<Product> => {
    const response = await axiosInstance.get<Product>(`/products/${id}`);
    return response.data;
  },

  getAllBrands: async (): Promise<string[]> => {
    const response = await axiosInstance.get<string[]>('/products/brands/list');
    return response.data;
  },

  getOutOfStockProducts: async (page = 0, size = 10): Promise<PageResponse<Product>> => {
    const response = await axiosInstance.get<PageResponse<Product>>('/products/stock/out', {
      params: { page, size },
    });
    return response.data;
  },

  getLowStockProducts: async (threshold: number = 10, page = 0, size = 10): Promise<PageResponse<Product>> => {
    const response = await axiosInstance.get<PageResponse<Product>>('/products/stock/low', {
      params: { threshold, page, size },
    });
    return response.data;
  },

  createProduct: async (product: ProductDTO): Promise<Product> => {
    const response = await axiosInstance.post<Product>('/products', product);
    return response.data;
  },

  updateProduct: async (id: number, product: ProductDTO): Promise<Product> => {
    const response = await axiosInstance.put<Product>(`/products/${id}`, product);
    return response.data;
  },

  deleteProduct: async (id: number): Promise<void> => {
    await axiosInstance.delete(`/products/${id}`);
  },
};
