import axiosInstance from './axios';
import type { Order, OrderRequest, OrderStatus, PageResponse } from '../types';

export const orderService = {
  getAllOrders: async (page = 0, size = 1000): Promise<PageResponse<Order>> => {
    const response = await axiosInstance.get<PageResponse<Order>>('/orders', {
      params: { page, size },
    });
    return response.data;
  },

  placeOrder: async (userId: number, request: OrderRequest): Promise<Order> => {
    const response = await axiosInstance.post<Order>('/orders', request, {
      params: { userId },
    });
    return response.data;
  },

  getOrderById: async (orderId: number, userId: number): Promise<Order> => {
    const response = await axiosInstance.get<Order>(`/orders/${orderId}`, {
      params: { userId },
    });
    return response.data;
  },

  getOrderByOrderNumber: async (orderNumber: string, userId: number): Promise<Order> => {
    const response = await axiosInstance.get<Order>(`/orders/number/${orderNumber}`, {
      params: { userId },
    });
    return response.data;
  },

  getUserOrders: async (userId: number, page = 0, size = 10): Promise<PageResponse<Order>> => {
    const response = await axiosInstance.get<PageResponse<Order>>(`/orders/user/${userId}`, {
      params: { page, size },
    });
    return response.data;
  },

  updateOrderStatus: async (orderId: number, status: OrderStatus): Promise<Order> => {
    const response = await axiosInstance.patch<Order>(`/orders/${orderId}/status`, null, {
      params: { status },
    });
    return response.data;
  },

  cancelOrder: async (orderId: number, userId: number): Promise<Order> => {
    const response = await axiosInstance.post<Order>(`/orders/${orderId}/cancel`, null, {
      params: { userId },
    });
    return response.data;
  },
};
