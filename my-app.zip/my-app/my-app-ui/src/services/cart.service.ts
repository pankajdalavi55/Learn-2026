import axiosInstance from './axios';
import type { Cart, AddToCartRequest } from '../types';

export const cartService = {
  getCart: async (userId: number): Promise<Cart> => {
    const response = await axiosInstance.get<Cart>('/cart', {
      params: { userId },
    });
    return response.data;
  },

  addToCart: async (userId: number, request: AddToCartRequest): Promise<Cart> => {
    const response = await axiosInstance.post<Cart>('/cart/add', request, {
      params: { userId },
    });
    return response.data;
  },

  updateCartItem: async (userId: number, productId: number, quantity: number): Promise<Cart> => {
    const response = await axiosInstance.put<Cart>(
      '/cart/update',
      {},
      {
        params: { userId, productId, quantity },
      }
    );
    return response.data;
  },

  removeFromCart: async (userId: number, productId: number): Promise<Cart> => {
    const response = await axiosInstance.delete<Cart>('/cart/remove', {
      params: { userId, productId },
    });
    return response.data;
  },

  clearCart: async (userId: number): Promise<void> => {
    await axiosInstance.delete('/cart/clear', {
      params: { userId },
    });
  },
};
