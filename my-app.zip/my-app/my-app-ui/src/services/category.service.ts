import axiosInstance from './axios';
import type { Category, CategoryDTO } from '../types';

export const categoryService = {
  getAllCategories: async (activeOnly = false): Promise<Category[]> => {
    const response = await axiosInstance.get<Category[]>('/categories', {
      params: { activeOnly },
    });
    return response.data;
  },

  getCategoryById: async (id: number): Promise<Category> => {
    const response = await axiosInstance.get<Category>(`/categories/${id}`);
    return response.data;
  },

  getTopLevelCategories: async (): Promise<Category[]> => {
    const response = await axiosInstance.get<Category[]>('/categories/top-level');
    return response.data;
  },

  getSubCategories: async (id: number): Promise<Category[]> => {
    const response = await axiosInstance.get<Category[]>(`/categories/${id}/subcategories`);
    return response.data;
  },

  createCategory: async (category: CategoryDTO): Promise<Category> => {
    const response = await axiosInstance.post<Category>('/categories', category);
    return response.data;
  },

  updateCategory: async (id: number, category: CategoryDTO): Promise<Category> => {
    const response = await axiosInstance.put<Category>(`/categories/${id}`, category);
    return response.data;
  },

  deleteCategory: async (id: number): Promise<void> => {
    await axiosInstance.delete(`/categories/${id}`);
  },
};
