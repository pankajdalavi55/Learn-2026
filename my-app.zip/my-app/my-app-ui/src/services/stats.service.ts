import axiosInstance from './axios';

export interface DashboardStats {
  totalUsers: number;
  totalProducts: number;
  totalCategories: number;
  totalOrders: number;
  todayOrders: number;
  pendingOrders: number;
  totalRevenue: number;
  todayRevenue: number;
  lowStockProducts: number;
  outOfStockProducts: number;
}

export interface RecentOrder {
  id: number;
  orderNumber: string;
  userName: string;
  totalAmount: number;
  status: string;
  createdAt: string;
}

export interface ProductStats {
  date: string;
  count: number;
}

export interface RevenueStats {
  date: string;
  revenue: number;
}

export const statsService = {
  getDashboardStats: async (): Promise<DashboardStats> => {
    // Since we don't have a dedicated stats endpoint, we'll fetch data from existing endpoints
    try {
      const [products, categories] = await Promise.all([
        axiosInstance.get('/products?page=0&size=1'),
        axiosInstance.get('/categories'),
      ]);

      // Mock stats for now - in production, you'd have a dedicated stats endpoint
      return {
        totalUsers: 0,
        totalProducts: products.data.totalElements || 0,
        totalCategories: Array.isArray(categories.data) ? categories.data.length : 0,
        totalOrders: 0,
        todayOrders: 0,
        pendingOrders: 0,
        totalRevenue: 0,
        todayRevenue: 0,
        lowStockProducts: 0,
        outOfStockProducts: 0,
      };
    } catch (error) {
      console.error('Failed to fetch dashboard stats:', error);
      throw error;
    }
  },

  getRecentOrders: async (limit = 5): Promise<RecentOrder[]> => {
    // Mock data for now
    return [];
  },

  getProductStats: async (days = 7): Promise<ProductStats[]> => {
    // Mock data for now
    return [];
  },

  getRevenueStats: async (days = 7): Promise<RevenueStats[]> => {
    // Mock data for now
    return [];
  },
};
