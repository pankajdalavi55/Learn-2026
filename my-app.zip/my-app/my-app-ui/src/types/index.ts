// User and Authentication Types
export type Role = 'CUSTOMER' | 'VENDOR' | 'SUPPORT' | 'MANAGER' | 'ADMIN';

export interface User {
  id: number;
  name: string;
  email: string;
  phone: string;
  role: Role;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  country?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface AuthResponse {
  token: string;
  type: string;
  userId: number;
  id?: number;
  email: string;
  name: string;
  role: Role;
  phone?: string;
  address?: string;
  profilePictureUrl?: string | null;
}

export interface LoginRequest {
  email: string;
  password: string;
}

export interface RegisterRequest {
  name: string;
  email: string;
  phone: string;
  password: string;
  role?: Role;
  address?: string;
  city?: string;
  state?: string;
  zipCode?: string;
  country?: string;
}

// Product Types
export interface Product {
  id: number;
  name: string;
  description: string;
  price: number;
  brand: string;
  stockQuantity: number;
  imageUrl?: string;
  category?: Category;
  categoryId?: number;
  categoryName?: string;
  createdAt?: string;
  updatedAt?: string;
}

export interface ProductDTO {
  id?: number;
  name: string;
  description: string;
  price: number;
  brand: string;
  stockQuantity: number;
  imageUrl?: string;
  categoryId: number;
  categoryName?: string;
}

// Category Types
export interface Category {
  id: number;
  name: string;
  description?: string;
  imageUrl?: string;
  isActive?: boolean;
  parentId?: number;
  parentName?: string;
  productCount?: number;
  subCategoryCount?: number;
  createdAt?: string;
  updatedAt?: string;
}

export interface CategoryDTO {
  id?: number;
  name: string;
  description?: string;
  imageUrl?: string;
  isActive?: boolean;
  parentId?: number;
}

// Cart Types
export interface CartItem {
  id: number;
  productId: number;
  productName: string;
  productImageUrl?: string;
  quantity: number;
  price: number;
  subtotal: number;
  availableStock: number;
}

export interface Cart {
  id: number;
  userId: number;
  items: CartItem[];
  totalItems: number;
  totalAmount: number;  // Backend uses totalAmount, not totalPrice
  totalPrice?: number;  // Alias for totalAmount for backward compatibility
  createdAt?: string;
  updatedAt?: string;
}

export interface AddToCartRequest {
  productId: number;
  quantity: number;
}

// Order Types
export type OrderStatus = 'PENDING' | 'PROCESSING' | 'SHIPPED' | 'DELIVERED' | 'CANCELLED';

export interface OrderItem {
  id: number;
  productId: number;
  productName: string;
  quantity: number;
  price: number;
  subtotal: number;
}

export interface Order {
  id: number;
  orderNumber: string;
  userId: number;
  items: OrderItem[];
  totalItems: number;
  totalAmount: number;
  status: OrderStatus;
  shippingAddress: string;
  shippingCity: string;
  shippingState: string;
  shippingPostalCode: string;
  shippingCountry: string;
  phoneNumber?: string;
  notes?: string;
  paymentMethod: string;
  paymentStatus?: string;
  createdAt: string;
  updatedAt: string;
  deliveredAt?: string;
}

export interface OrderRequest {
  shippingAddress: string;
  shippingCity: string;
  shippingState: string;
  shippingPostalCode: string;
  shippingCountry: string;
  phoneNumber?: string;
  notes?: string;
  paymentMethod: string;
}

// Pagination Types
export interface PageRequest {
  page: number;
  size: number;
  sortBy?: string;
  sortDir?: 'ASC' | 'DESC';
}

export interface PageResponse<T> {
  content: T[];
  totalPages: number;
  totalElements: number;
  size: number;
  number: number;
  numberOfElements: number;
  first: boolean;
  last: boolean;
  empty: boolean;
}

// Filter Types
export interface ProductFilter {
  category?: number;
  brand?: string;
  minPrice?: number;
  maxPrice?: number;
  keyword?: string;
}

// API Error Type
export interface ApiError {
  message: string;
  status: number;
  timestamp?: string;
}
