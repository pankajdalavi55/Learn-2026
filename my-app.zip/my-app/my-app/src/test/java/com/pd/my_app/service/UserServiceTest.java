package com.pd.my_app.service;

import com.pd.my_app.dto.UserDTO;
import com.pd.my_app.entity.User;
import com.pd.my_app.exception.DuplicateEmailException;
import com.pd.my_app.exception.UserNotFoundException;
import com.pd.my_app.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("UserService Tests")
class UserServiceTest {

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private UserService userService;

    private User testUser;
    private UserDTO testUserDTO;

    @BeforeEach
    void setUp() {
        testUser = new User("John Doe", "john@test.com", "1234567890");
        testUser.setId(1L);
        testUser.setIsActive(true);

        testUserDTO = new UserDTO();
        testUserDTO.setName("John Doe");
        testUserDTO.setEmail("john@test.com");
        testUserDTO.setPhone("1234567890");
    }

    @Test
    @DisplayName("Should create user successfully")
    void testCreateUser() {
        // Given
        when(userRepository.existsByEmail(testUserDTO.getEmail())).thenReturn(false);
        when(userRepository.save(any(User.class))).thenReturn(testUser);

        // When
        UserDTO result = userService.createUser(testUserDTO);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo("John Doe");
        assertThat(result.getEmail()).isEqualTo("john@test.com");
        verify(userRepository).existsByEmail(testUserDTO.getEmail());
        verify(userRepository).save(any(User.class));
    }

    @Test
    @DisplayName("Should throw exception when creating user with duplicate email")
    void testCreateUserDuplicateEmail() {
        // Given
        when(userRepository.existsByEmail(testUserDTO.getEmail())).thenReturn(true);

        // When/Then
        assertThatThrownBy(() -> userService.createUser(testUserDTO))
                .isInstanceOf(DuplicateEmailException.class)
                .hasMessageContaining("john@test.com");

        verify(userRepository).existsByEmail(testUserDTO.getEmail());
        verify(userRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should get user by ID successfully")
    void testGetUserById() {
        // Given
        Long userId = 1L;
        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));

        // When
        UserDTO result = userService.getUserById(userId);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(1L);
        assertThat(result.getEmail()).isEqualTo("john@test.com");
        verify(userRepository).findById(userId);
    }

    @Test
    @DisplayName("Should throw exception when user not found by ID")
    void testGetUserByIdNotFound() {
        // Given
        Long userId = 999L;
        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        // When/Then
        assertThatThrownBy(() -> userService.getUserById(userId))
                .isInstanceOf(UserNotFoundException.class)
                .hasMessageContaining("999");

        verify(userRepository).findById(userId);
    }

    @Test
    @DisplayName("Should get all users successfully")
    void testGetAllUsers() {
        // Given
        List<User> users = Arrays.asList(testUser);
        when(userRepository.findAll()).thenReturn(users);

        // When
        List<UserDTO> result = userService.getAllUsers();

        // Then
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getName()).isEqualTo("John Doe");
        verify(userRepository).findAll();
    }

    @Test
    @DisplayName("Should get active users only")
    void testGetActiveUsers() {
        // Given
        List<User> users = Arrays.asList(testUser);
        when(userRepository.findByIsActive(true)).thenReturn(users);

        // When
        List<UserDTO> result = userService.getActiveUsers();

        // Then
        assertThat(result).hasSize(1);
        assertThat(result.get(0).getIsActive()).isTrue();
        verify(userRepository).findByIsActive(true);
    }

    @Test
    @DisplayName("Should update user successfully")
    void testUpdateUser() {
        // Given
        Long userId = 1L;
        testUserDTO.setName("Jane Doe");
        testUserDTO.setEmail("jane@test.com");

        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(userRepository.existsByEmail("jane@test.com")).thenReturn(false);
        when(userRepository.save(any(User.class))).thenReturn(testUser);

        // When
        UserDTO result = userService.updateUser(userId, testUserDTO);

        // Then
        assertThat(result).isNotNull();
        verify(userRepository).findById(userId);
        verify(userRepository).existsByEmail("jane@test.com");
        verify(userRepository).save(any(User.class));
    }

    @Test
    @DisplayName("Should update user with same email")
    void testUpdateUserSameEmail() {
        // Given
        Long userId = 1L;
        testUserDTO.setName("John Updated");

        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(userRepository.save(any(User.class))).thenReturn(testUser);

        // When
        UserDTO result = userService.updateUser(userId, testUserDTO);

        // Then
        assertThat(result).isNotNull();
        verify(userRepository).findById(userId);
        verify(userRepository, never()).existsByEmail(any());
        verify(userRepository).save(any(User.class));
    }

    @Test
    @DisplayName("Should throw exception when updating with duplicate email")
    void testUpdateUserDuplicateEmail() {
        // Given
        Long userId = 1L;
        testUserDTO.setEmail("another@test.com");

        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(userRepository.existsByEmail("another@test.com")).thenReturn(true);

        // When/Then
        assertThatThrownBy(() -> userService.updateUser(userId, testUserDTO))
                .isInstanceOf(DuplicateEmailException.class);

        verify(userRepository).findById(userId);
        verify(userRepository).existsByEmail("another@test.com");
        verify(userRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should throw exception when updating non-existent user")
    void testUpdateUserNotFound() {
        // Given
        Long userId = 999L;
        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        // When/Then
        assertThatThrownBy(() -> userService.updateUser(userId, testUserDTO))
                .isInstanceOf(UserNotFoundException.class);

        verify(userRepository).findById(userId);
        verify(userRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should delete user successfully")
    void testDeleteUser() {
        // Given
        Long userId = 1L;
        when(userRepository.existsById(userId)).thenReturn(true);
        doNothing().when(userRepository).deleteById(userId);

        // When
        userService.deleteUser(userId);

        // Then
        verify(userRepository).existsById(userId);
        verify(userRepository).deleteById(userId);
    }

    @Test
    @DisplayName("Should throw exception when deleting non-existent user")
    void testDeleteUserNotFound() {
        // Given
        Long userId = 999L;
        when(userRepository.existsById(userId)).thenReturn(false);

        // When/Then
        assertThatThrownBy(() -> userService.deleteUser(userId))
                .isInstanceOf(UserNotFoundException.class);

        verify(userRepository).existsById(userId);
        verify(userRepository, never()).deleteById(any());
    }

    @Test
    @DisplayName("Should deactivate user successfully")
    void testDeactivateUser() {
        // Given
        Long userId = 1L;
        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(userRepository.save(any(User.class))).thenAnswer(invocation -> {
            User user = invocation.getArgument(0);
            assertThat(user.getIsActive()).isFalse();
            return user;
        });

        // When
        userService.deactivateUser(userId);

        // Then
        verify(userRepository).findById(userId);
        verify(userRepository).save(any(User.class));
    }

    @Test
    @DisplayName("Should throw exception when deactivating non-existent user")
    void testDeactivateUserNotFound() {
        // Given
        Long userId = 999L;
        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        // When/Then
        assertThatThrownBy(() -> userService.deactivateUser(userId))
                .isInstanceOf(UserNotFoundException.class);

        verify(userRepository).findById(userId);
        verify(userRepository, never()).save(any());
    }
}
