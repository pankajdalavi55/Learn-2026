package com.pd.my_app.service;

import com.pd.my_app.dto.ProductDTO;
import com.pd.my_app.entity.Category;
import com.pd.my_app.entity.Product;
import com.pd.my_app.exception.CategoryNotFoundException;
import com.pd.my_app.exception.ProductNotFoundException;
import com.pd.my_app.repository.CategoryRepository;
import com.pd.my_app.repository.ProductRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.*;
import org.springframework.data.jpa.domain.Specification;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("ProductService Tests")
class ProductServiceTest {

    @Mock
    private ProductRepository productRepository;

    @Mock
    private CategoryRepository categoryRepository;

    @InjectMocks
    private ProductService productService;

    private Product testProduct;
    private Category testCategory;
    private ProductDTO testProductDTO;

    @BeforeEach
    void setUp() {
        testCategory = new Category("Electronics", "Electronic items");
        testCategory.setId(1L);

        testProduct = new Product("Laptop", "High performance laptop", 
                                  new BigDecimal("999.99"), 50);
        testProduct.setId(1L);
        testProduct.setBrand("Dell");
        testProduct.setSku("DELL-001");
        testProduct.setCategory(testCategory);
        testProduct.setIsActive(true);
        testProduct.setIsFeatured(false);

        testProductDTO = new ProductDTO();
        testProductDTO.setName("Laptop");
        testProductDTO.setDescription("High performance laptop");
        testProductDTO.setPrice(new BigDecimal("999.99"));
        testProductDTO.setStockQuantity(50);
        testProductDTO.setBrand("Dell");
        testProductDTO.setCategoryId(1L);
    }

    @Test
    @DisplayName("Should get all products with pagination")
    void testGetAllProducts() {
        // Given
        Pageable pageable = PageRequest.of(0, 10);
        List<Product> products = Arrays.asList(testProduct);
        Page<Product> productPage = new PageImpl<>(products, pageable, 1);

        when(productRepository.findByIsActiveTrue(pageable)).thenReturn(productPage);

        // When
        Page<ProductDTO> result = productService.getAllProducts(pageable);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getContent()).hasSize(1);
        assertThat(result.getContent().get(0).getName()).isEqualTo("Laptop");
        verify(productRepository, times(1)).findByIsActiveTrue(pageable);
    }

    @Test
    @DisplayName("Should get products by category")
    void testGetProductsByCategory() {
        // Given
        Long categoryId = 1L;
        Pageable pageable = PageRequest.of(0, 10);
        List<Product> products = Arrays.asList(testProduct);
        Page<Product> productPage = new PageImpl<>(products, pageable, 1);

        when(categoryRepository.existsById(categoryId)).thenReturn(true);
        when(productRepository.findByCategoryIdAndIsActiveTrue(categoryId, pageable))
                .thenReturn(productPage);

        // When
        Page<ProductDTO> result = productService.getProductsByCategory(categoryId, pageable);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getContent()).hasSize(1);
        verify(categoryRepository).existsById(categoryId);
        verify(productRepository).findByCategoryIdAndIsActiveTrue(categoryId, pageable);
    }

    @Test
    @DisplayName("Should throw exception when category not found")
    void testGetProductsByCategoryNotFound() {
        // Given
        Long categoryId = 999L;
        Pageable pageable = PageRequest.of(0, 10);

        when(categoryRepository.existsById(categoryId)).thenReturn(false);

        // When/Then
        assertThatThrownBy(() -> productService.getProductsByCategory(categoryId, pageable))
                .isInstanceOf(CategoryNotFoundException.class)
                .hasMessageContaining("999");

        verify(categoryRepository).existsById(categoryId);
        verify(productRepository, never()).findByCategoryIdAndIsActiveTrue(any(), any());
    }

    @Test
    @DisplayName("Should search products by keyword")
    void testSearchProducts() {
        // Given
        String keyword = "laptop";
        Pageable pageable = PageRequest.of(0, 10);
        List<Product> products = Arrays.asList(testProduct);
        Page<Product> productPage = new PageImpl<>(products, pageable, 1);

        when(productRepository.searchProducts(keyword, pageable)).thenReturn(productPage);

        // When
        Page<ProductDTO> result = productService.searchProducts(keyword, pageable);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getContent()).hasSize(1);
        verify(productRepository).searchProducts(keyword, pageable);
    }

    @Test
    @DisplayName("Should filter products with all parameters")
    void testFilterProductsWithAllParams() {
        // Given
        Long categoryId = 1L;
        String brand = "Dell";
        BigDecimal minPrice = new BigDecimal("500");
        BigDecimal maxPrice = new BigDecimal("1500");
        String keyword = "laptop";
        Pageable pageable = PageRequest.of(0, 10);

        List<Product> products = Arrays.asList(testProduct);
        Page<Product> productPage = new PageImpl<>(products, pageable, 1);

        when(productRepository.findAll(any(Specification.class), eq(pageable)))
                .thenReturn(productPage);

        // When
        Page<ProductDTO> result = productService.filterProducts(
                categoryId, brand, minPrice, maxPrice, keyword, pageable);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getContent()).hasSize(1);
        verify(productRepository).findAll(any(Specification.class), eq(pageable));
    }

    @Test
    @DisplayName("Should filter products with null parameters")
    void testFilterProductsWithNullParams() {
        // Given
        Pageable pageable = PageRequest.of(0, 10);
        List<Product> products = Arrays.asList(testProduct);
        Page<Product> productPage = new PageImpl<>(products, pageable, 1);

        when(productRepository.findAll(any(Specification.class), eq(pageable)))
                .thenReturn(productPage);

        // When
        Page<ProductDTO> result = productService.filterProducts(
                null, null, null, null, null, pageable);

        // Then
        assertThat(result).isNotNull();
        verify(productRepository).findAll(any(Specification.class), eq(pageable));
    }

    @Test
    @DisplayName("Should get product by ID")
    void testGetProductById() {
        // Given
        Long productId = 1L;
        when(productRepository.findById(productId)).thenReturn(Optional.of(testProduct));

        // When
        ProductDTO result = productService.getProductById(productId);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(1L);
        assertThat(result.getName()).isEqualTo("Laptop");
        assertThat(result.getPrice()).isEqualByComparingTo(new BigDecimal("999.99"));
        verify(productRepository).findById(productId);
    }

    @Test
    @DisplayName("Should throw exception when product not found by ID")
    void testGetProductByIdNotFound() {
        // Given
        Long productId = 999L;
        when(productRepository.findById(productId)).thenReturn(Optional.empty());

        // When/Then
        assertThatThrownBy(() -> productService.getProductById(productId))
                .isInstanceOf(ProductNotFoundException.class)
                .hasMessageContaining("999");

        verify(productRepository).findById(productId);
    }

    @Test
    @DisplayName("Should create product successfully")
    void testCreateProduct() {
        // Given
        when(categoryRepository.findById(1L)).thenReturn(Optional.of(testCategory));
        when(productRepository.save(any(Product.class))).thenReturn(testProduct);

        // When
        ProductDTO result = productService.createProduct(testProductDTO);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getName()).isEqualTo("Laptop");
        assertThat(result.getCategoryName()).isEqualTo("Electronics");
        verify(categoryRepository).findById(1L);
        verify(productRepository).save(any(Product.class));
    }

    @Test
    @DisplayName("Should create product without category")
    void testCreateProductWithoutCategory() {
        // Given
        testProductDTO.setCategoryId(null);
        when(productRepository.save(any(Product.class))).thenReturn(testProduct);

        // When
        ProductDTO result = productService.createProduct(testProductDTO);

        // Then
        assertThat(result).isNotNull();
        verify(categoryRepository, never()).findById(any());
        verify(productRepository).save(any(Product.class));
    }

    @Test
    @DisplayName("Should throw exception when creating product with invalid category")
    void testCreateProductWithInvalidCategory() {
        // Given
        when(categoryRepository.findById(1L)).thenReturn(Optional.empty());

        // When/Then
        assertThatThrownBy(() -> productService.createProduct(testProductDTO))
                .isInstanceOf(CategoryNotFoundException.class);

        verify(categoryRepository).findById(1L);
        verify(productRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should update product successfully")
    void testUpdateProduct() {
        // Given
        Long productId = 1L;
        testProductDTO.setName("Updated Laptop");
        testProductDTO.setPrice(new BigDecimal("899.99"));

        when(productRepository.findById(productId)).thenReturn(Optional.of(testProduct));
        when(categoryRepository.findById(1L)).thenReturn(Optional.of(testCategory));
        when(productRepository.save(any(Product.class))).thenReturn(testProduct);

        // When
        ProductDTO result = productService.updateProduct(productId, testProductDTO);

        // Then
        assertThat(result).isNotNull();
        verify(productRepository).findById(productId);
        verify(categoryRepository).findById(1L);
        verify(productRepository).save(any(Product.class));
    }

    @Test
    @DisplayName("Should throw exception when updating non-existent product")
    void testUpdateProductNotFound() {
        // Given
        Long productId = 999L;
        when(productRepository.findById(productId)).thenReturn(Optional.empty());

        // When/Then
        assertThatThrownBy(() -> productService.updateProduct(productId, testProductDTO))
                .isInstanceOf(ProductNotFoundException.class);

        verify(productRepository).findById(productId);
        verify(productRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should delete product successfully")
    void testDeleteProduct() {
        // Given
        Long productId = 1L;
        when(productRepository.existsById(productId)).thenReturn(true);
        doNothing().when(productRepository).deleteById(productId);

        // When
        productService.deleteProduct(productId);

        // Then
        verify(productRepository).existsById(productId);
        verify(productRepository).deleteById(productId);
    }

    @Test
    @DisplayName("Should throw exception when deleting non-existent product")
    void testDeleteProductNotFound() {
        // Given
        Long productId = 999L;
        when(productRepository.existsById(productId)).thenReturn(false);

        // When/Then
        assertThatThrownBy(() -> productService.deleteProduct(productId))
                .isInstanceOf(ProductNotFoundException.class);

        verify(productRepository).existsById(productId);
        verify(productRepository, never()).deleteById(any());
    }

    @Test
    @DisplayName("Should get all brands")
    void testGetAllBrands() {
        // Given
        List<String> brands = Arrays.asList("Dell", "HP", "Lenovo");
        when(productRepository.findAllBrands()).thenReturn(brands);

        // When
        List<String> result = productService.getAllBrands();

        // Then
        assertThat(result).hasSize(3);
        assertThat(result).contains("Dell", "HP", "Lenovo");
        verify(productRepository).findAllBrands();
    }
}
