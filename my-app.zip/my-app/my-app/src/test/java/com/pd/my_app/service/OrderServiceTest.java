package com.pd.my_app.service;

import com.pd.my_app.dto.OrderDTO;
import com.pd.my_app.dto.OrderRequest;
import com.pd.my_app.entity.*;
import com.pd.my_app.exception.*;
import com.pd.my_app.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("OrderService Tests")
class OrderServiceTest {

    @Mock
    private OrderRepository orderRepository;

    @Mock
    private CartRepository cartRepository;

    @Mock
    private CartItemRepository cartItemRepository;

    @Mock
    private UserRepository userRepository;

    @Mock
    private ProductRepository productRepository;

    @InjectMocks
    private OrderService orderService;

    private User testUser;
    private Product testProduct;
    private Cart testCart;
    private CartItem testCartItem;
    private Order testOrder;
    private OrderRequest testOrderRequest;

    @BeforeEach
    void setUp() {
        testUser = new User("John Doe", "john@test.com", "1234567890");
        testUser.setId(1L);

        testProduct = new Product("Laptop", "Test laptop", 
                                  new BigDecimal("999.99"), 50);
        testProduct.setId(1L);
        testProduct.setIsActive(true);

        testCart = new Cart(testUser);
        testCart.setId(1L);
        testCart.setItems(new ArrayList<>());

        testCartItem = new CartItem(testCart, testProduct, 2);
        testCartItem.setId(1L);
        testCart.addItem(testCartItem);

        testOrder = new Order(testUser, "123 Main St", "New York", 
                             "NY", "10001", "USA");
        testOrder.setId(1L);
        testOrder.setOrderNumber("ORD-123456789");
        testOrder.setStatus(OrderStatus.PENDING);

        testOrderRequest = new OrderRequest();
        testOrderRequest.setShippingAddress("123 Main St");
        testOrderRequest.setShippingCity("New York");
        testOrderRequest.setShippingState("NY");
        testOrderRequest.setShippingPostalCode("10001");
        testOrderRequest.setShippingCountry("USA");
        testOrderRequest.setPhoneNumber("1234567890");
        testOrderRequest.setPaymentMethod("Credit Card");
    }

    @Test
    @DisplayName("Should place order successfully")
    void testPlaceOrder() {
        // Given
        Long userId = 1L;

        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(cartRepository.findByUserIdWithItems(userId)).thenReturn(Optional.of(testCart));
        when(productRepository.save(any(Product.class))).thenReturn(testProduct);
        when(orderRepository.save(any(Order.class))).thenReturn(testOrder);
        doNothing().when(cartItemRepository).deleteByCartId(testCart.getId());
        when(cartRepository.save(any(Cart.class))).thenReturn(testCart);

        // When
        OrderDTO result = orderService.placeOrder(userId, testOrderRequest);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getOrderNumber()).isEqualTo("ORD-123456789");
        assertThat(result.getStatus()).isEqualTo(OrderStatus.PENDING);
        verify(userRepository).findById(userId);
        verify(cartRepository).findByUserIdWithItems(userId);
        verify(productRepository, times(1)).save(any(Product.class));
        verify(orderRepository).save(any(Order.class));
        verify(cartItemRepository).deleteByCartId(testCart.getId());
    }

    @Test
    @DisplayName("Should throw exception when user not found for order")
    void testPlaceOrderUserNotFound() {
        // Given
        Long userId = 999L;
        when(userRepository.findById(userId)).thenReturn(Optional.empty());

        // When/Then
        assertThatThrownBy(() -> orderService.placeOrder(userId, testOrderRequest))
                .isInstanceOf(UserNotFoundException.class);

        verify(userRepository).findById(userId);
        verify(orderRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should throw exception when cart not found for order")
    void testPlaceOrderCartNotFound() {
        // Given
        Long userId = 1L;
        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(cartRepository.findByUserIdWithItems(userId)).thenReturn(Optional.empty());

        // When/Then
        assertThatThrownBy(() -> orderService.placeOrder(userId, testOrderRequest))
                .isInstanceOf(CartNotFoundException.class);

        verify(cartRepository).findByUserIdWithItems(userId);
        verify(orderRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should throw exception when cart is empty")
    void testPlaceOrderEmptyCart() {
        // Given
        Long userId = 1L;
        testCart.clearCart();

        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(cartRepository.findByUserIdWithItems(userId)).thenReturn(Optional.of(testCart));

        // When/Then
        assertThatThrownBy(() -> orderService.placeOrder(userId, testOrderRequest))
                .isInstanceOf(InvalidOrderException.class)
                .hasMessageContaining("empty cart");

        verify(orderRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should throw exception when insufficient stock during order")
    void testPlaceOrderInsufficientStock() {
        // Given
        Long userId = 1L;
        testProduct.setStockQuantity(1); // Less than cart item quantity (2)

        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(cartRepository.findByUserIdWithItems(userId)).thenReturn(Optional.of(testCart));

        // When/Then
        assertThatThrownBy(() -> orderService.placeOrder(userId, testOrderRequest))
                .isInstanceOf(InsufficientStockException.class);

        verify(orderRepository, never()).save(any());
        verify(productRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should get order by ID successfully")
    void testGetOrderById() {
        // Given
        Long orderId = 1L;
        Long userId = 1L;

        OrderItem orderItem = new OrderItem(testOrder, testProduct, 2);
        testOrder.addItem(orderItem);

        when(orderRepository.findByIdWithItems(orderId)).thenReturn(Optional.of(testOrder));

        // When
        OrderDTO result = orderService.getOrderById(orderId, userId);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getId()).isEqualTo(orderId);
        assertThat(result.getItems()).isNotEmpty();
        verify(orderRepository).findByIdWithItems(orderId);
    }

    @Test
    @DisplayName("Should throw exception when order not found")
    void testGetOrderByIdNotFound() {
        // Given
        Long orderId = 999L;
        Long userId = 1L;

        when(orderRepository.findByIdWithItems(orderId)).thenReturn(Optional.empty());

        // When/Then
        assertThatThrownBy(() -> orderService.getOrderById(orderId, userId))
                .isInstanceOf(OrderNotFoundException.class);

        verify(orderRepository).findByIdWithItems(orderId);
    }

    @Test
    @DisplayName("Should throw exception when accessing other user's order")
    void testGetOrderByIdAccessDenied() {
        // Given
        Long orderId = 1L;
        Long userId = 999L; // Different user

        when(orderRepository.findByIdWithItems(orderId)).thenReturn(Optional.of(testOrder));

        // When/Then
        assertThatThrownBy(() -> orderService.getOrderById(orderId, userId))
                .isInstanceOf(OrderNotFoundException.class)
                .hasMessageContaining("access denied");

        verify(orderRepository).findByIdWithItems(orderId);
    }

    @Test
    @DisplayName("Should get user orders with pagination")
    void testGetUserOrders() {
        // Given
        Long userId = 1L;
        Pageable pageable = PageRequest.of(0, 10);
        List<Order> orders = Arrays.asList(testOrder);
        Page<Order> orderPage = new PageImpl<>(orders, pageable, 1);

        when(orderRepository.findByUserId(userId, pageable)).thenReturn(orderPage);

        // When
        Page<OrderDTO> result = orderService.getUserOrders(userId, pageable);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getContent()).hasSize(1);
        verify(orderRepository).findByUserId(userId, pageable);
    }

    @Test
    @DisplayName("Should get order by order number successfully")
    void testGetOrderByOrderNumber() {
        // Given
        String orderNumber = "ORD-123456789";
        Long userId = 1L;

        when(orderRepository.findByOrderNumber(orderNumber)).thenReturn(Optional.of(testOrder));

        // When
        OrderDTO result = orderService.getOrderByOrderNumber(orderNumber, userId);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getOrderNumber()).isEqualTo(orderNumber);
        verify(orderRepository).findByOrderNumber(orderNumber);
    }

    @Test
    @DisplayName("Should throw exception when order number not found")
    void testGetOrderByOrderNumberNotFound() {
        // Given
        String orderNumber = "ORD-999999999";
        Long userId = 1L;

        when(orderRepository.findByOrderNumber(orderNumber)).thenReturn(Optional.empty());

        // When/Then
        assertThatThrownBy(() -> orderService.getOrderByOrderNumber(orderNumber, userId))
                .isInstanceOf(OrderNotFoundException.class);

        verify(orderRepository).findByOrderNumber(orderNumber);
    }

    @Test
    @DisplayName("Should update order status successfully")
    void testUpdateOrderStatus() {
        // Given
        Long orderId = 1L;
        OrderStatus newStatus = OrderStatus.SHIPPED;

        when(orderRepository.findById(orderId)).thenReturn(Optional.of(testOrder));
        when(orderRepository.save(any(Order.class))).thenReturn(testOrder);

        // When
        OrderDTO result = orderService.updateOrderStatus(orderId, newStatus);

        // Then
        assertThat(result).isNotNull();
        verify(orderRepository).findById(orderId);
        verify(orderRepository).save(any(Order.class));
    }

    @Test
    @DisplayName("Should update payment status when order delivered")
    void testUpdateOrderStatusToDelivered() {
        // Given
        Long orderId = 1L;
        OrderStatus newStatus = OrderStatus.DELIVERED;

        when(orderRepository.findById(orderId)).thenReturn(Optional.of(testOrder));
        when(orderRepository.save(any(Order.class))).thenAnswer(invocation -> {
            Order order = invocation.getArgument(0);
            assertThat(order.getPaymentStatus()).isEqualTo("COMPLETED");
            assertThat(order.getDeliveredAt()).isNotNull();
            return order;
        });

        // When
        OrderDTO result = orderService.updateOrderStatus(orderId, newStatus);

        // Then
        assertThat(result).isNotNull();
        verify(orderRepository).save(any(Order.class));
    }

    @Test
    @DisplayName("Should cancel order successfully")
    void testCancelOrder() {
        // Given
        Long orderId = 1L;
        Long userId = 1L;

        OrderItem orderItem = new OrderItem(testOrder, testProduct, 2);
        testOrder.addItem(orderItem);

        when(orderRepository.findByIdWithItems(orderId)).thenReturn(Optional.of(testOrder));
        when(productRepository.save(any(Product.class))).thenReturn(testProduct);
        when(orderRepository.save(any(Order.class))).thenReturn(testOrder);

        // When
        OrderDTO result = orderService.cancelOrder(orderId, userId);

        // Then
        assertThat(result).isNotNull();
        verify(orderRepository).findByIdWithItems(orderId);
        verify(productRepository, times(1)).save(any(Product.class));
        verify(orderRepository).save(any(Order.class));
    }

    @Test
    @DisplayName("Should throw exception when cancelling non-cancellable order")
    void testCancelOrderNotCancellable() {
        // Given
        Long orderId = 1L;
        Long userId = 1L;
        testOrder.setStatus(OrderStatus.SHIPPED); // Cannot cancel shipped orders

        when(orderRepository.findByIdWithItems(orderId)).thenReturn(Optional.of(testOrder));

        // When/Then
        assertThatThrownBy(() -> orderService.cancelOrder(orderId, userId))
                .isInstanceOf(InvalidOrderException.class)
                .hasMessageContaining("cannot be cancelled");

        verify(orderRepository).findByIdWithItems(orderId);
        verify(productRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should throw exception when cancelling other user's order")
    void testCancelOrderAccessDenied() {
        // Given
        Long orderId = 1L;
        Long userId = 999L; // Different user

        when(orderRepository.findByIdWithItems(orderId)).thenReturn(Optional.of(testOrder));

        // When/Then
        assertThatThrownBy(() -> orderService.cancelOrder(orderId, userId))
                .isInstanceOf(OrderNotFoundException.class)
                .hasMessageContaining("access denied");

        verify(orderRepository).findByIdWithItems(orderId);
        verify(orderRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should restore inventory when cancelling order")
    void testCancelOrderRestoresInventory() {
        // Given
        Long orderId = 1L;
        Long userId = 1L;
        Integer originalStock = testProduct.getStockQuantity();

        OrderItem orderItem = new OrderItem(testOrder, testProduct, 2);
        testOrder.addItem(orderItem);

        when(orderRepository.findByIdWithItems(orderId)).thenReturn(Optional.of(testOrder));
        when(productRepository.save(any(Product.class))).thenAnswer(invocation -> {
            Product product = invocation.getArgument(0);
            assertThat(product.getStockQuantity()).isEqualTo(originalStock + 2);
            return product;
        });
        when(orderRepository.save(any(Order.class))).thenReturn(testOrder);

        // When
        orderService.cancelOrder(orderId, userId);

        // Then
        verify(productRepository).save(any(Product.class));
    }
}
