package com.pd.my_app.service;

import com.pd.my_app.dto.CartDTO;
import com.pd.my_app.entity.*;
import com.pd.my_app.exception.*;
import com.pd.my_app.repository.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Optional;

import static org.assertj.core.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
@DisplayName("CartService Tests")
class CartServiceTest {

    @Mock
    private CartRepository cartRepository;

    @Mock
    private CartItemRepository cartItemRepository;

    @Mock
    private ProductRepository productRepository;

    @Mock
    private UserRepository userRepository;

    @InjectMocks
    private CartService cartService;

    private User testUser;
    private Product testProduct;
    private Cart testCart;
    private CartItem testCartItem;

    @BeforeEach
    void setUp() {
        testUser = new User("John Doe", "john@test.com", "1234567890");
        testUser.setId(1L);

        testProduct = new Product("Laptop", "Test laptop", 
                                  new BigDecimal("999.99"), 50);
        testProduct.setId(1L);
        testProduct.setIsActive(true);

        testCart = new Cart(testUser);
        testCart.setId(1L);
        testCart.setItems(new ArrayList<>());

        testCartItem = new CartItem(testCart, testProduct, 2);
        testCartItem.setId(1L);
    }

    @Test
    @DisplayName("Should get cart by user ID")
    void testGetCartByUserId() {
        // Given
        Long userId = 1L;
        when(cartRepository.findByUserIdWithItems(userId)).thenReturn(Optional.of(testCart));

        // When
        CartDTO result = cartService.getCartByUserId(userId);

        // Then
        assertThat(result).isNotNull();
        assertThat(result.getUserId()).isEqualTo(userId);
        verify(cartRepository).findByUserIdWithItems(userId);
    }

    @Test
    @DisplayName("Should create cart when not found")
    void testGetCartByUserIdCreateNew() {
        // Given
        Long userId = 1L;
        when(cartRepository.findByUserIdWithItems(userId)).thenReturn(Optional.empty());
        when(userRepository.findById(userId)).thenReturn(Optional.of(testUser));
        when(cartRepository.save(any(Cart.class))).thenReturn(testCart);

        // When
        CartDTO result = cartService.getCartByUserId(userId);

        // Then
        assertThat(result).isNotNull();
        verify(cartRepository).findByUserIdWithItems(userId);
        verify(userRepository).findById(userId);
        verify(cartRepository).save(any(Cart.class));
    }

    @Test
    @DisplayName("Should add product to cart successfully")
    void testAddToCart() {
        // Given
        Long userId = 1L;
        Long productId = 1L;
        Integer quantity = 2;

        when(cartRepository.findByUserIdWithItems(userId)).thenReturn(Optional.of(testCart));
        when(productRepository.findById(productId)).thenReturn(Optional.of(testProduct));
        when(cartItemRepository.findByCartIdAndProductId(testCart.getId(), productId))
                .thenReturn(Optional.empty());
        when(cartItemRepository.save(any(CartItem.class))).thenReturn(testCartItem);
        when(cartRepository.save(any(Cart.class))).thenReturn(testCart);

        // When
        CartDTO result = cartService.addToCart(userId, productId, quantity);

        // Then
        assertThat(result).isNotNull();
        verify(productRepository).findById(productId);
        verify(cartItemRepository).findByCartIdAndProductId(testCart.getId(), productId);
        verify(cartItemRepository).save(any(CartItem.class));
        verify(cartRepository).save(any(Cart.class));
    }

    @Test
    @DisplayName("Should update quantity when product already in cart")
    void testAddToCartExistingItem() {
        // Given
        Long userId = 1L;
        Long productId = 1L;
        Integer additionalQuantity = 3;

        testCart.addItem(testCartItem);

        when(cartRepository.findByUserIdWithItems(userId)).thenReturn(Optional.of(testCart));
        when(productRepository.findById(productId)).thenReturn(Optional.of(testProduct));
        when(cartItemRepository.findByCartIdAndProductId(testCart.getId(), productId))
                .thenReturn(Optional.of(testCartItem));
        when(cartRepository.save(any(Cart.class))).thenReturn(testCart);

        // When
        CartDTO result = cartService.addToCart(userId, productId, additionalQuantity);

        // Then
        assertThat(result).isNotNull();
        verify(cartItemRepository).findByCartIdAndProductId(testCart.getId(), productId);
        verify(cartRepository).save(any(Cart.class));
    }

    @Test
    @DisplayName("Should throw exception when adding inactive product")
    void testAddToCartInactiveProduct() {
        // Given
        Long userId = 1L;
        Long productId = 1L;
        testProduct.setIsActive(false);

        when(cartRepository.findByUserIdWithItems(userId)).thenReturn(Optional.of(testCart));
        when(productRepository.findById(productId)).thenReturn(Optional.of(testProduct));

        // When/Then
        assertThatThrownBy(() -> cartService.addToCart(userId, productId, 1))
                .isInstanceOf(ProductNotFoundException.class)
                .hasMessageContaining("not available");

        verify(productRepository).findById(productId);
        verify(cartItemRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should throw exception when insufficient stock")
    void testAddToCartInsufficientStock() {
        // Given
        Long userId = 1L;
        Long productId = 1L;
        Integer quantity = 100; // More than available stock

        when(cartRepository.findByUserIdWithItems(userId)).thenReturn(Optional.of(testCart));
        when(productRepository.findById(productId)).thenReturn(Optional.of(testProduct));
        when(cartItemRepository.findByCartIdAndProductId(testCart.getId(), productId))
                .thenReturn(Optional.empty());

        // When/Then
        assertThatThrownBy(() -> cartService.addToCart(userId, productId, quantity))
                .isInstanceOf(InsufficientStockException.class);

        verify(productRepository).findById(productId);
        verify(cartItemRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should throw exception when product not found")
    void testAddToCartProductNotFound() {
        // Given
        Long userId = 1L;
        Long productId = 999L;

        when(cartRepository.findByUserIdWithItems(userId)).thenReturn(Optional.of(testCart));
        when(productRepository.findById(productId)).thenReturn(Optional.empty());

        // When/Then
        assertThatThrownBy(() -> cartService.addToCart(userId, productId, 1))
                .isInstanceOf(ProductNotFoundException.class);

        verify(productRepository).findById(productId);
    }

    @Test
    @DisplayName("Should update cart item quantity successfully")
    void testUpdateCartItemQuantity() {
        // Given
        Long userId = 1L;
        Long productId = 1L;
        Integer newQuantity = 5;

        testCart.addItem(testCartItem);

        when(cartRepository.findByUserIdWithItems(userId)).thenReturn(Optional.of(testCart));
        when(cartItemRepository.findByCartIdAndProductId(testCart.getId(), productId))
                .thenReturn(Optional.of(testCartItem));
        when(cartRepository.save(any(Cart.class))).thenReturn(testCart);

        // When
        CartDTO result = cartService.updateCartItemQuantity(userId, productId, newQuantity);

        // Then
        assertThat(result).isNotNull();
        verify(cartItemRepository).findByCartIdAndProductId(testCart.getId(), productId);
        verify(cartRepository).save(any(Cart.class));
    }

    @Test
    @DisplayName("Should throw exception when updating with insufficient stock")
    void testUpdateCartItemQuantityInsufficientStock() {
        // Given
        Long userId = 1L;
        Long productId = 1L;
        Integer newQuantity = 100;

        testCart.addItem(testCartItem);

        when(cartRepository.findByUserIdWithItems(userId)).thenReturn(Optional.of(testCart));
        when(cartItemRepository.findByCartIdAndProductId(testCart.getId(), productId))
                .thenReturn(Optional.of(testCartItem));

        // When/Then
        assertThatThrownBy(() -> cartService.updateCartItemQuantity(userId, productId, newQuantity))
                .isInstanceOf(InsufficientStockException.class);

        verify(cartRepository, never()).save(any());
    }

    @Test
    @DisplayName("Should throw exception when cart not found for update")
    void testUpdateCartItemQuantityCartNotFound() {
        // Given
        Long userId = 999L;
        when(cartRepository.findByUserIdWithItems(userId)).thenReturn(Optional.empty());

        // When/Then
        assertThatThrownBy(() -> cartService.updateCartItemQuantity(userId, 1L, 5))
                .isInstanceOf(CartNotFoundException.class);
    }

    @Test
    @DisplayName("Should remove item from cart successfully")
    void testRemoveFromCart() {
        // Given
        Long userId = 1L;
        Long productId = 1L;

        testCart.addItem(testCartItem);

        when(cartRepository.findByUserIdWithItems(userId)).thenReturn(Optional.of(testCart));
        when(cartItemRepository.findByCartIdAndProductId(testCart.getId(), productId))
                .thenReturn(Optional.of(testCartItem));
        doNothing().when(cartItemRepository).delete(testCartItem);
        when(cartRepository.save(any(Cart.class))).thenReturn(testCart);

        // When
        CartDTO result = cartService.removeFromCart(userId, productId);

        // Then
        assertThat(result).isNotNull();
        verify(cartItemRepository).findByCartIdAndProductId(testCart.getId(), productId);
        verify(cartItemRepository).delete(testCartItem);
        verify(cartRepository).save(any(Cart.class));
    }

    @Test
    @DisplayName("Should throw exception when removing non-existent item")
    void testRemoveFromCartItemNotFound() {
        // Given
        Long userId = 1L;
        Long productId = 999L;

        when(cartRepository.findByUserIdWithItems(userId)).thenReturn(Optional.of(testCart));
        when(cartItemRepository.findByCartIdAndProductId(testCart.getId(), productId))
                .thenReturn(Optional.empty());

        // When/Then
        assertThatThrownBy(() -> cartService.removeFromCart(userId, productId))
                .isInstanceOf(ProductNotFoundException.class)
                .hasMessageContaining("not found in cart");

        verify(cartItemRepository, never()).delete(any());
    }

    @Test
    @DisplayName("Should clear cart successfully")
    void testClearCart() {
        // Given
        Long userId = 1L;

        when(cartRepository.findByUserId(userId)).thenReturn(Optional.of(testCart));
        doNothing().when(cartItemRepository).deleteByCartId(testCart.getId());
        when(cartRepository.save(any(Cart.class))).thenReturn(testCart);

        // When
        cartService.clearCart(userId);

        // Then
        verify(cartRepository).findByUserId(userId);
        verify(cartItemRepository).deleteByCartId(testCart.getId());
        verify(cartRepository).save(any(Cart.class));
    }

    @Test
    @DisplayName("Should throw exception when clearing non-existent cart")
    void testClearCartNotFound() {
        // Given
        Long userId = 999L;
        when(cartRepository.findByUserId(userId)).thenReturn(Optional.empty());

        // When/Then
        assertThatThrownBy(() -> cartService.clearCart(userId))
                .isInstanceOf(CartNotFoundException.class);

        verify(cartItemRepository, never()).deleteByCartId(any());
    }
}
