package com.pd.my_app.service;

import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.UUID;

@Service
public class FileStorageService {

    private final Path fileStorageLocation;

    public FileStorageService() {
        // Create uploads directory in project root
        this.fileStorageLocation = Paths.get("uploads/profile-pictures")
                .toAbsolutePath().normalize();

        try {
            Files.createDirectories(this.fileStorageLocation);
        } catch (Exception ex) {
            throw new RuntimeException("Could not create the directory where the uploaded files will be stored.", ex);
        }
    }

    public String storeFile(MultipartFile file) {
        // Generate unique filename
        String originalFilename = file.getOriginalFilename();
        String fileExtension = "";
        if (originalFilename != null && originalFilename.contains(".")) {
            fileExtension = originalFilename.substring(originalFilename.lastIndexOf("."));
        }
        
        String fileName = UUID.randomUUID().toString() + fileExtension;

        try {
            // Check if file is empty
            if (file.isEmpty()) {
                throw new RuntimeException("Failed to store empty file " + fileName);
            }

            // Check file extension
            if (!isValidImageExtension(fileExtension)) {
                throw new RuntimeException("Invalid file type. Only JPG, JPEG, PNG, and GIF are allowed.");
            }

            // Copy file to the target location (Replacing existing file with the same name)
            Path targetLocation = this.fileStorageLocation.resolve(fileName);
            Files.copy(file.getInputStream(), targetLocation, StandardCopyOption.REPLACE_EXISTING);

            return fileName;
        } catch (IOException ex) {
            throw new RuntimeException("Could not store file " + fileName + ". Please try again!", ex);
        }
    }

    public void deleteFile(String fileName) {
        try {
            Path filePath = this.fileStorageLocation.resolve(fileName).normalize();
            Files.deleteIfExists(filePath);
        } catch (IOException ex) {
            // Log error but don't throw exception
            System.err.println("Could not delete file: " + fileName);
        }
    }

    private boolean isValidImageExtension(String extension) {
        String lowerCaseExtension = extension.toLowerCase();
        return lowerCaseExtension.equals(".jpg") || 
               lowerCaseExtension.equals(".jpeg") || 
               lowerCaseExtension.equals(".png") || 
               lowerCaseExtension.equals(".gif");
    }

    public Path getFileStorageLocation() {
        return fileStorageLocation;
    }
}
