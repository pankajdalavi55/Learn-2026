package com.pd.my_app.service;

import com.pd.my_app.dto.UserDTO;
import com.pd.my_app.entity.User;
import com.pd.my_app.exception.DuplicateEmailException;
import com.pd.my_app.exception.UserNotFoundException;
import com.pd.my_app.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class UserService {

    private static final Logger logger = LoggerFactory.getLogger(UserService.class);

    private final UserRepository userRepository;

    @Autowired
    public UserService(UserRepository userRepository) {
        this.userRepository = userRepository;
    }

    public UserDTO createUser(UserDTO userDTO) {
        logger.debug("Creating new user with email: {}", userDTO.getEmail());
        
        if (userRepository.existsByEmail(userDTO.getEmail())) {
            logger.warn("Attempt to create user with duplicate email: {}", userDTO.getEmail());
            throw new DuplicateEmailException(userDTO.getEmail());
        }

        User user = mapToEntity(userDTO);
        User savedUser = userRepository.save(user);
        
        logger.info("User created successfully with id: {}", savedUser.getId());
        return mapToDTO(savedUser);
    }

    @Transactional(readOnly = true)
    public UserDTO getUserById(Long id) {
        logger.debug("Fetching user with id: {}", id);
        
        User user = userRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("User not found with id: {}", id);
                    return new UserNotFoundException(id);
                });
        
        logger.debug("User found: {}", user.getEmail());
        return mapToDTO(user);
    }

    @Transactional(readOnly = true)
    public List<UserDTO> getAllUsers() {
        logger.debug("Fetching all users");
        
        List<User> users = userRepository.findAll();
        logger.info("Found {} users", users.size());
        
        return users.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<UserDTO> getActiveUsers() {
        logger.debug("Fetching active users");
        
        List<User> users = userRepository.findByIsActive(true);
        logger.info("Found {} active users", users.size());
        
        return users.stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public UserDTO updateUser(Long id, UserDTO userDTO) {
        logger.debug("Updating user with id: {}", id);
        
        User existingUser = userRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("User not found with id: {} for update", id);
                    return new UserNotFoundException(id);
                });

        // Check if email is being changed and if new email already exists
        if (!existingUser.getEmail().equals(userDTO.getEmail()) &&
                userRepository.existsByEmail(userDTO.getEmail())) {
            logger.warn("Attempt to update user with duplicate email: {}", userDTO.getEmail());
            throw new DuplicateEmailException(userDTO.getEmail());
        }

        existingUser.setName(userDTO.getName());
        existingUser.setEmail(userDTO.getEmail());
        existingUser.setPhone(userDTO.getPhone());
        if (userDTO.getIsActive() != null) {
            existingUser.setIsActive(userDTO.getIsActive());
        }

        User updatedUser = userRepository.save(existingUser);
        logger.info("User updated successfully with id: {}", updatedUser.getId());
        
        return mapToDTO(updatedUser);
    }

    public void deleteUser(Long id) {
        logger.debug("Deleting user with id: {}", id);
        
        if (!userRepository.existsById(id)) {
            logger.error("User not found with id: {} for deletion", id);
            throw new UserNotFoundException(id);
        }

        userRepository.deleteById(id);
        logger.info("User deleted successfully with id: {}", id);
    }

    public void deactivateUser(Long id) {
        logger.debug("Deactivating user with id: {}", id);
        
        User user = userRepository.findById(id)
                .orElseThrow(() -> {
                    logger.error("User not found with id: {} for deactivation", id);
                    return new UserNotFoundException(id);
                });

        user.setIsActive(false);
        userRepository.save(user);
        logger.info("User deactivated successfully with id: {}", id);
    }

    // Mapping methods
    private UserDTO mapToDTO(User user) {
        return new UserDTO(
                user.getId(),
                user.getName(),
                user.getEmail(),
                user.getPhone(),
                user.getProfilePictureUrl(),
                user.getIsActive(),
                user.getCreatedAt(),
                user.getUpdatedAt()
        );
    }

    private User mapToEntity(UserDTO userDTO) {
        User user = new User();
        user.setName(userDTO.getName());
        user.setEmail(userDTO.getEmail());
        user.setPhone(userDTO.getPhone());
        user.setProfilePictureUrl(userDTO.getProfilePictureUrl());
        if (userDTO.getIsActive() != null) {
            user.setIsActive(userDTO.getIsActive());
        }
        return user;
    }
}
