package com.pd.my_app.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * Application-Level Configuration Properties
 * Binds application-specific properties from application.yaml
 */
@Configuration
@ConfigurationProperties(prefix = "file.upload")
public class AppProperties {

    private String dir = "uploads";

    public AppProperties() {
    }

    public String getDir() {
        return dir;
    }

    public void setDir(String dir) {
        this.dir = dir;
    }
}
