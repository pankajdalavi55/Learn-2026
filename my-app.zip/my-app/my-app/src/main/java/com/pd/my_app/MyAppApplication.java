package com.pd.my_app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.cache.annotation.EnableCaching;

/**
 * Main Application Class for E-Commerce Platform
 * 
 * Features:
 * - Role-Based Access Control (RBAC) with JWT authentication
 * - Product catalog with categories and inventory management
 * - Shopping cart and order management
 * - User management with multiple roles (ADMIN, MANAGER, SUPPORT, VENDOR, CUSTOMER)
 * - File upload for profile pictures and product images
 * - RESTful API with Swagger documentation
 * - Caching for improved performance
 * - Connection pooling with HikariCP
 * - Comprehensive error handling and validation
 */
@SpringBootApplication
@EnableConfigurationProperties
public class MyAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyAppApplication.class, args);
	}

}
