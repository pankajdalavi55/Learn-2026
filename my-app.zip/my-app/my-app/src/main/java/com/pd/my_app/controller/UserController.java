package com.pd.my_app.controller;

import com.pd.my_app.dto.UserDTO;
import com.pd.my_app.entity.User;
import com.pd.my_app.repository.UserRepository;
import com.pd.my_app.security.JwtTokenUtil;
import com.pd.my_app.service.FileStorageService;
import com.pd.my_app.service.UserService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/users")
public class UserController {

    private static final Logger logger = LoggerFactory.getLogger(UserController.class);

    private final UserService userService;
    
    @Autowired
    private FileStorageService fileStorageService;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @Autowired
    public UserController(UserService userService) {
        this.userService = userService;
    }

    /**
     * Create a new user
     * POST /api/users
     */
    @PostMapping
    public ResponseEntity<UserDTO> createUser(@Valid @RequestBody UserDTO userDTO) {
        logger.info("REST request to create user: {}", userDTO.getEmail());
        UserDTO createdUser = userService.createUser(userDTO);
        return new ResponseEntity<>(createdUser, HttpStatus.CREATED);
    }

    /**
     * Get user by ID
     * GET /api/users/{id}
     */
    @GetMapping("/{id}")
    public ResponseEntity<UserDTO> getUserById(@PathVariable Long id) {
        logger.info("REST request to get user by id: {}", id);
        UserDTO user = userService.getUserById(id);
        return ResponseEntity.ok(user);
    }

    /**
     * Get all users
     * GET /api/users
     */
    @GetMapping
    public ResponseEntity<List<UserDTO>> getAllUsers(@RequestParam(required = false) Boolean active) {
        logger.info("REST request to get all users, active filter: {}", active);
        
        List<UserDTO> users;
        if (active != null && active) {
            users = userService.getActiveUsers();
        } else {
            users = userService.getAllUsers();
        }
        
        return ResponseEntity.ok(users);
    }

    /**
     * Update user by ID
     * PUT /api/users/{id}
     */
    @PutMapping("/{id}")
    public ResponseEntity<UserDTO> updateUser(
            @PathVariable Long id,
            @Valid @RequestBody UserDTO userDTO) {
        logger.info("REST request to update user with id: {}", id);
        UserDTO updatedUser = userService.updateUser(id, userDTO);
        return ResponseEntity.ok(updatedUser);
    }

    /**
     * Delete user by ID
     * DELETE /api/users/{id}
     */
    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteUser(@PathVariable Long id) {
        logger.info("REST request to delete user with id: {}", id);
        userService.deleteUser(id);
        return ResponseEntity.noContent().build();
    }

    /**
     * Deactivate user by ID (soft delete)
     * PATCH /api/users/{id}/deactivate
     */
    @PatchMapping("/{id}/deactivate")
    public ResponseEntity<Void> deactivateUser(@PathVariable Long id) {
        logger.info("REST request to deactivate user with id: {}", id);
        userService.deactivateUser(id);
        return ResponseEntity.ok().build();
    }

    /**
     * Upload profile picture
     * POST /api/users/profile-picture
     */
    @PostMapping("/profile-picture")
    public ResponseEntity<Map<String, String>> uploadProfilePicture(
            @RequestHeader("Authorization") String token,
            @RequestParam("file") MultipartFile file) {
        logger.info("REST request to upload profile picture");
        
        try {
            // Get user ID from token
            String jwt = token.replace("Bearer ", "");
            Long userId = jwtTokenUtil.extractUserId(jwt);
            
            // Get user
            User user = userRepository.findById(userId)
                    .orElseThrow(() -> new RuntimeException("User not found"));
            
            // Delete old profile picture if exists
            if (user.getProfilePictureUrl() != null && !user.getProfilePictureUrl().isEmpty()) {
                // Extract filename from URL
                String oldFileName = user.getProfilePictureUrl().substring(user.getProfilePictureUrl().lastIndexOf("/") + 1);
                fileStorageService.deleteFile(oldFileName);
            }
            
            // Store new file
            String fileName = fileStorageService.storeFile(file);
            String fileUrl = "/uploads/profile-pictures/" + fileName;
            
            // Update user profile picture URL
            user.setProfilePictureUrl(fileUrl);
            userRepository.save(user);
            
            Map<String, String> response = new HashMap<>();
            response.put("profilePictureUrl", fileUrl);
            response.put("message", "Profile picture uploaded successfully");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error uploading profile picture: ", e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }

    /**
     * Delete profile picture
     * DELETE /api/users/profile-picture
     */
    @DeleteMapping("/profile-picture")
    public ResponseEntity<Map<String, String>> deleteProfilePicture(
            @RequestHeader("Authorization") String token) {
        logger.info("REST request to delete profile picture");
        
        try {
            // Get user ID from token
            String jwt = token.replace("Bearer ", "");
            Long userId = jwtTokenUtil.extractUserId(jwt);
            
            // Get user
            User user = userRepository.findById(userId)
                    .orElseThrow(() -> new RuntimeException("User not found"));
            
            // Delete profile picture file if exists
            if (user.getProfilePictureUrl() != null && !user.getProfilePictureUrl().isEmpty()) {
                String fileName = user.getProfilePictureUrl().substring(user.getProfilePictureUrl().lastIndexOf("/") + 1);
                fileStorageService.deleteFile(fileName);
            }
            
            // Remove profile picture URL from user
            user.setProfilePictureUrl(null);
            userRepository.save(user);
            
            Map<String, String> response = new HashMap<>();
            response.put("message", "Profile picture deleted successfully");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Error deleting profile picture: ", e);
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("error", e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
        }
    }
}
