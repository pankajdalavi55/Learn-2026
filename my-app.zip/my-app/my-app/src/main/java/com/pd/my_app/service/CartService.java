package com.pd.my_app.service;

import com.pd.my_app.dto.CartDTO;
import com.pd.my_app.dto.CartItemDTO;
import com.pd.my_app.entity.Cart;
import com.pd.my_app.entity.CartItem;
import com.pd.my_app.entity.Product;
import com.pd.my_app.entity.User;
import com.pd.my_app.exception.CartNotFoundException;
import com.pd.my_app.exception.InsufficientStockException;
import com.pd.my_app.exception.ProductNotFoundException;
import com.pd.my_app.exception.UserNotFoundException;
import com.pd.my_app.repository.CartItemRepository;
import com.pd.my_app.repository.CartRepository;
import com.pd.my_app.repository.ProductRepository;
import com.pd.my_app.repository.UserRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.Optional;
import java.util.stream.Collectors;

@Service
@Transactional
public class CartService {

    private static final Logger logger = LoggerFactory.getLogger(CartService.class);

    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;
    private final ProductRepository productRepository;
    private final UserRepository userRepository;

    @Autowired
    public CartService(CartRepository cartRepository, CartItemRepository cartItemRepository,
                       ProductRepository productRepository, UserRepository userRepository) {
        this.cartRepository = cartRepository;
        this.cartItemRepository = cartItemRepository;
        this.productRepository = productRepository;
        this.userRepository = userRepository;
    }

    @Transactional(readOnly = true)
    public CartDTO getCartByUserId(Long userId) {
        logger.debug("Fetching cart for user id: {}", userId);
        
        Cart cart = cartRepository.findByUserIdWithItems(userId)
                .orElseGet(() -> {
                    logger.info("Cart not found for user {}. Creating new cart", userId);
                    return createCartForUser(userId);
                });
        
        return mapToDTO(cart);
    }

    public CartDTO addToCart(Long userId, Long productId, Integer quantity) {
        logger.debug("Adding product {} (quantity: {}) to cart for user {}", productId, quantity, userId);
        
        // Get or create cart
        Cart cart = cartRepository.findByUserIdWithItems(userId)
                .orElseGet(() -> createCartForUser(userId));

        // Get product and validate stock
        Product product = productRepository.findById(productId)
                .orElseThrow(() -> new ProductNotFoundException(productId));

        if (!product.getIsActive()) {
            throw new ProductNotFoundException("Product is not available");
        }

        // Check if product already in cart
        Optional<CartItem> existingItem = cartItemRepository.findByCartIdAndProductId(cart.getId(), productId);

        if (existingItem.isPresent()) {
            CartItem cartItem = existingItem.get();
            Integer newQuantity = cartItem.getQuantity() + quantity;
            
            // Validate stock for new quantity
            if (!product.hasEnoughStock(newQuantity)) {
                throw new InsufficientStockException(product.getName(), newQuantity, product.getStockQuantity());
            }
            
            cartItem.updateQuantity(newQuantity);
            logger.info("Updated cart item quantity to {}", newQuantity);
        } else {
            // Validate stock
            if (!product.hasEnoughStock(quantity)) {
                throw new InsufficientStockException(product.getName(), quantity, product.getStockQuantity());
            }
            
            CartItem newItem = new CartItem(cart, product, quantity);
            cart.addItem(newItem);
            cartItemRepository.save(newItem);
            logger.info("Added new item to cart");
        }

        cart.recalculateTotal();
        Cart savedCart = cartRepository.save(cart);
        
        logger.info("Cart updated successfully for user {}", userId);
        return mapToDTO(savedCart);
    }

    public CartDTO updateCartItemQuantity(Long userId, Long productId, Integer newQuantity) {
        logger.debug("Updating cart item quantity for user {} - product {}, new quantity: {}", 
                     userId, productId, newQuantity);
        
        Cart cart = cartRepository.findByUserIdWithItems(userId)
                .orElseThrow(() -> new CartNotFoundException(userId));

        CartItem cartItem = cartItemRepository.findByCartIdAndProductId(cart.getId(), productId)
                .orElseThrow(() -> new ProductNotFoundException("Product not found in cart"));

        Product product = cartItem.getProduct();

        // Validate stock
        if (!product.hasEnoughStock(newQuantity)) {
            throw new InsufficientStockException(product.getName(), newQuantity, product.getStockQuantity());
        }

        cartItem.updateQuantity(newQuantity);
        cart.recalculateTotal();
        Cart savedCart = cartRepository.save(cart);
        
        logger.info("Cart item quantity updated successfully");
        return mapToDTO(savedCart);
    }

    public CartDTO removeFromCart(Long userId, Long productId) {
        logger.debug("Removing product {} from cart for user {}", productId, userId);
        
        Cart cart = cartRepository.findByUserIdWithItems(userId)
                .orElseThrow(() -> new CartNotFoundException(userId));

        CartItem cartItem = cartItemRepository.findByCartIdAndProductId(cart.getId(), productId)
                .orElseThrow(() -> new ProductNotFoundException("Product not found in cart"));

        cart.removeItem(cartItem);
        cartItemRepository.delete(cartItem);
        
        cart.recalculateTotal();
        Cart savedCart = cartRepository.save(cart);
        
        logger.info("Product removed from cart successfully");
        return mapToDTO(savedCart);
    }

    public void clearCart(Long userId) {
        logger.debug("Clearing cart for user {}", userId);
        
        Cart cart = cartRepository.findByUserId(userId)
                .orElseThrow(() -> new CartNotFoundException(userId));

        cart.clearCart();
        cartItemRepository.deleteByCartId(cart.getId());
        cartRepository.save(cart);
        
        logger.info("Cart cleared successfully for user {}", userId);
    }

    private Cart createCartForUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException(userId));
        
        Cart cart = new Cart(user);
        return cartRepository.save(cart);
    }

    // Mapping methods
    private CartDTO mapToDTO(Cart cart) {
        CartDTO dto = new CartDTO();
        dto.setId(cart.getId());
        dto.setUserId(cart.getUser().getId());
        dto.setTotalAmount(cart.getTotalAmount());
        dto.setTotalItems(cart.getTotalItems());
        
        dto.setItems(cart.getItems().stream()
                .map(this::mapCartItemToDTO)
                .collect(Collectors.toList()));
        
        return dto;
    }

    private CartItemDTO mapCartItemToDTO(CartItem item) {
        CartItemDTO dto = new CartItemDTO();
        dto.setId(item.getId());
        dto.setProductId(item.getProduct().getId());
        dto.setProductName(item.getProduct().getName());
        dto.setProductImageUrl(item.getProduct().getImageUrl());
        dto.setQuantity(item.getQuantity());
        dto.setPrice(item.getPrice());
        dto.setSubtotal(item.getSubtotal());
        dto.setAvailableStock(item.getProduct().getStockQuantity());
        return dto;
    }
}
