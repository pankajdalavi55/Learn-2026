package com.pd.my_app.config;

import com.pd.my_app.security.CustomUserDetailsService;
import com.pd.my_app.security.JwtAuthenticationFilter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.HttpMethod;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.AuthenticationProvider;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.configuration.AuthenticationConfiguration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import java.util.Arrays;

/**
 * Security Configuration
 * Implements Role-Based Access Control (RBAC) with JWT authentication
 * <p>
 * ROLE HIERARCHY & PERMISSIONS:
 * <p>
 * 1. CUSTOMER (Default Role):
 *    - View products, categories (public access)
 *    - Manage own cart
 *    - Place and view own orders
 *    - View and update own profile
 *    - Cannot access other users' data
 * 
 * 2. VENDOR:
 *    - All CUSTOMER permissions
 *    - Create, update, delete own products
 *    - View own product sales
 *    - Manage inventory for own products
 * 
 * 3. SUPPORT:
 *    - View all users (read-only)
 *    - View all orders (to help customers)
 *    - View all carts (to troubleshoot)
 *    - Cannot modify data
 * 
 * 4. MANAGER:
 *    - All SUPPORT permissions
 *    - Manage categories
 *    - Manage all products and inventory
 *    - View analytics and reports
 *    - Update order statuses
 * 
 * 5. ADMIN (Superuser):
 *    - Full system access
 *    - Manage all users (CRUD)
 *    - Manage all products, categories, orders
 *    - View all carts
 *    - System configuration
 *    - Assign/change user roles
 */
@Configuration
@EnableWebSecurity
@EnableMethodSecurity(prePostEnabled = true)
public class SecurityConfig {

    private final CustomUserDetailsService userDetailsService;
    private final JwtAuthenticationFilter jwtAuthenticationFilter;

    @Autowired
    public SecurityConfig(CustomUserDetailsService userDetailsService, 
                         JwtAuthenticationFilter jwtAuthenticationFilter) {
        this.userDetailsService = userDetailsService;
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
    }

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
            .cors(cors -> cors.configurationSource(corsConfigurationSource()))
            .csrf(AbstractHttpConfigurer::disable)
            .authorizeHttpRequests(auth -> auth
                // Public endpoints - No authentication required
                .requestMatchers("/api/auth/**").permitAll()
                .requestMatchers("/actuator/health").permitAll()
                .requestMatchers("/swagger-ui/**", "/v3/api-docs/**", "/swagger-ui.html").permitAll()
                
                // Product and Category - Public read, restricted write
                .requestMatchers(HttpMethod.GET, "/api/products/**").permitAll()
                .requestMatchers(HttpMethod.GET, "/api/categories/**").permitAll()
                .requestMatchers(HttpMethod.POST, "/api/products/**").hasAnyRole("ADMIN", "MANAGER", "VENDOR")
                .requestMatchers(HttpMethod.PUT, "/api/products/**").hasAnyRole("ADMIN", "MANAGER", "VENDOR")
                .requestMatchers(HttpMethod.DELETE, "/api/products/**").hasAnyRole("ADMIN", "MANAGER")
                
                // Category management - ADMIN and MANAGER only
                .requestMatchers(HttpMethod.POST, "/api/categories/**").hasAnyRole("ADMIN", "MANAGER")
                .requestMatchers(HttpMethod.PUT, "/api/categories/**").hasAnyRole("ADMIN", "MANAGER")
                .requestMatchers(HttpMethod.DELETE, "/api/categories/**").hasAnyRole("ADMIN", "MANAGER")
                
                // User management - Role-based access
                .requestMatchers(HttpMethod.GET, "/api/users").hasAnyRole("ADMIN", "SUPPORT", "MANAGER")
                .requestMatchers(HttpMethod.GET, "/api/users/*").hasAnyRole("ADMIN", "SUPPORT", "MANAGER", "CUSTOMER")
                .requestMatchers(HttpMethod.POST, "/api/users").hasRole("ADMIN")
                .requestMatchers(HttpMethod.PUT, "/api/users/*").hasAnyRole("ADMIN", "CUSTOMER")
                .requestMatchers(HttpMethod.DELETE, "/api/users/*").hasRole("ADMIN")
                
                // User profile picture - Authenticated users can manage their own
                .requestMatchers("/api/users/profile-picture").authenticated()
                
                // User addresses - Users can only manage their own addresses
                .requestMatchers("/api/user/addresses/**").authenticated()
                
                // User payment cards - Users can only manage their own cards
                .requestMatchers("/api/user/cards/**").authenticated()
                
                // Serve uploaded files
                .requestMatchers("/uploads/**").permitAll()
                
                // Cart - Users can only access their own cart (enforced in service layer)
                .requestMatchers("/api/cart/**").hasAnyRole("CUSTOMER", "ADMIN", "SUPPORT", "MANAGER")
                
                // Orders - Users can only access their own orders (enforced in service layer)
                .requestMatchers(HttpMethod.POST, "/api/orders").hasAnyRole("CUSTOMER", "ADMIN")
                .requestMatchers(HttpMethod.GET, "/api/orders/**").hasAnyRole("CUSTOMER", "ADMIN", "SUPPORT", "MANAGER")
                .requestMatchers(HttpMethod.PATCH, "/api/orders/**").hasAnyRole("ADMIN", "MANAGER")
                
                // All other requests require authentication
                .anyRequest().authenticated()
            )
            .sessionManagement(session -> session.sessionCreationPolicy(SessionCreationPolicy.STATELESS))
            .authenticationProvider(authenticationProvider())
            .addFilterBefore(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public AuthenticationProvider authenticationProvider() {
        DaoAuthenticationProvider authProvider = new DaoAuthenticationProvider(userDetailsService);
        authProvider.setPasswordEncoder(passwordEncoder());
        return authProvider;
    }

    @Bean
    public AuthenticationManager authenticationManager(AuthenticationConfiguration config) throws Exception {
        return config.getAuthenticationManager();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        
        // Only allow specific origins - can be externalized to application.yaml
        configuration.setAllowedOrigins(Arrays.asList(
            "http://localhost:5173", 
            "http://localhost:3000",
            "http://localhost:4200"
        ));
        
        // Only allow specific HTTP methods
        configuration.setAllowedMethods(Arrays.asList("GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"));
        
        // Only allow specific headers
        configuration.setAllowedHeaders(Arrays.asList(
            "Authorization",
            "Content-Type",
            "Accept",
            "Origin",
            "X-Requested-With"
        ));
        
        // Expose specific headers to the client
        configuration.setExposedHeaders(Arrays.asList("Authorization", "Content-Disposition"));
        
        // Allow credentials (cookies, authorization headers)
        configuration.setAllowCredentials(true);
        
        // Cache preflight response for 1 hour
        configuration.setMaxAge(3600L);
        
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/api/**", configuration);
        return source;
    }
}
