package com.pd.my_app.service;

import com.pd.my_app.dto.CategoryDTO;
import com.pd.my_app.entity.Category;
import com.pd.my_app.exception.CategoryNotFoundException;
import com.pd.my_app.repository.CategoryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.stream.Collectors;

@Service
@Transactional
public class CategoryService {

    private static final Logger logger = LoggerFactory.getLogger(CategoryService.class);

    private final CategoryRepository categoryRepository;

    @Autowired
    public CategoryService(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    /**
     * Create a new category
     */
    @org.springframework.cache.annotation.CacheEvict(value = "categories", allEntries = true)
    public CategoryDTO createCategory(CategoryDTO categoryDTO) {
        logger.debug("Creating new category: {}", categoryDTO.getName());

        Category category = new Category();
        category.setName(categoryDTO.getName());
        category.setDescription(categoryDTO.getDescription());
        category.setImageUrl(categoryDTO.getImageUrl());
        category.setIsActive(categoryDTO.getIsActive() != null ? categoryDTO.getIsActive() : true);

        if (categoryDTO.getParentId() != null) {
            Category parent = categoryRepository.findById(categoryDTO.getParentId())
                    .orElseThrow(() -> new CategoryNotFoundException("Parent category not found with id: " + categoryDTO.getParentId()));
            category.setParent(parent);
        }

        Category savedCategory = categoryRepository.save(category);
        logger.info("Category created successfully with id: {}", savedCategory.getId());

        return convertToDTO(savedCategory);
    }

    /**
     * Get category by ID
     */
    @Transactional(readOnly = true)
    public CategoryDTO getCategoryById(Long id) {
        logger.debug("Fetching category with id: {}", id);

        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new CategoryNotFoundException("Category not found with id: " + id));

        return convertToDTO(category);
    }

    /**
     * Get all active categories
     */
    @Transactional(readOnly = true)
    @org.springframework.cache.annotation.Cacheable(value = "categories", key = "'active'")
    public List<CategoryDTO> getAllActiveCategories() {
        logger.debug("Fetching all active categories");

        List<Category> categories = categoryRepository.findByIsActiveTrue();
        return categories.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Get all categories
     */
    @Transactional(readOnly = true)
    @org.springframework.cache.annotation.Cacheable(value = "categories", key = "'all'")
    public List<CategoryDTO> getAllCategories() {
        logger.debug("Fetching all categories");

        List<Category> categories = categoryRepository.findAll();
        return categories.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Get top level categories (no parent)
     */
    @Transactional(readOnly = true)
    @org.springframework.cache.annotation.Cacheable(value = "categories", key = "'topLevel'")
    public List<CategoryDTO> getTopLevelCategories() {
        logger.debug("Fetching top level categories");

        List<Category> categories = categoryRepository.findTopLevelCategories();
        return categories.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    /**
     * Get subcategories of a category
     */
    @Transactional(readOnly = true)
    public List<CategoryDTO> getSubCategories(Long parentId) {
        logger.debug("Fetching subcategories for parent id: {}", parentId);

        if (!categoryRepository.existsById(parentId)) {
            throw new CategoryNotFoundException("Parent category not found with id: " + parentId);
        }

        List<Category> categories = categoryRepository.findSubCategories(parentId);
        return categories.stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }
    /**
     * Update category
     */
    @org.springframework.cache.annotation.CacheEvict(value = "categories", allEntries = true)
    public CategoryDTO updateCategory(Long id, CategoryDTO categoryDTO) {
        logger.debug("Updating category with id: {}", id);

        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new CategoryNotFoundException("Category not found with id: " + id));

        category.setName(categoryDTO.getName());
        category.setDescription(categoryDTO.getDescription());
        category.setImageUrl(categoryDTO.getImageUrl());
        
        if (categoryDTO.getIsActive() != null) {
            category.setIsActive(categoryDTO.getIsActive());
        }

        if (categoryDTO.getParentId() != null) {
            Category parent = categoryRepository.findById(categoryDTO.getParentId())
                    .orElseThrow(() -> new CategoryNotFoundException("Parent category not found with id: " + categoryDTO.getParentId()));
            category.setParent(parent);
        } else {
            category.setParent(null);
        }

        Category updatedCategory = categoryRepository.save(category);
        logger.info("Category updated successfully with id: {}", id);

        return convertToDTO(updatedCategory);
    }

    /**
     * Delete category
     */
    @org.springframework.cache.annotation.CacheEvict(value = "categories", allEntries = true)
    public void deleteCategory(Long id) {
        logger.debug("Deleting category with id: {}", id);

        if (!categoryRepository.existsById(id)) {
            throw new CategoryNotFoundException("Category not found with id: " + id);
        }

        categoryRepository.deleteById(id);
        logger.info("Category deleted successfully with id: {}", id);
    }

    /**
     * Convert Category entity to DTO
     */
    private CategoryDTO convertToDTO(Category category) {
        CategoryDTO dto = new CategoryDTO();
        dto.setId(category.getId());
        dto.setName(category.getName());
        dto.setDescription(category.getDescription());
        dto.setImageUrl(category.getImageUrl());
        dto.setIsActive(category.getIsActive());
        dto.setCreatedAt(category.getCreatedAt());
        dto.setUpdatedAt(category.getUpdatedAt());

        if (category.getParent() != null) {
            dto.setParentId(category.getParent().getId());
            dto.setParentName(category.getParent().getName());
        }

        dto.setProductCount(category.getProducts() != null ? category.getProducts().size() : 0);
        dto.setSubCategoryCount(category.getSubCategories() != null ? category.getSubCategories().size() : 0);

        return dto;
    }
}
