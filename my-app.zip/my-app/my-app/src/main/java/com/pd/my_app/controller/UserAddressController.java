package com.pd.my_app.controller;

import com.pd.my_app.dto.UserAddressDTO;
import com.pd.my_app.security.JwtTokenUtil;
import com.pd.my_app.service.UserAddressService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/user/addresses")
public class UserAddressController {

    @Autowired
    private UserAddressService addressService;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @GetMapping
    public ResponseEntity<List<UserAddressDTO>> getUserAddresses(
            @RequestHeader("Authorization") String token) {
        Long userId = getUserIdFromToken(token);
        List<UserAddressDTO> addresses = addressService.getUserAddresses(userId);
        return ResponseEntity.ok(addresses);
    }

    @PostMapping
    public ResponseEntity<UserAddressDTO> addAddress(
            @RequestHeader("Authorization") String token,
            @Valid @RequestBody UserAddressDTO addressDTO) {
        Long userId = getUserIdFromToken(token);
        UserAddressDTO savedAddress = addressService.addAddress(userId, addressDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedAddress);
    }

    @PutMapping("/{addressId}")
    public ResponseEntity<UserAddressDTO> updateAddress(
            @RequestHeader("Authorization") String token,
            @PathVariable Long addressId,
            @Valid @RequestBody UserAddressDTO addressDTO) {
        Long userId = getUserIdFromToken(token);
        UserAddressDTO updatedAddress = addressService.updateAddress(userId, addressId, addressDTO);
        return ResponseEntity.ok(updatedAddress);
    }

    @DeleteMapping("/{addressId}")
    public ResponseEntity<Void> deleteAddress(
            @RequestHeader("Authorization") String token,
            @PathVariable Long addressId) {
        Long userId = getUserIdFromToken(token);
        addressService.deleteAddress(userId, addressId);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{addressId}/set-default")
    public ResponseEntity<UserAddressDTO> setDefaultAddress(
            @RequestHeader("Authorization") String token,
            @PathVariable Long addressId) {
        Long userId = getUserIdFromToken(token);
        UserAddressDTO updatedAddress = addressService.setDefaultAddress(userId, addressId);
        return ResponseEntity.ok(updatedAddress);
    }

    private Long getUserIdFromToken(String token) {
        String jwt = token.replace("Bearer ", "");
        return jwtTokenUtil.extractUserId(jwt);
    }
}
