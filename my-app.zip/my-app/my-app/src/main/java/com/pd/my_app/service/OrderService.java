package com.pd.my_app.service;

import com.pd.my_app.dto.OrderDTO;
import com.pd.my_app.dto.OrderItemDTO;
import com.pd.my_app.dto.OrderRequest;
import com.pd.my_app.entity.*;
import com.pd.my_app.exception.*;
import com.pd.my_app.repository.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.stream.Collectors;

@Service
@Transactional
public class OrderService {

    private static final Logger logger = LoggerFactory.getLogger(OrderService.class);

    private final OrderRepository orderRepository;
    private final CartRepository cartRepository;
    private final CartItemRepository cartItemRepository;
    private final UserRepository userRepository;
    private final ProductRepository productRepository;

    @Autowired
    public OrderService(OrderRepository orderRepository, CartRepository cartRepository,
                        CartItemRepository cartItemRepository, UserRepository userRepository,
                        ProductRepository productRepository) {
        this.orderRepository = orderRepository;
        this.cartRepository = cartRepository;
        this.cartItemRepository = cartItemRepository;
        this.userRepository = userRepository;
        this.productRepository = productRepository;
    }

    public OrderDTO placeOrder(Long userId, OrderRequest orderRequest) {
        logger.info("Placing order for user: {}", userId);

        // Get user
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new UserNotFoundException(userId));

        // Get cart with items
        Cart cart = cartRepository.findByUserIdWithItems(userId)
                .orElseThrow(() -> new CartNotFoundException(userId));

        if (cart.getItems().isEmpty()) {
            throw new InvalidOrderException("Cannot place order with empty cart");
        }

        // Create order
        Order order = new Order(user, 
                orderRequest.getShippingAddress(),
                orderRequest.getShippingCity(),
                orderRequest.getShippingState(),
                orderRequest.getShippingPostalCode(),
                orderRequest.getShippingCountry());
        
        order.setPhoneNumber(orderRequest.getPhoneNumber());
        order.setNotes(orderRequest.getNotes());
        order.setPaymentMethod(orderRequest.getPaymentMethod());

        // Convert cart items to order items and reduce inventory
        for (CartItem cartItem : cart.getItems()) {
            Product product = cartItem.getProduct();

            // Validate stock availability
            if (!product.hasEnoughStock(cartItem.getQuantity())) {
                throw new InsufficientStockException(
                        product.getName(), 
                        cartItem.getQuantity(), 
                        product.getStockQuantity()
                );
            }

            // Reduce stock
            product.reduceStock(cartItem.getQuantity());
            productRepository.save(product);

            // Create order item
            OrderItem orderItem = new OrderItem(order, product, cartItem.getQuantity());
            order.addItem(orderItem);
            
            logger.debug("Added product {} to order, reduced stock by {}", 
                         product.getName(), cartItem.getQuantity());
        }

        order.recalculateTotal();
        Order savedOrder = orderRepository.save(order);

        // Clear cart after successful order
        cart.clearCart();
        cartItemRepository.deleteByCartId(cart.getId());
        cartRepository.save(cart);

        logger.info("Order placed successfully - Order number: {}", savedOrder.getOrderNumber());
        return mapToDTO(savedOrder);
    }

    @Transactional(readOnly = true)
    public OrderDTO getOrderById(Long orderId, Long userId) {
        logger.debug("Fetching order {} for user {}", orderId, userId);

        Order order = orderRepository.findByIdWithItems(orderId)
                .orElseThrow(() -> new OrderNotFoundException(orderId));

        // Verify order belongs to user
        if (!order.getUser().getId().equals(userId)) {
            throw new OrderNotFoundException("Order not found or access denied");
        }

        return mapToDTO(order);
    }

    @Transactional(readOnly = true)
    public Page<OrderDTO> getUserOrders(Long userId, Pageable pageable) {
        logger.debug("Fetching orders for user: {}", userId);

        Page<Order> orders = orderRepository.findByUserId(userId, pageable);
        return orders.map(this::mapToDTO);
    }

    @Transactional(readOnly = true)
    public Page<OrderDTO> getAllOrders(Pageable pageable) {
        logger.debug("Fetching all orders");

        Page<Order> orders = orderRepository.findAll(pageable);
        return orders.map(this::mapToDTO);
    }

    @Transactional(readOnly = true)
    public OrderDTO getOrderByOrderNumber(String orderNumber, Long userId) {
        logger.debug("Fetching order by order number: {}", orderNumber);

        Order order = orderRepository.findByOrderNumber(orderNumber)
                .orElseThrow(() -> new OrderNotFoundException("Order not found with order number: " + orderNumber));

        // Verify order belongs to user
        if (!order.getUser().getId().equals(userId)) {
            throw new OrderNotFoundException("Order not found or access denied");
        }

        return mapToDTO(order);
    }

    public OrderDTO updateOrderStatus(Long orderId, OrderStatus newStatus) {
        logger.info("Updating order {} status to {}", orderId, newStatus);

        Order order = orderRepository.findById(orderId)
                .orElseThrow(() -> new OrderNotFoundException(orderId));

        order.setStatus(newStatus);

        if (newStatus == OrderStatus.DELIVERED) {
            order.setDeliveredAt(LocalDateTime.now());
            order.setPaymentStatus("COMPLETED");
        }

        Order updatedOrder = orderRepository.save(order);
        logger.info("Order status updated successfully");

        return mapToDTO(updatedOrder);
    }

    public OrderDTO cancelOrder(Long orderId, Long userId) {
        logger.info("Cancelling order {} for user {}", orderId, userId);

        Order order = orderRepository.findByIdWithItems(orderId)
                .orElseThrow(() -> new OrderNotFoundException(orderId));

        // Verify order belongs to user
        if (!order.getUser().getId().equals(userId)) {
            throw new OrderNotFoundException("Order not found or access denied");
        }

        // Check if order can be cancelled
        if (!order.canBeCancelled()) {
            throw new InvalidOrderException("Order cannot be cancelled in current status: " + order.getStatus());
        }

        // Restore inventory
        for (OrderItem item : order.getItems()) {
            Product product = item.getProduct();
            product.increaseStock(item.getQuantity());
            productRepository.save(product);
            
            logger.debug("Restored stock for product {}: +{}", 
                         product.getName(), item.getQuantity());
        }

        order.setStatus(OrderStatus.CANCELLED);
        Order cancelledOrder = orderRepository.save(order);

        logger.info("Order cancelled successfully and inventory restored");
        return mapToDTO(cancelledOrder);
    }

    // Mapping methods
    private OrderDTO mapToDTO(Order order) {
        OrderDTO dto = new OrderDTO();
        dto.setId(order.getId());
        dto.setOrderNumber(order.getOrderNumber());
        dto.setUserId(order.getUser().getId());
        dto.setStatus(order.getStatus());
        dto.setTotalAmount(order.getTotalAmount());
        dto.setTotalItems(order.getTotalItems());
        dto.setShippingAddress(order.getShippingAddress());
        dto.setShippingCity(order.getShippingCity());
        dto.setShippingState(order.getShippingState());
        dto.setShippingPostalCode(order.getShippingPostalCode());
        dto.setShippingCountry(order.getShippingCountry());
        dto.setPhoneNumber(order.getPhoneNumber());
        dto.setNotes(order.getNotes());
        dto.setPaymentMethod(order.getPaymentMethod());
        dto.setPaymentStatus(order.getPaymentStatus());
        dto.setCreatedAt(order.getCreatedAt());
        dto.setUpdatedAt(order.getUpdatedAt());
        dto.setDeliveredAt(order.getDeliveredAt());

        dto.setItems(order.getItems().stream()
                .map(this::mapOrderItemToDTO)
                .collect(Collectors.toList()));

        return dto;
    }

    private OrderItemDTO mapOrderItemToDTO(OrderItem item) {
        OrderItemDTO dto = new OrderItemDTO();
        dto.setId(item.getId());
        dto.setProductId(item.getProduct().getId());
        dto.setProductName(item.getProductName());
        dto.setQuantity(item.getQuantity());
        dto.setPrice(item.getPrice());
        dto.setSubtotal(item.getSubtotal());
        return dto;
    }
}
