package com.pd.my_app.service;

import com.pd.my_app.dto.ProductDTO;
import com.pd.my_app.entity.Category;
import com.pd.my_app.entity.Product;
import com.pd.my_app.exception.CategoryNotFoundException;
import com.pd.my_app.exception.ProductNotFoundException;
import com.pd.my_app.repository.CategoryRepository;
import com.pd.my_app.repository.ProductRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.util.List;

@Service
@Transactional
public class ProductService {

    private static final Logger logger = LoggerFactory.getLogger(ProductService.class);

    private final ProductRepository productRepository;
    private final CategoryRepository categoryRepository;

    @Autowired
    public ProductService(ProductRepository productRepository, CategoryRepository categoryRepository) {
        this.productRepository = productRepository;
        this.categoryRepository = categoryRepository;
    }

    @Transactional(readOnly = true)
    @org.springframework.cache.annotation.Cacheable(value = "products", key = "#pageable.pageNumber + '-' + #pageable.pageSize")
    public Page<ProductDTO> getAllProducts(Pageable pageable) {
        logger.debug("Fetching all active products with pagination");
        Page<Product> products = productRepository.findByIsActiveTrue(pageable);
        return products.map(this::mapToDTO);
    }

    @Transactional(readOnly = true)
    public Page<ProductDTO> getProductsByCategory(Long categoryId, Pageable pageable) {
        logger.debug("Fetching products for category id: {}", categoryId);
        
        if (!categoryRepository.existsById(categoryId)) {
            throw new CategoryNotFoundException(categoryId);
        }
        
        Page<Product> products = productRepository.findByCategoryIdAndIsActiveTrue(categoryId, pageable);
        return products.map(this::mapToDTO);
    }

    @Transactional(readOnly = true)
    public Page<ProductDTO> searchProducts(String keyword, Pageable pageable) {
        logger.debug("Searching products with keyword: {}", keyword);
        Page<Product> products = productRepository.searchProducts(keyword, pageable);
        return products.map(this::mapToDTO);
    }

    @Transactional(readOnly = true)
    public Page<ProductDTO> filterProducts(Long categoryId, String brand, BigDecimal minPrice, 
                                            BigDecimal maxPrice, String keyword, Pageable pageable) {
        logger.debug("Filtering products - Category: {}, Brand: {}, Price Range: {}-{}, Keyword: {}", 
                     categoryId, brand, minPrice, maxPrice, keyword);

        Specification<Product> spec = (root, query, cb) -> cb.conjunction();

        // Active products only
        spec = spec.and((root, query, cb) -> cb.isTrue(root.get("isActive")));

        // Filter by category
        if (categoryId != null) {
            spec = spec.and((root, query, cb) -> cb.equal(root.get("category").get("id"), categoryId));
        }

        // Filter by brand
        if (brand != null && !brand.trim().isEmpty()) {
            spec = spec.and((root, query, cb) -> 
                cb.equal(cb.lower(root.get("brand")), brand.toLowerCase()));
        }

        // Filter by price range
        if (minPrice != null) {
            spec = spec.and((root, query, cb) -> cb.greaterThanOrEqualTo(root.get("price"), minPrice));
        }
        if (maxPrice != null) {
            spec = spec.and((root, query, cb) -> cb.lessThanOrEqualTo(root.get("price"), maxPrice));
        }

        // Search by keyword
        if (keyword != null && !keyword.trim().isEmpty()) {
            String likePattern = "%" + keyword.toLowerCase() + "%";
            spec = spec.and((root, query, cb) -> 
                cb.or(
                    cb.like(cb.lower(root.get("name")), likePattern),
                    cb.like(cb.lower(root.get("description")), likePattern),
                    cb.like(cb.lower(root.get("brand")), likePattern)
                )
            );
        }

        Page<Product> products = productRepository.findAll(spec, pageable);
        logger.info("Found {} products matching filter criteria", products.getTotalElements());
        
        return products.map(this::mapToDTO);
    }

    @Transactional(readOnly = true)
    @org.springframework.cache.annotation.Cacheable(value = "products", key = "#id")
    public ProductDTO getProductById(Long id) {
        logger.debug("Fetching product with id: {}", id);
        
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ProductNotFoundException(id));
        
        return mapToDTO(product);
    }
    @org.springframework.cache.annotation.CacheEvict(value = "products", allEntries = true)
    public ProductDTO createProduct(ProductDTO productDTO) {
        logger.debug("Creating new product: {}", productDTO.getName());
        
        Product product = mapToEntity(productDTO);
        
        if (productDTO.getCategoryId() != null) {
            Category category = categoryRepository.findById(productDTO.getCategoryId())
                    .orElseThrow(() -> new CategoryNotFoundException(productDTO.getCategoryId()));
            product.setCategory(category);
        }
        
        Product savedProduct = productRepository.save(product);
        logger.info("Product created successfully with id: {}", savedProduct.getId());
        
        return mapToDTO(savedProduct);
    }

    @org.springframework.cache.annotation.CachePut(value = "products", key = "#id")
    @org.springframework.cache.annotation.CacheEvict(value = "products", allEntries = true, condition = "#result != null")
    public ProductDTO updateProduct(Long id, ProductDTO productDTO) {
        logger.debug("Updating product with id: {}", id);
        
        Product existingProduct = productRepository.findById(id)
                .orElseThrow(() -> new ProductNotFoundException(id));

        existingProduct.setName(productDTO.getName());
        existingProduct.setDescription(productDTO.getDescription());
        existingProduct.setPrice(productDTO.getPrice());
        existingProduct.setStockQuantity(productDTO.getStockQuantity());
        existingProduct.setBrand(productDTO.getBrand());
        existingProduct.setSku(productDTO.getSku());
        existingProduct.setImageUrl(productDTO.getImageUrl());
        
        if (productDTO.getIsActive() != null) {
            existingProduct.setIsActive(productDTO.getIsActive());
        }
        if (productDTO.getIsFeatured() != null) {
            existingProduct.setIsFeatured(productDTO.getIsFeatured());
        }

        if (productDTO.getCategoryId() != null) {
            Category category = categoryRepository.findById(productDTO.getCategoryId())
                    .orElseThrow(() -> new CategoryNotFoundException(productDTO.getCategoryId()));
            existingProduct.setCategory(category);
        }

        Product updatedProduct = productRepository.save(existingProduct);
        logger.info("Product updated successfully with id: {}", updatedProduct.getId());
        
        return mapToDTO(updatedProduct);
    }

    @org.springframework.cache.annotation.CacheEvict(value = "products", allEntries = true)
    public void deleteProduct(Long id) {
        logger.debug("Deleting product with id: {}", id);
        
        if (!productRepository.existsById(id)) {
            throw new ProductNotFoundException(id);
        }

        productRepository.deleteById(id);
        logger.info("Product deleted successfully with id: {}", id);
    }

    @Transactional(readOnly = true)
    public List<String> getAllBrands() {
        logger.debug("Fetching all brands");
        return productRepository.findAllBrands();
    }

    @Transactional(readOnly = true)
    public Page<ProductDTO> getOutOfStockProducts(Pageable pageable) {
        logger.debug("Fetching out of stock products with pagination");
        Page<Product> products = productRepository.findByStockQuantityAndIsActiveTrue(0, pageable);
        return products.map(this::mapToDTO);
    }

    @Transactional(readOnly = true)
    public Page<ProductDTO> getLowStockProducts(int threshold, Pageable pageable) {
        logger.debug("Fetching low stock products with threshold: {} and pagination", threshold);
        Page<Product> products = productRepository.findByStockQuantityBetweenAndIsActiveTrue(1, threshold, pageable);
        return products.map(this::mapToDTO);
    }

    // Mapping methods
    private ProductDTO mapToDTO(Product product) {
        ProductDTO dto = new ProductDTO();
        dto.setId(product.getId());
        dto.setName(product.getName());
        dto.setDescription(product.getDescription());
        dto.setPrice(product.getPrice());
        dto.setStockQuantity(product.getStockQuantity());
        dto.setBrand(product.getBrand());
        dto.setSku(product.getSku());
        dto.setImageUrl(product.getImageUrl());
        dto.setRating(product.getRating());
        dto.setReviewCount(product.getReviewCount());
        dto.setIsActive(product.getIsActive());
        dto.setIsFeatured(product.getIsFeatured());
        dto.setCreatedAt(product.getCreatedAt());
        dto.setUpdatedAt(product.getUpdatedAt());
        
        if (product.getCategory() != null) {
            dto.setCategoryId(product.getCategory().getId());
            dto.setCategoryName(product.getCategory().getName());
        }
        
        return dto;
    }

    private Product mapToEntity(ProductDTO dto) {
        Product product = new Product();
        product.setName(dto.getName());
        product.setDescription(dto.getDescription());
        product.setPrice(dto.getPrice());
        product.setStockQuantity(dto.getStockQuantity());
        product.setBrand(dto.getBrand());
        product.setSku(dto.getSku());
        product.setImageUrl(dto.getImageUrl());
        
        if (dto.getIsActive() != null) {
            product.setIsActive(dto.getIsActive());
        }
        if (dto.getIsFeatured() != null) {
            product.setIsFeatured(dto.getIsFeatured());
        }
        
        return product;
    }
}
