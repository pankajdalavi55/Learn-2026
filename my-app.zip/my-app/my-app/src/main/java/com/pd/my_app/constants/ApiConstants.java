package com.pd.my_app.constants;

/**
 * API Constants for the E-Commerce Application
 * Contains all constant values used across the application
 */
public final class ApiConstants {

    private ApiConstants() {
        // Private constructor to prevent instantiation
    }

    // API Base Paths
    public static final String API_BASE_PATH = "/api";
    public static final String AUTH_PATH = API_BASE_PATH + "/auth";
    public static final String USERS_PATH = API_BASE_PATH + "/users";
    public static final String PRODUCTS_PATH = API_BASE_PATH + "/products";
    public static final String CATEGORIES_PATH = API_BASE_PATH + "/categories";
    public static final String CART_PATH = API_BASE_PATH + "/cart";
    public static final String ORDERS_PATH = API_BASE_PATH + "/orders";

    // Pagination Defaults
    public static final int DEFAULT_PAGE_NUMBER = 0;
    public static final int DEFAULT_PAGE_SIZE = 20;
    public static final int MAX_PAGE_SIZE = 100;
    public static final String DEFAULT_SORT_BY = "createdAt";
    public static final String DEFAULT_SORT_DIRECTION = "DESC";

    // File Upload
    public static final long MAX_FILE_SIZE = 5 * 1024 * 1024; // 5MB
    public static final long MAX_REQUEST_SIZE = 10 * 1024 * 1024; // 10MB
    public static final String PROFILE_PICTURE_DIR = "profile-pictures";
    public static final String PRODUCT_IMAGE_DIR = "product-images";

    // Cache Names
    public static final String PRODUCTS_CACHE = "products";
    public static final String CATEGORIES_CACHE = "categories";
    public static final String USERS_CACHE = "users";

    // Stock Thresholds
    public static final int LOW_STOCK_THRESHOLD = 10;
    public static final int OUT_OF_STOCK = 0;

    // Order Status Messages
    public static final String ORDER_PLACED_MESSAGE = "Order placed successfully";
    public static final String ORDER_CANCELLED_MESSAGE = "Order cancelled successfully";
    public static final String ORDER_NOT_CANCELLABLE = "Order cannot be cancelled in current status";

    // Error Messages
    public static final String USER_NOT_FOUND = "User not found with id: %d";
    public static final String PRODUCT_NOT_FOUND = "Product not found with id: %d";
    public static final String CATEGORY_NOT_FOUND = "Category not found with id: %d";
    public static final String ORDER_NOT_FOUND = "Order not found with id: %d";
    public static final String CART_NOT_FOUND = "Cart not found for user id: %d";
    public static final String INSUFFICIENT_STOCK = "Insufficient stock for product: %s. Available: %d, Requested: %d";
    public static final String DUPLICATE_EMAIL = "Email already exists: %s";
    public static final String INVALID_CREDENTIALS = "Invalid email or password";
    public static final String UNAUTHORIZED_ACCESS = "You are not authorized to access this resource";

    // Validation Messages
    public static final String VALIDATION_NAME_REQUIRED = "Name is required";
    public static final String VALIDATION_EMAIL_REQUIRED = "Email is required";
    public static final String VALIDATION_EMAIL_INVALID = "Email should be valid";
    public static final String VALIDATION_PASSWORD_REQUIRED = "Password is required";
    public static final String VALIDATION_PASSWORD_SIZE = "Password must be between 6 and 20 characters";
    public static final String VALIDATION_PRICE_POSITIVE = "Price must be positive";
    public static final String VALIDATION_QUANTITY_POSITIVE = "Quantity must be positive";

    // JWT
    public static final String JWT_HEADER = "Authorization";
    public static final String JWT_TOKEN_PREFIX = "Bearer ";
    public static final long JWT_EXPIRATION_TIME = 24 * 60 * 60 * 1000; // 24 hours

    // Response Messages
    public static final String SUCCESS_MESSAGE = "Operation completed successfully";
    public static final String CREATED_MESSAGE = "Resource created successfully";
    public static final String UPDATED_MESSAGE = "Resource updated successfully";
    public static final String DELETED_MESSAGE = "Resource deleted successfully";
}
