package com.pd.my_app.controller;

import com.pd.my_app.dto.OrderDTO;
import com.pd.my_app.dto.OrderRequest;
import com.pd.my_app.entity.OrderStatus;
import com.pd.my_app.service.OrderService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/orders")
public class OrderController {

    private static final Logger logger = LoggerFactory.getLogger(OrderController.class);

    private final OrderService orderService;

    @Autowired
    public OrderController(OrderService orderService) {
        this.orderService = orderService;
    }

    /**
     * Place a new order from cart
     * POST /api/orders?userId=1
     */
    @PostMapping
    public ResponseEntity<OrderDTO> placeOrder(
            @RequestParam Long userId,
            @Valid @RequestBody OrderRequest orderRequest) {
        logger.info("REST request to place order for user: {}", userId);
        OrderDTO order = orderService.placeOrder(userId, orderRequest);
        return new ResponseEntity<>(order, HttpStatus.CREATED);
    }

    /**
     * Get order by ID
     * GET /api/orders/1?userId=1
     */
    @GetMapping("/{orderId}")
    public ResponseEntity<OrderDTO> getOrderById(
            @PathVariable Long orderId,
            @RequestParam Long userId) {
        logger.info("REST request to get order {} for user {}", orderId, userId);
        OrderDTO order = orderService.getOrderById(orderId, userId);
        return ResponseEntity.ok(order);
    }

    /**
     * Get order by order number
     * GET /api/orders/number/ORD-123456?userId=1
     */
    @GetMapping("/number/{orderNumber}")
    public ResponseEntity<OrderDTO> getOrderByOrderNumber(
            @PathVariable String orderNumber,
            @RequestParam Long userId) {
        logger.info("REST request to get order by number {} for user {}", orderNumber, userId);
        OrderDTO order = orderService.getOrderByOrderNumber(orderNumber, userId);
        return ResponseEntity.ok(order);
    }

    /**
     * Get user's order history with pagination
     * GET /api/orders/user/1?page=0&size=10
     */
    @GetMapping("/user/{userId}")
    public ResponseEntity<Page<OrderDTO>> getUserOrders(
            @PathVariable Long userId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        logger.info("REST request to get orders for user: {}", userId);
        
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        Page<OrderDTO> orders = orderService.getUserOrders(userId, pageable);
        return ResponseEntity.ok(orders);
    }

    /**
     * Update order status (Admin only - in real app)
     * PATCH /api/orders/1/status?status=SHIPPED
     */
    @PatchMapping("/{orderId}/status")
    public ResponseEntity<OrderDTO> updateOrderStatus(
            @PathVariable Long orderId,
            @RequestParam OrderStatus status) {
        logger.info("REST request to update order {} status to {}", orderId, status);
        OrderDTO order = orderService.updateOrderStatus(orderId, status);
        return ResponseEntity.ok(order);
    }

    /**
     * Cancel order
     * POST /api/orders/1/cancel?userId=1
     */
    @PostMapping("/{orderId}/cancel")
    public ResponseEntity<OrderDTO> cancelOrder(
            @PathVariable Long orderId,
            @RequestParam Long userId) {
        logger.info("REST request to cancel order {} for user {}", orderId, userId);
        OrderDTO order = orderService.cancelOrder(orderId, userId);
        return ResponseEntity.ok(order);
    }

    /**
     * Get all orders (Admin only)
     * GET /api/orders?page=0&size=10
     */
    @GetMapping
    public ResponseEntity<Page<OrderDTO>> getAllOrders(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size) {
        logger.info("REST request to get all orders");
        Pageable pageable = PageRequest.of(page, size, Sort.by("createdAt").descending());
        Page<OrderDTO> orders = orderService.getAllOrders(pageable);
        return ResponseEntity.ok(orders);
    }
}
