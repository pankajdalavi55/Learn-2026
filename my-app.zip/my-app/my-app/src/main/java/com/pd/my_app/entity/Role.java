package com.pd.my_app.entity;

public enum Role {
    // Customer role - Regular users who can browse, shop, and manage their own data
    CUSTOMER,
    
    // Vendor role - Can manage their own products and view their sales
    VENDOR,
    
    // Admin role - Full system access, can manage all users, products, orders
    ADMIN,
    
    // Support role - Can view customer details, orders, help with issues
    SUPPORT,
    
    // Manager role - Can view analytics, reports, manage inventory
    MANAGER
}
