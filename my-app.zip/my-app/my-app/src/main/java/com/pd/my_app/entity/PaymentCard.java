package com.pd.my_app.entity;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "payment_cards")
public class PaymentCard {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    @NotBlank(message = "Card label is required")
    @Size(max = 50)
    @Column(name = "label", length = 50)
    private String label; // e.g., "Personal", "Business"

    @NotBlank(message = "Cardholder name is required")
    @Size(max = 100)
    @Column(name = "cardholder_name", nullable = false, length = 100)
    private String cardholderName;

    @NotBlank(message = "Card number is required")
    @Size(max = 255)
    @Column(name = "card_number_encrypted", nullable = false)
    private String cardNumberEncrypted; // Store encrypted

    @Column(name = "card_last_four", length = 4)
    private String cardLastFour; // Store last 4 digits for display

    @NotBlank(message = "Card type is required")
    @Size(max = 20)
    @Column(name = "card_type", length = 20)
    private String cardType; // VISA, MASTERCARD, AMEX, etc.

    @NotBlank(message = "Expiry month is required")
    @Size(max = 2)
    @Column(name = "expiry_month", nullable = false, length = 2)
    private String expiryMonth;

    @NotBlank(message = "Expiry year is required")
    @Size(max = 4)
    @Column(name = "expiry_year", nullable = false, length = 4)
    private String expiryYear;

    @Column(name = "is_default")
    private Boolean isDefault = false;

    @CreationTimestamp
    @Column(name = "created_at", updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    @Column(name = "updated_at")
    private LocalDateTime updatedAt;

    // Constructors
    public PaymentCard() {
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public String getLabel() {
        return label;
    }

    public void setLabel(String label) {
        this.label = label;
    }

    public String getCardholderName() {
        return cardholderName;
    }

    public void setCardholderName(String cardholderName) {
        this.cardholderName = cardholderName;
    }

    public String getCardNumberEncrypted() {
        return cardNumberEncrypted;
    }

    public void setCardNumberEncrypted(String cardNumberEncrypted) {
        this.cardNumberEncrypted = cardNumberEncrypted;
    }

    public String getCardLastFour() {
        return cardLastFour;
    }

    public void setCardLastFour(String cardLastFour) {
        this.cardLastFour = cardLastFour;
    }

    public String getCardType() {
        return cardType;
    }

    public void setCardType(String cardType) {
        this.cardType = cardType;
    }

    public String getExpiryMonth() {
        return expiryMonth;
    }

    public void setExpiryMonth(String expiryMonth) {
        this.expiryMonth = expiryMonth;
    }

    public String getExpiryYear() {
        return expiryYear;
    }

    public void setExpiryYear(String expiryYear) {
        this.expiryYear = expiryYear;
    }

    public Boolean getIsDefault() {
        return isDefault;
    }

    public void setIsDefault(Boolean isDefault) {
        this.isDefault = isDefault;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    public LocalDateTime getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(LocalDateTime updatedAt) {
        this.updatedAt = updatedAt;
    }

    // Helper method to get masked card number
    public String getMaskedCardNumber() {
        if (cardLastFour != null && cardLastFour.length() == 4) {
            return "**** **** **** " + cardLastFour;
        }
        return "****";
    }
}
