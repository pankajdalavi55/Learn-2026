package com.pd.my_app.controller;

import com.pd.my_app.dto.AddToCartRequest;
import com.pd.my_app.dto.CartDTO;
import com.pd.my_app.security.CustomUserDetails;
import com.pd.my_app.service.CartService;
import jakarta.validation.Valid;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/cart")
public class CartController {

    private static final Logger logger = LoggerFactory.getLogger(CartController.class);

    private final CartService cartService;

    @Autowired
    public CartController(CartService cartService) {
        this.cartService = cartService;
    }

    /**
     * Get cart for user
     * GET /api/cart?userId=1
     * Customers can only access their own cart, ADMIN/SUPPORT/MANAGER can access any cart
     */
    @GetMapping
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN', 'SUPPORT', 'MANAGER')")
    public ResponseEntity<CartDTO> getCart(
            @RequestParam Long userId,
            @AuthenticationPrincipal CustomUserDetails currentUser) {
        
        // Validate user can only access their own cart (except ADMIN/SUPPORT/MANAGER)
        String role = currentUser.getRole();
        boolean isPrivilegedUser = role.equals("ADMIN") || role.equals("SUPPORT") || role.equals("MANAGER");
        
        if (!isPrivilegedUser && !userId.equals(currentUser.getUserId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You can only access your own cart");
        }
        
        logger.info("REST request to get cart for user: {}", userId);
        CartDTO cart = cartService.getCartByUserId(userId);
        return ResponseEntity.ok(cart);
    }

    /**
     * Add product to cart
     * POST /api/cart/add?userId=1
     */
    @PostMapping("/add")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
    public ResponseEntity<CartDTO> addToCart(
            @RequestParam Long userId,
            @Valid @RequestBody AddToCartRequest request,
            @AuthenticationPrincipal CustomUserDetails currentUser) {
        
        // Customers can only add to their own cart
        String role = currentUser.getRole();
        if (!role.equals("ADMIN") && !userId.equals(currentUser.getUserId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You can only modify your own cart");
        }
        
        logger.info("REST request to add product {} to cart for user {}", 
                    request.getProductId(), userId);
        CartDTO cart = cartService.addToCart(userId, request.getProductId(), request.getQuantity());
        return ResponseEntity.ok(cart);
    }

    /**
     * Update cart item quantity
     * PUT /api/cart/update?userId=1&productId=1&quantity=3
     */
    @PutMapping("/update")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
    public ResponseEntity<CartDTO> updateCartItemQuantity(
            @RequestParam Long userId,
            @RequestParam Long productId,
            @RequestParam Integer quantity,
            @AuthenticationPrincipal CustomUserDetails currentUser) {
        
        String role = currentUser.getRole();
        if (!role.equals("ADMIN") && !userId.equals(currentUser.getUserId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You can only modify your own cart");
        }
        
        logger.info("REST request to update cart item quantity for user {}, product {}, quantity {}", 
                    userId, productId, quantity);
        CartDTO cart = cartService.updateCartItemQuantity(userId, productId, quantity);
        return ResponseEntity.ok(cart);
    }

    /**
     * Remove product from cart
     * DELETE /api/cart/remove?userId=1&productId=1
     */
    @DeleteMapping("/remove")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
    public ResponseEntity<CartDTO> removeFromCart(
            @RequestParam Long userId,
            @RequestParam Long productId,
            @AuthenticationPrincipal CustomUserDetails currentUser) {
        
        String role = currentUser.getRole();
        if (!role.equals("ADMIN") && !userId.equals(currentUser.getUserId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You can only modify your own cart");
        }
        
        logger.info("REST request to remove product {} from cart for user {}", 
                    productId, userId);
        CartDTO cart = cartService.removeFromCart(userId, productId);
        return ResponseEntity.ok(cart);
    }

    /**
     * Clear entire cart
     * DELETE /api/cart/clear?userId=1
     */
    @DeleteMapping("/clear")
    @PreAuthorize("hasAnyRole('CUSTOMER', 'ADMIN')")
    public ResponseEntity<Void> clearCart(
            @RequestParam Long userId,
            @AuthenticationPrincipal CustomUserDetails currentUser) {
        
        String role = currentUser.getRole();
        if (!role.equals("ADMIN") && !userId.equals(currentUser.getUserId())) {
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You can only modify your own cart");
        }
        
        logger.info("REST request to clear cart for user {}", userId);
        cartService.clearCart(userId);
        return ResponseEntity.noContent().build();
    }
}
