package com.pd.my_app.filter;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * Request/Response Logging Filter for Audit Trail
 * Logs all HTTP requests and responses for security and debugging purposes
 */
@Component
public class RequestResponseLoggingFilter implements Filter {

    private static final Logger logger = LoggerFactory.getLogger(RequestResponseLoggingFilter.class);

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        long startTime = System.currentTimeMillis();

        try {
            // Log request details
            logRequest(httpRequest);

            // Process the request
            chain.doFilter(request, response);

        } finally {
            long duration = System.currentTimeMillis() - startTime;

            // Log response details
            logResponse(httpResponse, duration);
        }
    }

    private void logRequest(HttpServletRequest request) {
        String uri = request.getRequestURI();
        String method = request.getMethod();
        String queryString = request.getQueryString();

        // Skip logging for actuator endpoints and static resources
        if (uri.contains("/actuator") || uri.contains("/swagger") || uri.contains("/v3/api-docs")) {
            return;
        }

        StringBuilder logMessage = new StringBuilder();
        logMessage.append("Incoming Request: ")
                .append(method).append(" ")
                .append(uri);

        if (queryString != null) {
            logMessage.append("?").append(queryString);
        }

        logger.info(logMessage.toString());
    }

    private void logResponse(HttpServletResponse response, long duration) {
        int status = response.getStatus();

        StringBuilder logMessage = new StringBuilder();
        logMessage.append("Outgoing Response: ")
                .append("Status=").append(status)
                .append(", Duration=").append(duration).append("ms");

        if (status >= 400) {
            logger.warn(logMessage.toString());
        } else {
            logger.info(logMessage.toString());
        }
    }
}
