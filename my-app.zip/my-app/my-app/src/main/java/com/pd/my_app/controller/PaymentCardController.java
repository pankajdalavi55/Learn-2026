package com.pd.my_app.controller;

import com.pd.my_app.dto.PaymentCardDTO;
import com.pd.my_app.security.JwtTokenUtil;
import com.pd.my_app.service.PaymentCardService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/user/cards")
public class PaymentCardController {

    @Autowired
    private PaymentCardService cardService;

    @Autowired
    private JwtTokenUtil jwtTokenUtil;

    @GetMapping
    public ResponseEntity<List<PaymentCardDTO>> getUserCards(
            @RequestHeader("Authorization") String token) {
        Long userId = getUserIdFromToken(token);
        List<PaymentCardDTO> cards = cardService.getUserCards(userId);
        return ResponseEntity.ok(cards);
    }

    @PostMapping
    public ResponseEntity<PaymentCardDTO> addCard(
            @RequestHeader("Authorization") String token,
            @Valid @RequestBody PaymentCardDTO cardDTO) {
        Long userId = getUserIdFromToken(token);
        PaymentCardDTO savedCard = cardService.addCard(userId, cardDTO);
        return ResponseEntity.status(HttpStatus.CREATED).body(savedCard);
    }

    @PutMapping("/{cardId}")
    public ResponseEntity<PaymentCardDTO> updateCard(
            @RequestHeader("Authorization") String token,
            @PathVariable Long cardId,
            @Valid @RequestBody PaymentCardDTO cardDTO) {
        Long userId = getUserIdFromToken(token);
        PaymentCardDTO updatedCard = cardService.updateCard(userId, cardId, cardDTO);
        return ResponseEntity.ok(updatedCard);
    }

    @DeleteMapping("/{cardId}")
    public ResponseEntity<Void> deleteCard(
            @RequestHeader("Authorization") String token,
            @PathVariable Long cardId) {
        Long userId = getUserIdFromToken(token);
        cardService.deleteCard(userId, cardId);
        return ResponseEntity.noContent().build();
    }

    @PatchMapping("/{cardId}/set-default")
    public ResponseEntity<PaymentCardDTO> setDefaultCard(
            @RequestHeader("Authorization") String token,
            @PathVariable Long cardId) {
        Long userId = getUserIdFromToken(token);
        PaymentCardDTO updatedCard = cardService.setDefaultCard(userId, cardId);
        return ResponseEntity.ok(updatedCard);
    }

    private Long getUserIdFromToken(String token) {
        String jwt = token.replace("Bearer ", "");
        return jwtTokenUtil.extractUserId(jwt);
    }
}
