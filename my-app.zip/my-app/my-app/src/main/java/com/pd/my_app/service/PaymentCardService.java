package com.pd.my_app.service;

import com.pd.my_app.dto.PaymentCardDTO;
import com.pd.my_app.entity.PaymentCard;
import com.pd.my_app.entity.User;
import com.pd.my_app.repository.PaymentCardRepository;
import com.pd.my_app.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import java.util.Base64;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class PaymentCardService {

    @Autowired
    private PaymentCardRepository cardRepository;

    @Autowired
    private UserRepository userRepository;

    // Simple encryption key - In production, use a secure key management system
    private static final String ENCRYPTION_KEY = "MySecretKey12345"; // 16 chars for AES-128

    public List<PaymentCardDTO> getUserCards(Long userId) {
        return cardRepository.findByUserIdOrderByIsDefaultDescCreatedAtDesc(userId)
                .stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public PaymentCardDTO addCard(Long userId, PaymentCardDTO cardDTO) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new RuntimeException("User not found"));

        // If this is the first card or is being set as default, handle defaults
        if (Boolean.TRUE.equals(cardDTO.getIsDefault())) {
            clearDefaultCards(userId);
        } else if (cardRepository.countByUserId(userId) == 0) {
            // First card should be default
            cardDTO.setIsDefault(true);
        }

        String cardNumber = cardDTO.getCardNumber();
        String encryptedCardNumber = encryptCardNumber(cardNumber);
        String lastFour = cardNumber.substring(cardNumber.length() - 4);

        PaymentCard card = new PaymentCard();
        card.setUser(user);
        card.setLabel(cardDTO.getLabel());
        card.setCardholderName(cardDTO.getCardholderName());
        card.setCardNumberEncrypted(encryptedCardNumber);
        card.setCardLastFour(lastFour);
        card.setCardType(cardDTO.getCardType());
        card.setExpiryMonth(cardDTO.getExpiryMonth());
        card.setExpiryYear(cardDTO.getExpiryYear());
        card.setIsDefault(cardDTO.getIsDefault() != null ? cardDTO.getIsDefault() : false);

        PaymentCard savedCard = cardRepository.save(card);
        return convertToDTO(savedCard);
    }

    @Transactional
    public PaymentCardDTO updateCard(Long userId, Long cardId, PaymentCardDTO cardDTO) {
        PaymentCard card = cardRepository.findByIdAndUserId(cardId, userId)
                .orElseThrow(() -> new RuntimeException("Card not found"));

        // If setting as default, clear other defaults
        if (Boolean.TRUE.equals(cardDTO.getIsDefault())) {
            clearDefaultCards(userId);
        }

        card.setLabel(cardDTO.getLabel());
        card.setCardholderName(cardDTO.getCardholderName());
        
        // Only update card number if provided
        if (cardDTO.getCardNumber() != null && !cardDTO.getCardNumber().isEmpty()) {
            String cardNumber = cardDTO.getCardNumber();
            card.setCardNumberEncrypted(encryptCardNumber(cardNumber));
            card.setCardLastFour(cardNumber.substring(cardNumber.length() - 4));
        }
        
        card.setCardType(cardDTO.getCardType());
        card.setExpiryMonth(cardDTO.getExpiryMonth());
        card.setExpiryYear(cardDTO.getExpiryYear());
        card.setIsDefault(cardDTO.getIsDefault() != null ? cardDTO.getIsDefault() : false);

        PaymentCard updatedCard = cardRepository.save(card);
        return convertToDTO(updatedCard);
    }

    @Transactional
    public void deleteCard(Long userId, Long cardId) {
        PaymentCard card = cardRepository.findByIdAndUserId(cardId, userId)
                .orElseThrow(() -> new RuntimeException("Card not found"));

        boolean wasDefault = Boolean.TRUE.equals(card.getIsDefault());
        cardRepository.delete(card);

        // If deleted card was default, set another as default
        if (wasDefault) {
            List<PaymentCard> remainingCards = cardRepository.findByUserIdOrderByIsDefaultDescCreatedAtDesc(userId);
            if (!remainingCards.isEmpty()) {
                PaymentCard newDefault = remainingCards.get(0);
                newDefault.setIsDefault(true);
                cardRepository.save(newDefault);
            }
        }
    }

    @Transactional
    public PaymentCardDTO setDefaultCard(Long userId, Long cardId) {
        PaymentCard card = cardRepository.findByIdAndUserId(cardId, userId)
                .orElseThrow(() -> new RuntimeException("Card not found"));

        clearDefaultCards(userId);
        card.setIsDefault(true);
        PaymentCard updatedCard = cardRepository.save(card);
        return convertToDTO(updatedCard);
    }

    private void clearDefaultCards(Long userId) {
        cardRepository.findByUserIdAndIsDefault(userId, true)
                .ifPresent(defaultCard -> {
                    defaultCard.setIsDefault(false);
                    cardRepository.save(defaultCard);
                });
    }

    private String encryptCardNumber(String cardNumber) {
        try {
            SecretKeySpec key = new SecretKeySpec(ENCRYPTION_KEY.getBytes(), "AES");
            Cipher cipher = Cipher.getInstance("AES");
            cipher.init(Cipher.ENCRYPT_MODE, key);
            byte[] encrypted = cipher.doFinal(cardNumber.getBytes());
            return Base64.getEncoder().encodeToString(encrypted);
        } catch (Exception e) {
            throw new RuntimeException("Error encrypting card number", e);
        }
    }

    private PaymentCardDTO convertToDTO(PaymentCard card) {
        PaymentCardDTO dto = new PaymentCardDTO();
        dto.setId(card.getId());
        dto.setLabel(card.getLabel());
        dto.setCardholderName(card.getCardholderName());
        dto.setCardLastFour(card.getCardLastFour());
        dto.setMaskedCardNumber(card.getMaskedCardNumber());
        dto.setCardType(card.getCardType());
        dto.setExpiryMonth(card.getExpiryMonth());
        dto.setExpiryYear(card.getExpiryYear());
        dto.setIsDefault(card.getIsDefault());
        return dto;
    }
}
