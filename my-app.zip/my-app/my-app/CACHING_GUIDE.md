# Complete Spring Boot Caching Guide

## Table of Contents
1. [What is Caching?](#what-is-caching)
2. [Why Use Caching?](#why-use-caching)
3. [How Caching Works](#how-caching-works)
4. [Types of Caching](#types-of-caching)
5. [Cache Strategies](#cache-strategies)
6. [Spring Boot Caching](#spring-boot-caching)
7. [Cache Providers](#cache-providers)
8. [Practical Implementation](#practical-implementation)
9. [Cache Annotations Explained](#cache-annotations-explained)
10. [Advanced Caching Concepts](#advanced-caching-concepts)
11. [Best Practices](#best-practices)
12. [Common Pitfalls](#common-pitfalls)
13. [Performance Monitoring](#performance-monitoring)
14. [Real-World Examples](#real-world-examples)

---

## What is Caching?

**Caching** is a technique of storing frequently accessed data in a temporary storage area (cache) so that future requests for that data can be served faster.

### Simple Analogy
Think of caching like keeping your favorite coffee mug on your desk instead of in the kitchen cabinet. Every time you need it, you don't have to walk to the kitchen—it's right there, saving you time!

### Technical Definition
- **Cache**: A high-speed storage layer between your application and the data source (database, API, file system)
- **Cache Hit**: When requested data is found in cache
- **Cache Miss**: When requested data is NOT found in cache and must be fetched from the original source
- **Cache Eviction**: Removing data from cache (manually or automatically)

---

## Why Use Caching?

### Benefits

1. **Performance Improvement**
   - Reduces response time from seconds to milliseconds
   - Example: Database query taking 500ms → Cache read taking 5ms (100x faster!)

2. **Reduced Database Load**
   - Fewer queries to database
   - Database can handle more concurrent users
   - Lower infrastructure costs

3. **Better User Experience**
   - Faster page loads
   - Responsive applications
   - Improved customer satisfaction

4. **Scalability**
   - Handle more requests with same resources
   - Horizontal scaling becomes easier

5. **Cost Savings**
   - Reduce expensive API calls (third-party services)
   - Lower database instance requirements

### When to Use Caching?

✅ **Good Use Cases:**
- Data that doesn't change frequently (categories, product catalogs)
- Expensive database queries (complex joins, aggregations)
- API responses from external services
- Configuration data
- User session data
- Static content (images metadata, documents)

❌ **Bad Use Cases:**
- Real-time data (stock prices, live scores)
- User-specific sensitive data (passwords, credit cards)
- Data that changes very frequently
- Large objects that consume too much memory

---

## How Caching Works

### Basic Flow

```
┌─────────────┐
│  Request    │
│  Incoming   │
└──────┬──────┘
       │
       ▼
┌─────────────────┐
│ Check Cache     │◄──── Step 1: Look in cache first
└──────┬──────────┘
       │
       ├─────────► Cache Hit (Data Found)
       │                  │
       │                  ▼
       │           ┌──────────────┐
       │           │ Return Data  │
       │           │ from Cache   │
       │           └──────────────┘
       │
       └─────────► Cache Miss (Data NOT Found)
                          │
                          ▼
                   ┌──────────────────┐
                   │ Fetch from       │◄──── Step 2: Get from database
                   │ Database         │
                   └─────────┬────────┘
                             │
                             ▼
                   ┌──────────────────┐
                   │ Store in Cache   │◄──── Step 3: Save for next time
                   └─────────┬────────┘
                             │
                             ▼
                   ┌──────────────────┐
                   │ Return Data      │
                   └──────────────────┘
```

### Cache Lifecycle

```
Data Creation → Cache Storage → Cache Hit (Multiple Times) → Cache Expiration → Cache Eviction
```

---

## Types of Caching

### 1. Client-Side Caching
**Location**: Browser, Mobile App
**Examples**: Browser cache, LocalStorage, Cookies

```
Browser Request → Check Local Cache → Server (if needed)
```

**Pros**: Very fast, reduces network calls
**Cons**: Not shared between users, storage limitations

---

### 2. Server-Side Caching

#### a) Application-Level Cache (In-Memory)
**Location**: Within application JVM
**Examples**: ConcurrentHashMap, Caffeine, Guava Cache

```java
// Simple in-memory cache
private final Map<String, Product> cache = new ConcurrentHashMap<>();

public Product getProduct(Long id) {
    return cache.computeIfAbsent(id.toString(), 
        k -> productRepository.findById(id).orElse(null));
}
```

**Pros**: Extremely fast, no network latency
**Cons**: Limited to single JVM, lost on restart

---

#### b) Distributed Cache
**Location**: Separate cache server(s)
**Examples**: Redis, Memcached, Hazelcast

```
App Server 1 ──┐
               ├──► Redis Server ──► Data
App Server 2 ──┤
               │
App Server 3 ──┘
```

**Pros**: Shared across multiple servers, persistent (Redis)
**Cons**: Network latency, additional infrastructure

---

#### c) Database Cache
**Location**: Database level
**Examples**: MySQL Query Cache, PostgreSQL Shared Buffers

**Pros**: Transparent to application
**Cons**: Limited control, specific to database

---

### 3. CDN Caching
**Location**: Content Delivery Network
**Examples**: CloudFlare, AWS CloudFront, Akamai

**Use Case**: Static assets (images, CSS, JS files)

---

### 4. Proxy Caching
**Location**: Reverse proxy
**Examples**: Nginx, Varnish, Apache

---

## Cache Strategies

### 1. Cache-Aside (Lazy Loading)

**Pattern**: Application manages cache manually

```java
// Pseudocode
public Product getProduct(Long id) {
    // 1. Check cache
    Product product = cache.get(id);
    
    if (product == null) {  // Cache Miss
        // 2. Fetch from database
        product = database.findById(id);
        
        // 3. Store in cache
        cache.put(id, product);
    }
    
    return product;
}
```

**Pros**: Simple, only cache what's needed
**Cons**: Cache miss penalty, stale data possible

**Best For**: Read-heavy applications

---

### 2. Read-Through Cache

**Pattern**: Cache sits between application and database

```
Application → Cache → Database
```

Cache automatically loads data from database on miss.

**Pros**: Simplified code, consistent behavior
**Cons**: Slower first access

---

### 3. Write-Through Cache

**Pattern**: Write to cache AND database simultaneously

```java
public void updateProduct(Product product) {
    // Write to database
    database.save(product);
    
    // Write to cache
    cache.put(product.getId(), product);
}
```

**Pros**: Data consistency, no data loss
**Cons**: Slower writes, cache pollution

---

### 4. Write-Behind (Write-Back) Cache

**Pattern**: Write to cache immediately, database asynchronously

```java
public void updateProduct(Product product) {
    // Write to cache immediately
    cache.put(product.getId(), product);
    
    // Queue for database write (async)
    writeQueue.add(product);
}
```

**Pros**: Very fast writes
**Cons**: Risk of data loss, complexity

---

### 5. Refresh-Ahead Cache

**Pattern**: Proactively refresh cache before expiration

```java
// Automatically refresh popular items
@Scheduled(fixedRate = 300000) // Every 5 minutes
public void refreshPopularProducts() {
    List<Long> popularIds = getPopularProductIds();
    popularIds.forEach(id -> {
        Product product = database.findById(id);
        cache.put(id, product);
    });
}
```

**Pros**: No cache miss for hot data
**Cons**: Wasted refreshes if data unused

---

## Spring Boot Caching

### Architecture

```
┌─────────────────────────────────────────────┐
│           Spring Application                │
│                                             │
│  ┌────────────────────────────────────┐   │
│  │    @Cacheable Methods              │   │
│  │  - getUserById()                   │   │
│  │  - getProducts()                   │   │
│  └───────────┬────────────────────────┘   │
│              │                              │
│              ▼                              │
│  ┌────────────────────────────────────┐   │
│  │  Spring Cache Abstraction          │   │
│  │  (CacheManager Interface)          │   │
│  └───────────┬────────────────────────┘   │
│              │                              │
│              ▼                              │
│  ┌────────────────────────────────────┐   │
│  │  Cache Provider Implementation     │   │
│  │  - ConcurrentMap (Simple)          │   │
│  │  - EhCache                         │   │
│  │  - Caffeine                        │   │
│  │  - Redis                           │   │
│  └────────────────────────────────────┘   │
└─────────────────────────────────────────────┘
```

### Core Components

1. **@EnableCaching**: Enables Spring's annotation-driven cache management
2. **CacheManager**: Interface to interact with cache
3. **Cache Annotations**: @Cacheable, @CachePut, @CacheEvict, etc.

---

## Cache Providers

### 1. Simple (ConcurrentHashMap) - Development

**Dependency**: None (built-in)

```java
@Configuration
@EnableCaching
public class CacheConfig {
    @Bean
    public CacheManager cacheManager() {
        return new ConcurrentMapCacheManager("products", "users");
    }
}
```

**Pros**: No setup, good for learning
**Cons**: No TTL, no persistence, limited features

---

### 2. Caffeine - Production (Single Server)

**Dependency**:
```xml
<dependency>
    <groupId>com.github.ben-manes.caffeine</groupId>
    <artifactId>caffeine</artifactId>
</dependency>
```

**Configuration**:
```java
@Configuration
@EnableCaching
public class CacheConfig {
    @Bean
    public CacheManager cacheManager() {
        CaffeineCacheManager cacheManager = new CaffeineCacheManager("products", "users");
        cacheManager.setCaffeine(caffeineCacheBuilder());
        return cacheManager;
    }

    Caffeine<Object, Object> caffeineCacheBuilder() {
        return Caffeine.newBuilder()
            .initialCapacity(100)           // Initial capacity
            .maximumSize(1000)              // Max 1000 entries
            .expireAfterWrite(10, TimeUnit.MINUTES)  // TTL: 10 minutes
            .recordStats();                 // Enable statistics
    }
}
```

**Pros**: High performance, TTL support, stats
**Cons**: Single JVM only

---

### 3. Redis - Production (Distributed)

**Dependency**:
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-data-redis</artifactId>
</dependency>
```

**application.yaml**:
```yaml
spring:
  redis:
    host: localhost
    port: 6379
    password: your-password
    timeout: 2000
  cache:
    type: redis
    redis:
      time-to-live: 600000  # 10 minutes in milliseconds
```

**Configuration**:
```java
@Configuration
@EnableCaching
public class RedisCacheConfig {
    
    @Bean
    public CacheManager cacheManager(RedisConnectionFactory connectionFactory) {
        RedisCacheConfiguration config = RedisCacheConfiguration.defaultCacheConfig()
            .entryTtl(Duration.ofMinutes(10))
            .serializeKeysWith(
                RedisSerializationContext.SerializationPair.fromSerializer(
                    new StringRedisSerializer()))
            .serializeValuesWith(
                RedisSerializationContext.SerializationPair.fromSerializer(
                    new GenericJackson2JsonRedisSerializer()))
            .disableCachingNullValues();

        return RedisCacheManager.builder(connectionFactory)
            .cacheDefaults(config)
            .transactionAware()
            .build();
    }
}
```

**Pros**: Distributed, persistent, pub/sub support
**Cons**: Network latency, requires Redis server

---

### 4. EhCache - Production (Single Server)

**Dependency**:
```xml
<dependency>
    <groupId>org.ehcache</groupId>
    <artifactId>ehcache</artifactId>
</dependency>
```

**ehcache.xml**:
```xml
<config xmlns="http://www.ehcache.org/v3">
    <cache alias="products">
        <expiry>
            <ttl unit="minutes">10</ttl>
        </expiry>
        <heap unit="entries">1000</heap>
    </cache>
</config>
```

---

## Practical Implementation

### Step 1: Add Dependency

**Maven (pom.xml)**:
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-cache</artifactId>
</dependency>
```

**Gradle (build.gradle)**:
```gradle
implementation 'org.springframework.boot:spring-boot-starter-cache'
```

---

### Step 2: Enable Caching

```java
@SpringBootApplication
@EnableCaching  // ← Enable caching
public class MyApplication {
    public static void main(String[] args) {
        SpringApplication.run(MyApplication.class, args);
    }
}
```

**OR** in a separate configuration class:

```java
@Configuration
@EnableCaching
public class CacheConfig {
    @Bean
    public CacheManager cacheManager() {
        return new ConcurrentMapCacheManager("products", "categories", "users");
    }
}
```

---

### Step 3: Configure Cache Names

**application.yaml**:
```yaml
spring:
  cache:
    type: simple  # simple, caffeine, redis, ehcache
    cache-names: products, categories, users, orders
```

---

### Step 4: Apply Cache Annotations

#### Basic Example

```java
@Service
public class ProductService {
    
    @Autowired
    private ProductRepository repository;
    
    // Cache the result
    @Cacheable(value = "products", key = "#id")
    public Product getProductById(Long id) {
        System.out.println("Fetching from database: " + id);
        return repository.findById(id).orElse(null);
    }
    
    // Update cache after modification
    @CachePut(value = "products", key = "#product.id")
    public Product updateProduct(Product product) {
        return repository.save(product);
    }
    
    // Remove from cache
    @CacheEvict(value = "products", key = "#id")
    public void deleteProduct(Long id) {
        repository.deleteById(id);
    }
    
    // Clear entire cache
    @CacheEvict(value = "products", allEntries = true)
    public void clearCache() {
        // Cache cleared
    }
}
```

---

## Cache Annotations Explained

### 1. @Cacheable - Read from Cache

**Purpose**: Cache method result, return cached value on subsequent calls

```java
@Cacheable(value = "products", key = "#id")
public Product getProductById(Long id) {
    return database.findById(id);
}
```

**Flow**:
1. Check if result exists in "products" cache with key = id
2. If YES → Return cached result (skip method execution)
3. If NO → Execute method, store result in cache, return result

**Parameters**:
- `value/cacheNames`: Cache name(s)
- `key`: Cache key (SpEL expression)
- `condition`: When to cache (SpEL)
- `unless`: When NOT to cache (SpEL)

**Examples**:

```java
// Simple key
@Cacheable("products")
public List<Product> getAllProducts() { ... }

// Composite key
@Cacheable(value = "products", key = "#category + '-' + #brand")
public List<Product> getProducts(String category, String brand) { ... }

// Conditional caching
@Cacheable(value = "products", condition = "#id > 0")
public Product getProduct(Long id) { ... }

// Don't cache null results
@Cacheable(value = "products", unless = "#result == null")
public Product findProduct(Long id) { ... }

// Complex key with multiple parameters
@Cacheable(value = "products", key = "{#page, #size, #sort}")
public Page<Product> getProducts(int page, int size, String sort) { ... }
```

---

### 2. @CachePut - Update Cache

**Purpose**: Always execute method AND update cache with result

```java
@CachePut(value = "products", key = "#product.id")
public Product updateProduct(Product product) {
    return database.save(product);
}
```

**Flow**:
1. ALWAYS execute method
2. Store result in cache
3. Return result

**Use Case**: Update cache when data changes

---

### 3. @CacheEvict - Remove from Cache

**Purpose**: Remove entries from cache

```java
// Remove single entry
@CacheEvict(value = "products", key = "#id")
public void deleteProduct(Long id) {
    database.deleteById(id);
}

// Clear entire cache
@CacheEvict(value = "products", allEntries = true)
public void deleteAllProducts() {
    database.deleteAll();
}

// Evict before method execution (cleanup before operation)
@CacheEvict(value = "products", beforeInvocation = true)
public void importProducts(List<Product> products) {
    database.saveAll(products);
}
```

**Parameters**:
- `allEntries`: Clear entire cache (default: false)
- `beforeInvocation`: Evict before method runs (default: false)

---

### 4. @Caching - Multiple Operations

**Purpose**: Combine multiple cache operations

```java
@Caching(
    cacheable = {
        @Cacheable(value = "products", key = "#id")
    },
    put = {
        @CachePut(value = "productsByName", key = "#result.name"),
        @CachePut(value = "productsBySku", key = "#result.sku")
    }
)
public Product getProduct(Long id) {
    return database.findById(id);
}
```

---

### 5. @CacheConfig - Class-Level Configuration

**Purpose**: Common cache configuration for all methods in class

```java
@Service
@CacheConfig(cacheNames = "products")  // Apply to all methods
public class ProductService {
    
    @Cacheable(key = "#id")  // Uses "products" cache
    public Product getById(Long id) { ... }
    
    @CacheEvict(key = "#id")  // Uses "products" cache
    public void delete(Long id) { ... }
}
```

---

## Advanced Caching Concepts

### 1. Cache Key Generation

#### SpEL (Spring Expression Language) for Keys

```java
// Parameter value
@Cacheable(key = "#id")
public Product get(Long id) { ... }

// Object property
@Cacheable(key = "#product.id")
public void save(Product product) { ... }

// Method name
@Cacheable(key = "#root.methodName")
public List<Product> getAll() { ... }

// Composite key
@Cacheable(key = "{#user.id, #category}")
public List<Product> getUserProducts(User user, String category) { ... }

// Conditional key
@Cacheable(key = "#id != null ? #id : 'default'")
public Product get(Long id) { ... }
```

#### Custom Key Generator

```java
@Component
public class CustomKeyGenerator implements KeyGenerator {
    
    @Override
    public Object generate(Object target, Method method, Object... params) {
        return method.getName() + "_" + 
               Arrays.stream(params)
                     .map(String::valueOf)
                     .collect(Collectors.joining("_"));
    }
}

// Usage
@Cacheable(keyGenerator = "customKeyGenerator")
public Product getProduct(Long id, String locale) { ... }
```

---

### 2. Conditional Caching

```java
// Cache only if ID is positive
@Cacheable(value = "products", condition = "#id > 0")
public Product getProduct(Long id) { ... }

// Don't cache if result is null
@Cacheable(value = "products", unless = "#result == null")
public Product findProduct(Long id) { ... }

// Cache only for active users
@Cacheable(value = "data", condition = "#user.active")
public Data getData(User user) { ... }

// Don't cache expensive results
@Cacheable(value = "reports", unless = "#result.size() > 1000")
public List<Report> getReports() { ... }
```

---

### 3. Time-To-Live (TTL)

#### Caffeine

```java
@Bean
public CacheManager cacheManager() {
    CaffeineCacheManager manager = new CaffeineCacheManager();
    manager.setCaffeine(Caffeine.newBuilder()
        .expireAfterWrite(10, TimeUnit.MINUTES)     // Expire 10 min after write
        .expireAfterAccess(5, TimeUnit.MINUTES)     // Expire 5 min after last access
        .maximumSize(1000));
    return manager;
}
```

#### Redis

```java
@Bean
public RedisCacheConfiguration cacheConfiguration() {
    return RedisCacheConfiguration.defaultCacheConfig()
        .entryTtl(Duration.ofMinutes(10));  // 10 minutes TTL
}
```

#### Per-Cache TTL

```java
@Bean
public CacheManager cacheManager(RedisConnectionFactory factory) {
    Map<String, RedisCacheConfiguration> cacheConfigs = new HashMap<>();
    
    // Products: 10 minutes
    cacheConfigs.put("products", 
        RedisCacheConfiguration.defaultCacheConfig()
            .entryTtl(Duration.ofMinutes(10)));
    
    // Categories: 1 hour (rarely change)
    cacheConfigs.put("categories", 
        RedisCacheConfiguration.defaultCacheConfig()
            .entryTtl(Duration.ofHours(1)));
    
    // User sessions: 30 minutes
    cacheConfigs.put("sessions", 
        RedisCacheConfiguration.defaultCacheConfig()
            .entryTtl(Duration.ofMinutes(30)));
    
    return RedisCacheManager.builder(factory)
        .withInitialCacheConfigurations(cacheConfigs)
        .build();
}
```

---

### 4. Cache Synchronization (Preventing Cache Stampede)

```java
// WITHOUT sync: Multiple threads fetch same data simultaneously
@Cacheable("products")
public Product getProduct(Long id) { ... }

// WITH sync: Only one thread fetches, others wait
@Cacheable(value = "products", key = "#id", sync = true)
public Product getProduct(Long id) {
    // Only executed by one thread
    return expensiveDatabaseQuery(id);
}
```

**Use When**: 
- Expensive operations
- High traffic
- Cold cache scenarios

---

### 5. Multi-Level Caching

```java
// Level 1: Local cache (fast)
// Level 2: Redis (distributed)

@Configuration
public class MultiLevelCacheConfig {
    
    @Bean
    public CacheManager cacheManager(RedisConnectionFactory redis) {
        // Local cache (L1)
        CaffeineCacheManager local = new CaffeineCacheManager();
        local.setCaffeine(Caffeine.newBuilder()
            .maximumSize(100)
            .expireAfterWrite(2, TimeUnit.MINUTES));
        
        // Redis cache (L2)
        RedisCacheManager distributed = RedisCacheManager
            .builder(redis)
            .cacheDefaults(RedisCacheConfiguration.defaultCacheConfig()
                .entryTtl(Duration.ofMinutes(10)))
            .build();
        
        // Chain them
        return new CompositeCacheManager(local, distributed);
    }
}
```

---

### 6. Cache Statistics

```java
@Component
public class CacheMonitor {
    
    @Autowired
    private CacheManager cacheManager;
    
    public void printStats() {
        Cache cache = cacheManager.getCache("products");
        
        if (cache instanceof CaffeineCache) {
            com.github.benmanes.caffeine.cache.Cache<Object, Object> nativeCache = 
                (com.github.benmanes.caffeine.cache.Cache<Object, Object>) 
                cache.getNativeCache();
            
            CacheStats stats = nativeCache.stats();
            
            System.out.println("Hit Count: " + stats.hitCount());
            System.out.println("Miss Count: " + stats.missCount());
            System.out.println("Hit Rate: " + stats.hitRate());
            System.out.println("Eviction Count: " + stats.evictionCount());
        }
    }
}
```

---

### 7. Manual Cache Management

```java
@Service
public class CacheManagementService {
    
    @Autowired
    private CacheManager cacheManager;
    
    // Get specific value
    public Product getCachedProduct(Long id) {
        Cache cache = cacheManager.getCache("products");
        return cache.get(id, Product.class);
    }
    
    // Put value manually
    public void cacheProduct(Long id, Product product) {
        Cache cache = cacheManager.getCache("products");
        cache.put(id, product);
    }
    
    // Remove specific key
    public void evictProduct(Long id) {
        Cache cache = cacheManager.getCache("products");
        cache.evict(id);
    }
    
    // Clear entire cache
    public void clearProductCache() {
        Cache cache = cacheManager.getCache("products");
        cache.clear();
    }
    
    // Check if key exists
    public boolean isProductCached(Long id) {
        Cache cache = cacheManager.getCache("products");
        return cache.get(id) != null;
    }
}
```

---

## Best Practices

### 1. Choose Appropriate Cache Names

```java
// ❌ Bad: Generic names
@Cacheable("cache1")
@Cacheable("data")

// ✅ Good: Descriptive names
@Cacheable("products")
@Cacheable("activeUserSessions")
@Cacheable("productsByCategory")
```

---

### 2. Use Meaningful Cache Keys

```java
// ❌ Bad: Non-unique keys
@Cacheable(value = "products", key = "#root.methodName")

// ✅ Good: Unique, meaningful keys
@Cacheable(value = "products", key = "#id")
@Cacheable(value = "products", key = "{#category, #brand, #page}")
```

---

### 3. Set Appropriate TTL

```java
// Static/rarely changing data → Long TTL
@Cacheable("countries")  // TTL: 24 hours
public List<Country> getAllCountries() { ... }

// Frequently changing data → Short TTL
@Cacheable("stockPrices")  // TTL: 1 minute
public StockPrice getPrice(String symbol) { ... }

// User-specific data → Medium TTL
@Cacheable("userPreferences")  // TTL: 30 minutes
public Preferences getUserPrefs(Long userId) { ... }
```

---

### 4. Handle Cache Failures Gracefully

```java
@Cacheable(value = "products", key = "#id")
public Product getProduct(Long id) {
    try {
        return productRepository.findById(id)
            .orElseThrow(() -> new ProductNotFoundException(id));
    } catch (Exception e) {
        log.error("Error fetching product: " + id, e);
        // Don't cache errors
        throw e;
    }
}
```

---

### 5. Don't Cache Large Objects

```java
// ❌ Bad: Caching entire order history
@Cacheable("userOrders")
public List<Order> getAllUserOrders(Long userId) {
    return orderRepository.findByUserId(userId); // Could be 1000s
}

// ✅ Good: Cache with pagination
@Cacheable(value = "userOrders", key = "{#userId, #page, #size}")
public Page<Order> getUserOrders(Long userId, int page, int size) {
    return orderRepository.findByUserId(userId, PageRequest.of(page, size));
}
```

---

### 6. Invalidate Cache Strategically

```java
@Service
public class ProductService {
    
    // Create invalidates ALL products
    @CacheEvict(value = "products", allEntries = true)
    public Product createProduct(Product product) {
        return repository.save(product);
    }
    
    // Update invalidates specific product + list
    @Caching(evict = {
        @CacheEvict(value = "products", key = "#product.id"),
        @CacheEvict(value = "productList", allEntries = true)
    })
    public Product updateProduct(Product product) {
        return repository.save(product);
    }
    
    // Delete removes specific product
    @CacheEvict(value = "products", key = "#id")
    public void deleteProduct(Long id) {
        repository.deleteById(id);
    }
}
```

---

### 7. Monitor Cache Performance

```java
@Aspect
@Component
public class CacheMonitoringAspect {
    
    private static final Logger log = LoggerFactory.getLogger(CacheMonitoringAspect.class);
    
    @Around("@annotation(org.springframework.cache.annotation.Cacheable)")
    public Object monitorCache(ProceedingJoinPoint joinPoint) throws Throwable {
        long start = System.currentTimeMillis();
        Object result = joinPoint.proceed();
        long duration = System.currentTimeMillis() - start;
        
        log.info("Method: {}, Duration: {}ms", 
            joinPoint.getSignature().getName(), duration);
        
        return result;
    }
}
```

---

### 8. Use @CacheConfig for Class-Level Settings

```java
// ❌ Bad: Repeat cache name everywhere
@Service
public class ProductService {
    @Cacheable(value = "products", key = "#id")
    public Product get(Long id) { ... }
    
    @CacheEvict(value = "products", key = "#id")
    public void delete(Long id) { ... }
}

// ✅ Good: Define once
@Service
@CacheConfig(cacheNames = "products")
public class ProductService {
    @Cacheable(key = "#id")
    public Product get(Long id) { ... }
    
    @CacheEvict(key = "#id")
    public void delete(Long id) { ... }
}
```

---

### 9. Avoid Caching in Transactions

```java
// ❌ Bad: Cache might contain uncommitted data
@Transactional
@Cacheable("products")
public Product createProduct(Product product) {
    return repository.save(product);
    // Transaction might rollback!
}

// ✅ Good: Cache after transaction commits
@Service
public class ProductService {
    
    @Transactional
    public Product createProduct(Product product) {
        return repository.save(product);
    }
    
    @Cacheable("products")
    public Product getProduct(Long id) {
        return repository.findById(id).orElse(null);
    }
}
```

---

### 10. Test Cache Behavior

```java
@SpringBootTest
class ProductServiceCacheTest {
    
    @Autowired
    private ProductService service;
    
    @Autowired
    private CacheManager cacheManager;
    
    @Test
    void testCaching() {
        // First call - cache miss
        Product p1 = service.getProduct(1L);
        
        // Second call - should be cached
        Product p2 = service.getProduct(1L);
        
        // Verify cache hit
        Cache cache = cacheManager.getCache("products");
        assertNotNull(cache.get(1L));
    }
    
    @Test
    void testCacheEviction() {
        service.getProduct(1L);  // Cache it
        
        service.deleteProduct(1L);  // Should evict
        
        Cache cache = cacheManager.getCache("products");
        assertNull(cache.get(1L));  // Verify evicted
    }
}
```

---

## Common Pitfalls

### 1. Forgetting to Enable Caching

```java
// ❌ Missing @EnableCaching
@SpringBootApplication
public class MyApp { ... }

// ✅ Correct
@SpringBootApplication
@EnableCaching
public class MyApp { ... }
```

---

### 2. Caching Non-Serializable Objects (Redis)

```java
// ❌ Bad: Class not serializable for Redis
public class Product {
    private Long id;
    private String name;
    // No Serializable interface
}

// ✅ Good: Use JSON serialization
@Configuration
public class RedisConfig {
    @Bean
    public RedisTemplate<String, Object> redisTemplate(RedisConnectionFactory factory) {
        RedisTemplate<String, Object> template = new RedisTemplate<>();
        template.setConnectionFactory(factory);
        template.setValueSerializer(new GenericJackson2JsonRedisSerializer());
        return template;
    }
}
```

---

### 3. Cache Stampede (Thundering Herd)

```java
// ❌ Problem: Multiple requests hit database when cache expires
@Cacheable("products")
public Product getProduct(Long id) {
    return database.findById(id);
}

// ✅ Solution: Use sync=true
@Cacheable(value = "products", key = "#id", sync = true)
public Product getProduct(Long id) {
    return database.findById(id);
}
```

---

### 4. Caching Null Values

```java
// ❌ Bad: Caches null, can't differentiate not-found vs not-loaded
@Cacheable("products")
public Product getProduct(Long id) {
    return repository.findById(id).orElse(null);
}

// ✅ Good: Don't cache nulls
@Cacheable(value = "products", unless = "#result == null")
public Product getProduct(Long id) {
    return repository.findById(id).orElse(null);
}

// ✅ Better: Use Optional
@Cacheable("products")
public Optional<Product> getProduct(Long id) {
    return repository.findById(id);
}
```

---

### 5. Self-Invocation Not Cached

```java
@Service
public class ProductService {
    
    @Cacheable("products")
    public Product getProduct(Long id) {
        return repository.findById(id).orElse(null);
    }
    
    // ❌ Bad: Self-invocation bypasses proxy
    public List<Product> getProducts(List<Long> ids) {
        return ids.stream()
            .map(this::getProduct)  // NOT cached!
            .collect(Collectors.toList());
    }
    
    // ✅ Good: Use another bean
    @Autowired
    private ProductService self;
    
    public List<Product> getProducts(List<Long> ids) {
        return ids.stream()
            .map(self::getProduct)  // Cached!
            .collect(Collectors.toList());
    }
}
```

---

### 6. Inconsistent Cache Keys

```java
// ❌ Bad: Different methods, same cache, incompatible keys
@Cacheable(value = "products", key = "#id")
public Product getById(Long id) { ... }

@Cacheable(value = "products", key = "#sku")
public Product getBySku(String sku) { ... }
// Key collision if id == sku!

// ✅ Good: Include discriminator
@Cacheable(value = "products", key = "'id:' + #id")
public Product getById(Long id) { ... }

@Cacheable(value = "products", key = "'sku:' + #sku")
public Product getBySku(String sku) { ... }
```

---

### 7. Over-Caching

```java
// ❌ Bad: Caching everything
@Cacheable("data")
public RealTimeStockPrice getStockPrice() { ... }

@Cacheable("data")
public CurrentDateTime getTime() { ... }

@Cacheable("data")
public UserPassword getPassword(Long userId) { ... }  // Security risk!
```

---

## Performance Monitoring

### 1. Enable Actuator Metrics

**pom.xml**:
```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-actuator</artifactId>
</dependency>
<dependency>
    <groupId>io.micrometer</groupId>
    <artifactId>micrometer-registry-prometheus</artifactId>
</dependency>
```

**application.yaml**:
```yaml
management:
  endpoints:
    web:
      exposure:
        include: health,info,metrics,prometheus
  metrics:
    cache:
      enabled: true
```

**Access Metrics**:
- http://localhost:8080/actuator/metrics/cache.size
- http://localhost:8080/actuator/metrics/cache.gets
- http://localhost:8080/actuator/metrics/cache.puts
- http://localhost:8080/actuator/metrics/cache.evictions

---

### 2. Custom Cache Metrics

```java
@Component
public class CacheMetricsCollector {
    
    @Autowired
    private CacheManager cacheManager;
    
    @Scheduled(fixedRate = 60000)  // Every minute
    public void collectMetrics() {
        cacheManager.getCacheNames().forEach(cacheName -> {
            Cache cache = cacheManager.getCache(cacheName);
            
            if (cache instanceof CaffeineCache) {
                com.github.benmanes.caffeine.cache.Cache<?, ?> caffeineCache = 
                    (com.github.benmanes.caffeine.cache.Cache<?, ?>) 
                    cache.getNativeCache();
                
                CacheStats stats = caffeineCache.stats();
                
                log.info("Cache: {}, Hits: {}, Misses: {}, Hit Rate: {:.2f}%",
                    cacheName, 
                    stats.hitCount(), 
                    stats.missCount(),
                    stats.hitRate() * 100);
            }
        });
    }
}
```

---

### 3. Cache Hit Rate Formula

```
Hit Rate = (Cache Hits) / (Cache Hits + Cache Misses)

Example:
- Hits: 950
- Misses: 50
- Hit Rate = 950 / (950 + 50) = 950 / 1000 = 95%
```

**Interpretation**:
- 95%+ : Excellent
- 80-95% : Good
- 60-80% : Fair
- <60% : Poor (consider adjusting cache strategy)

---

## Real-World Examples

### Example 1: E-Commerce Product Catalog

```java
@Service
@CacheConfig(cacheNames = "products")
public class ProductService {
    
    @Autowired
    private ProductRepository repository;
    
    // Cache individual product (rarely changes)
    @Cacheable(key = "#id", unless = "#result == null")
    public Product getProductById(Long id) {
        log.info("Fetching product {} from database", id);
        return repository.findById(id).orElse(null);
    }
    
    // Cache product list by category
    @Cacheable(key = "'category:' + #categoryId + ':page:' + #page")
    public Page<Product> getProductsByCategory(Long categoryId, int page) {
        log.info("Fetching products for category {} from database", categoryId);
        return repository.findByCategoryId(categoryId, PageRequest.of(page, 20));
    }
    
    // Cache search results (short TTL recommended)
    @Cacheable(
        value = "productSearch",
        key = "'search:' + #keyword + ':page:' + #page"
    )
    public Page<Product> searchProducts(String keyword, int page) {
        return repository.searchByKeyword(keyword, PageRequest.of(page, 20));
    }
    
    // Update product - invalidate caches
    @Caching(evict = {
        @CacheEvict(key = "#product.id"),
        @CacheEvict(value = "productSearch", allEntries = true),
        @CacheEvict(
            value = "products", 
            key = "'category:' + #product.category.id + ':page:*'"
        )
    })
    public Product updateProduct(Product product) {
        log.info("Updating product {} and invalidating caches", product.getId());
        return repository.save(product);
    }
    
    // Bulk update - clear all caches
    @CacheEvict(allEntries = true)
    public void updatePrices(List<Product> products) {
        log.info("Bulk updating {} products, clearing cache", products.size());
        repository.saveAll(products);
    }
}
```

---

### Example 2: User Session Management

```java
@Service
public class UserSessionService {
    
    // Cache user sessions (30 min TTL recommended)
    @Cacheable(value = "userSessions", key = "#userId")
    public UserSession getUserSession(Long userId) {
        return sessionRepository.findByUserId(userId);
    }
    
    // Update session
    @CachePut(value = "userSessions", key = "#session.userId")
    public UserSession updateSession(UserSession session) {
        return sessionRepository.save(session);
    }
    
    // Logout - remove session
    @CacheEvict(value = "userSessions", key = "#userId")
    public void logout(Long userId) {
        sessionRepository.deleteByUserId(userId);
    }
    
    // Cleanup expired sessions
    @Scheduled(cron = "0 0 * * * *")  // Every hour
    @CacheEvict(value = "userSessions", allEntries = true)
    public void cleanupExpiredSessions() {
        log.info("Cleaning up expired sessions");
        sessionRepository.deleteExpired(LocalDateTime.now());
    }
}
```

---

### Example 3: Configuration/Reference Data

```java
@Service
@CacheConfig(cacheNames = "referenceData")
public class ReferenceDataService {
    
    // Cache countries (rarely change, long TTL)
    @Cacheable(key = "'countries'")
    public List<Country> getAllCountries() {
        return countryRepository.findAll();
    }
    
    // Cache currencies
    @Cacheable(key = "'currencies'")
    public List<Currency> getAllCurrencies() {
        return currencyRepository.findAll();
    }
    
    // Cache categories hierarchy (1 hour TTL)
    @Cacheable(key = "'categoryTree'")
    public CategoryTree getCategoryTree() {
        return buildCategoryTree(categoryRepository.findAll());
    }
    
    // Admin updates - clear specific cache
    @CacheEvict(key = "'countries'")
    public Country updateCountry(Country country) {
        return countryRepository.save(country);
    }
    
    // Refresh all reference data
    @Scheduled(cron = "0 0 2 * * *")  // 2 AM daily
    @CacheEvict(allEntries = true)
    public void refreshReferenceData() {
        log.info("Refreshing all reference data caches");
    }
}
```

---

### Example 4: API Rate Limiting with Cache

```java
@Service
public class RateLimitService {
    
    @Autowired
    private CacheManager cacheManager;
    
    private static final int MAX_REQUESTS = 100;
    private static final Duration WINDOW = Duration.ofMinutes(1);
    
    public boolean isAllowed(String userId) {
        Cache cache = cacheManager.getCache("rateLimits");
        String key = "user:" + userId;
        
        AtomicInteger counter = cache.get(key, AtomicInteger.class);
        
        if (counter == null) {
            counter = new AtomicInteger(0);
            cache.put(key, counter);
        }
        
        int requests = counter.incrementAndGet();
        
        if (requests > MAX_REQUESTS) {
            log.warn("Rate limit exceeded for user: {}", userId);
            return false;
        }
        
        return true;
    }
    
    @Scheduled(fixedRate = 60000)  // Reset every minute
    @CacheEvict(value = "rateLimits", allEntries = true)
    public void resetCounters() {
        // Counters cleared
    }
}
```

---

### Example 5: Distributed Cache with Redis

```java
@Service
public class DistributedCacheService {
    
    @Autowired
    private RedisTemplate<String, Object> redisTemplate;
    
    // Cache with custom TTL
    public void cacheWithTtl(String key, Object value, Duration ttl) {
        redisTemplate.opsForValue().set(key, value, ttl);
    }
    
    // Get from cache
    public Object getFromCache(String key) {
        return redisTemplate.opsForValue().get(key);
    }
    
    // Cache list
    public void cacheList(String key, List<?> items) {
        redisTemplate.opsForList().rightPushAll(key, items);
        redisTemplate.expire(key, Duration.ofHours(1));
    }
    
    // Cache set (unique items)
    public void cacheSet(String key, Set<?> items) {
        items.forEach(item -> 
            redisTemplate.opsForSet().add(key, item));
        redisTemplate.expire(key, Duration.ofHours(1));
    }
    
    // Distributed lock using Redis
    public boolean acquireLock(String lockKey, Duration timeout) {
        Boolean success = redisTemplate.opsForValue()
            .setIfAbsent(lockKey, "locked", timeout);
        return success != null && success;
    }
    
    public void releaseLock(String lockKey) {
        redisTemplate.delete(lockKey);
    }
}
```

---

## Summary Checklist

### Before Implementing Cache

- [ ] Identify frequently accessed data
- [ ] Measure current performance (baseline)
- [ ] Determine data change frequency
- [ ] Choose appropriate cache provider
- [ ] Define TTL strategy
- [ ] Plan cache invalidation strategy

### During Implementation

- [ ] Add spring-boot-starter-cache dependency
- [ ] Enable caching with @EnableCaching
- [ ] Configure CacheManager
- [ ] Apply cache annotations
- [ ] Use meaningful cache names
- [ ] Define proper cache keys
- [ ] Handle cache eviction
- [ ] Test cache behavior

### After Implementation

- [ ] Monitor cache hit rates
- [ ] Track performance improvements
- [ ] Adjust TTL if needed
- [ ] Review cache size
- [ ] Monitor memory usage
- [ ] Document cache strategy
- [ ] Train team on cache usage

---

## Conclusion

Caching is a powerful technique for improving application performance, but it requires careful planning and implementation. Key takeaways:

1. **Start Simple**: Begin with simple in-memory cache (ConcurrentHashMap)
2. **Measure Impact**: Always measure before and after metrics
3. **Right TTL**: Balance freshness vs performance
4. **Proper Invalidation**: Ensure data consistency
5. **Monitor Always**: Track hit rates and adjust strategy
6. **Test Thoroughly**: Verify cache behavior in different scenarios
7. **Document Well**: Explain caching decisions for team

**Remember**: Caching is not a silver bullet. Use it where it makes sense, and always consider:
- Data freshness requirements
- Memory constraints
- Complexity added
- Consistency needs

Happy Caching! 🚀

---

## Additional Resources

- [Spring Boot Caching Documentation](https://docs.spring.io/spring-boot/docs/current/reference/html/io.html#io.caching)
- [Caffeine Cache GitHub](https://github.com/ben-manes/caffeine)
- [Redis Documentation](https://redis.io/docs/)
- [Cache Patterns](https://docs.aws.amazon.com/whitepapers/latest/database-caching-strategies-using-redis/caching-patterns.html)
