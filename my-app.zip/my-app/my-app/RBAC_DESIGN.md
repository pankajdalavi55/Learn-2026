# Role-Based Access Control (RBAC) Design Documentation

## 🏗️ Architecture Overview

This system implements **enterprise-grade Role-Based Access Control (RBAC)** using Spring Security with JWT (JSON Web Tokens) for stateless authentication.

---

## 🎭 Role Hierarchy & Permissions

### 1. **CUSTOMER** (Default Role)
**Purpose**: Regular shoppers and end-users

**Permissions**:
- ✅ View all products and categories (public access)
- ✅ Register and login
- ✅ Manage **own** shopping cart (add, update, remove items)
- ✅ Place orders from **own** cart
- ✅ View **own** order history
- ✅ View and update **own** profile
- ❌ Cannot access other users' data
- ❌ Cannot manage products or categories
- ❌ Cannot view other users' carts or orders

**Use Case**: John wants to buy a laptop. He can browse products, add to his cart, and checkout - but he can't see Jane's cart or orders.

---

### 2. **VENDOR** 
**Purpose**: Third-party sellers managing their own products

**Permissions**:
- ✅ All CUSTOMER permissions
- ✅ Create new products (for their store)
- ✅ Update **own** products (price, stock, description)
- ✅ Delete **own** products
- ✅ View sales analytics for **own** products
- ✅ Manage inventory for **own** products
- ❌ Cannot modify other vendors' products
- ❌ Cannot manage categories
- ❌ Cannot access user management

**Use Case**: TechStore vendor can add their laptops, update prices, manage stock - but can't modify Amazon's products.

---

### 3. **SUPPORT** 
**Purpose**: Customer service representatives

**Permissions**:
- ✅ View all users (read-only)
- ✅ View all orders (to help customers)
- ✅ View all shopping carts (to troubleshoot issues)
- ✅ View product catalog
- ❌ Cannot modify user data
- ❌ Cannot modify products or categories
- ❌ Cannot create/delete orders
- ❌ Cannot modify cart contents

**Use Case**: Support agent Sarah can see Customer John's cart to help him troubleshoot checkout issues, but can't change his cart or personal info.

---

### 4. **MANAGER** 
**Purpose**: Operations and inventory managers

**Permissions**:
- ✅ All SUPPORT permissions (read access)
- ✅ Create, update, delete categories
- ✅ Manage ALL products and inventory (not just own)
- ✅ Update order statuses (processing, shipped, delivered)
- ✅ View analytics and reports
- ✅ Manage stock levels across all products
- ❌ Cannot manage users
- ❌ Cannot assign roles

**Use Case**: Manager Mike can organize categories, manage all product inventory, and update order statuses when items ship.

---

### 5. **ADMIN** (Superuser)
**Purpose**: System administrators with full control

**Permissions**:
- ✅ **FULL SYSTEM ACCESS**
- ✅ Manage all users (create, read, update, delete)
- ✅ Assign and change user roles
- ✅ Manage all products, categories, orders
- ✅ View all carts and customer data
- ✅ Override any restrictions
- ✅ System configuration
- ✅ Access all API endpoints

**Use Case**: Admin Alice has complete control - she can create new manager accounts, change user roles, access all data, and configure the system.

---

## 🔐 Security Implementation

### Authentication Flow

```
1. User Registration/Login
   ↓
2. Credentials validated
   ↓
3. JWT Token generated (contains: userId, email, role)
   ↓
4. Token returned to client
   ↓
5. Client includes token in Authorization header
   ↓
6. JwtAuthenticationFilter validates token
   ↓
7. SecurityContext populated with user details
   ↓
8. @PreAuthorize checks role permissions
   ↓
9. Request processed or rejected (403 Forbidden)
```

### Token Structure (JWT)
```json
{
  "sub": "john@example.com",
  "userId": 1,
  "role": "CUSTOMER",
  "iat": 1701234567,
  "exp": 1701320967
}
```

---

## 📋 API Endpoint Security Matrix

| Endpoint | Public | CUSTOMER | VENDOR | SUPPORT | MANAGER | ADMIN |
|----------|--------|----------|--------|---------|---------|-------|
| **Authentication** |
| POST /api/auth/register | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| POST /api/auth/login | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| **Products** |
| GET /api/products | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| POST /api/products | ❌ | ❌ | ✅ | ❌ | ✅ | ✅ |
| PUT /api/products/{id} | ❌ | ❌ | ✅* | ❌ | ✅ | ✅ |
| DELETE /api/products/{id} | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ |
| **Categories** |
| GET /api/categories | ✅ | ✅ | ✅ | ✅ | ✅ | ✅ |
| POST /api/categories | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ |
| PUT /api/categories/{id} | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ |
| DELETE /api/categories/{id} | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ |
| **Cart** |
| GET /api/cart | ❌ | ✅** | ❌ | ✅ | ✅ | ✅ |
| POST /api/cart/add | ❌ | ✅** | ❌ | ❌ | ❌ | ✅ |
| PUT /api/cart/update | ❌ | ✅** | ❌ | ❌ | ❌ | ✅ |
| DELETE /api/cart/remove | ❌ | ✅** | ❌ | ❌ | ❌ | ✅ |
| **Orders** |
| GET /api/orders | ❌ | ✅** | ❌ | ✅ | ✅ | ✅ |
| POST /api/orders | ❌ | ✅** | ❌ | ❌ | ❌ | ✅ |
| PATCH /api/orders/{id}/status | ❌ | ❌ | ❌ | ❌ | ✅ | ✅ |
| **Users** |
| GET /api/users | ❌ | ❌ | ❌ | ✅ | ✅ | ✅ |
| GET /api/users/{id} | ❌ | ✅** | ❌ | ✅ | ✅ | ✅ |
| POST /api/users | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |
| PUT /api/users/{id} | ❌ | ✅** | ❌ | ❌ | ❌ | ✅ |
| DELETE /api/users/{id} | ❌ | ❌ | ❌ | ❌ | ❌ | ✅ |

**Legend**:
- ✅ = Full access
- ✅* = Own resources only
- ✅** = Own data only (enforced in controller)
- ❌ = No access

---

## 🛡️ Security Features

### 1. **JWT Token Authentication**
- Stateless authentication (no server-side sessions)
- Token expiry: 24 hours (configurable)
- Signed with HS256 algorithm
- Contains user ID and role for authorization

### 2. **Password Security**
- BCrypt password hashing (10 rounds)
- Never stored in plain text
- Password strength validation (minimum 6 characters)

### 3. **Method-Level Security**
- `@PreAuthorize` annotations on controller methods
- Role-based access control at method level
- Automatic 403 Forbidden for unauthorized access

### 4. **User-Specific Data Protection**
```java
// Example: Customer can only access their own cart
if (!currentUser.getRole().equals("ADMIN") && !userId.equals(currentUser.getUserId())) {
    throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You can only access your own cart");
}
```

### 5. **CORS Configuration**
- Configurable allowed origins
- Supports credentials
- Preflight request handling

---

## 🚀 Usage Examples

### 1. Register New User
```bash
POST /api/auth/register
{
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "1234567890",
  "password": "securePassword123",
  "role": "CUSTOMER"
}

Response:
{
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "type": "Bearer",
  "userId": 1,
  "email": "john@example.com",
  "name": "John Doe",
  "role": "CUSTOMER"
}
```

### 2. Login
```bash
POST /api/auth/login
{
  "email": "john@example.com",
  "password": "securePassword123"
}

Response: (same as register)
```

### 3. Access Protected Endpoint
```bash
GET /api/cart?userId=1
Headers:
  Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
```

### 4. Create Admin User (only ADMIN can do this)
```bash
POST /api/users
Headers:
  Authorization: Bearer <admin-token>
Body:
{
  "name": "Admin Alice",
  "email": "admin@example.com",
  "phone": "1234567890",
  "password": "adminPass123",
  "role": "ADMIN"
}
```

---

## 🔧 Configuration

### JWT Settings (application.yaml)
```yaml
jwt:
  secret: myVerySecureSecretKeyThatIsAtLeast256BitsLongForHS256Algorithm
  expiration: 86400000  # 24 hours in milliseconds
```

### Security Customization
- Modify `SecurityConfig.java` to change role permissions
- Update `JwtTokenUtil.java` to change token expiration
- Configure CORS in `SecurityConfig` for frontend integration

---

## 🎯 Best Practices Implemented

1. **Least Privilege Principle**: Users get only necessary permissions
2. **Defense in Depth**: Multiple layers (JWT + @PreAuthorize + Controller validation)
3. **Secure Defaults**: New users are CUSTOMER by default
4. **Fail Secure**: Unauthorized access returns 403, not 500
5. **Audit Trail**: All security events logged
6. **Stateless**: JWT enables horizontal scaling
7. **Token Validation**: Every request validates token freshness

---

## 🚨 Security Considerations

1. **JWT Secret**: Use environment variable in production, not hardcoded
2. **HTTPS**: Always use HTTPS in production to prevent token theft
3. **Token Storage**: Store tokens securely on client (httpOnly cookies or secure storage)
4. **Token Refresh**: Implement refresh tokens for better security
5. **Rate Limiting**: Add rate limiting to prevent brute force attacks
6. **Account Lockout**: Implement after N failed login attempts
7. **Password Policy**: Enforce strong passwords in production

---

## 📊 Testing Different Roles

```bash
# Test as CUSTOMER
curl -H "Authorization: Bearer <customer-token>" http://localhost:8080/api/cart?userId=1

# Test as ADMIN (can access anyone's cart)
curl -H "Authorization: Bearer <admin-token>" http://localhost:8080/api/cart?userId=5

# Test unauthorized access (should fail with 403)
curl -H "Authorization: Bearer <customer-token>" http://localhost:8080/api/users
```

---

## 🎓 Summary

This RBAC system provides:
- ✅ **5 distinct roles** with clear responsibilities
- ✅ **Granular permissions** at API endpoint level
- ✅ **JWT-based authentication** for stateless security
- ✅ **User-specific data protection** (users can't access others' data)
- ✅ **Scalable architecture** (no server-side sessions)
- ✅ **Production-ready** with comprehensive security features

The design follows industry best practices and can be easily extended for additional roles or permissions as the application grows.
