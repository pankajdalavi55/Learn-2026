# Quick Start Guide - RBAC System Testing

## Available Test Users

| Email | Password | Role | User ID |
|-------|----------|------|---------|
| admin@test.com | Admin@123 | ADMIN | 3 |
| manager@test.com | Manager@123 | MANAGER | 4 |
| support@test.com | Support@123 | SUPPORT | 5 |
| vendor@test.com | Vendor@123 | VENDOR | 6 |
| customer1@test.com | Customer@123 | CUSTOMER | 7 |
| customer2@test.com | Customer@123 | CUSTOMER | 8 |

## Quick Test Commands (PowerShell)

### 1. Login and Get Token
```powershell
# Login as Customer1
$body = '{"email":"customer1@test.com","password":"Customer@123"}'
$response = Invoke-WebRequest -Uri http://localhost:8080/api/auth/login -Method POST -ContentType "application/json" -Body $body | ConvertFrom-Json
$token = $response.token
Write-Host "Token: $token"
```

### 2. Access Own Cart (Customer)
```powershell
$headers = @{Authorization = "Bearer $token"}
$response = Invoke-WebRequest -Uri "http://localhost:8080/api/cart?userId=7" -Method GET -Headers $headers
$response.Content
```

### 3. Try to Access Another User's Cart (Should Fail with 403)
```powershell
try {
    Invoke-WebRequest -Uri "http://localhost:8080/api/cart?userId=8" -Method GET -Headers $headers
} catch {
    Write-Host "Blocked! Status: $($_.Exception.Response.StatusCode.value__)"
}
```

### 4. Login as Admin
```powershell
$body = '{"email":"admin@test.com","password":"Admin@123"}'
$response = Invoke-WebRequest -Uri http://localhost:8080/api/auth/login -Method POST -ContentType "application/json" -Body $body | ConvertFrom-Json
$adminToken = $response.token
```

### 5. Admin Access Any Cart
```powershell
$headers = @{Authorization = "Bearer $adminToken"}
# Access Customer1's cart
Invoke-WebRequest -Uri "http://localhost:8080/api/cart?userId=7" -Method GET -Headers $headers
# Access Customer2's cart
Invoke-WebRequest -Uri "http://localhost:8080/api/cart?userId=8" -Method GET -Headers $headers
```

### 6. Add Product to Cart
```powershell
$headers = @{Authorization = "Bearer $token"}
$body = '{"productId":6,"quantity":1}'
Invoke-WebRequest -Uri "http://localhost:8080/api/cart/add?userId=7" -Method POST -Headers $headers -ContentType "application/json" -Body $body
```

### 7. Public Endpoint (No Auth Required)
```powershell
# Get products (public)
Invoke-WebRequest -Uri "http://localhost:8080/api/products?page=0&size=5" -Method GET
```

### 8. View Cart Contents
```powershell
$headers = @{Authorization = "Bearer $token"}
$response = Invoke-WebRequest -Uri "http://localhost:8080/api/cart?userId=7" -Method GET -Headers $headers | ConvertFrom-Json
Write-Host "Total: `$$($response.totalAmount)"
Write-Host "Items: $($response.totalItems)"
$response.items | ForEach-Object { Write-Host "  - $($_.productName): $($_.quantity) x `$$($_.price) = `$$($_.subtotal)" }
```

## Test Scenarios

### ✅ Scenario 1: Customer Self-Service
```powershell
# Login as customer1
$body = '{"email":"customer1@test.com","password":"Customer@123"}'
$resp = Invoke-WebRequest -Uri http://localhost:8080/api/auth/login -Method POST -ContentType "application/json" -Body $body | ConvertFrom-Json
$token = $resp.token

# View own cart
$headers = @{Authorization = "Bearer $token"}
Invoke-WebRequest -Uri "http://localhost:8080/api/cart?userId=7" -Method GET -Headers $headers

# Add product
$body = '{"productId":4,"quantity":1}'
Invoke-WebRequest -Uri "http://localhost:8080/api/cart/add?userId=7" -Method POST -Headers $headers -ContentType "application/json" -Body $body
```

### ✅ Scenario 2: Admin Managing Users
```powershell
# Login as admin
$body = '{"email":"admin@test.com","password":"Admin@123"}'
$resp = Invoke-WebRequest -Uri http://localhost:8080/api/auth/login -Method POST -ContentType "application/json" -Body $body | ConvertFrom-Json
$adminToken = $resp.token

# View any user's cart
$headers = @{Authorization = "Bearer $adminToken"}
Invoke-WebRequest -Uri "http://localhost:8080/api/cart?userId=7" -Method GET -Headers $headers
Invoke-WebRequest -Uri "http://localhost:8080/api/cart?userId=8" -Method GET -Headers $headers

# Admin can add to any cart
$body = '{"productId":5,"quantity":2}'
Invoke-WebRequest -Uri "http://localhost:8080/api/cart/add?userId=8" -Method POST -Headers $headers -ContentType "application/json" -Body $body
```

### ❌ Scenario 3: Unauthorized Access (Should Fail)
```powershell
# Customer1 trying to access Customer2's data
$body = '{"email":"customer1@test.com","password":"Customer@123"}'
$resp = Invoke-WebRequest -Uri http://localhost:8080/api/auth/login -Method POST -ContentType "application/json" -Body $body | ConvertFrom-Json
$token = $resp.token
$headers = @{Authorization = "Bearer $token"}

try {
    # This should fail with 403
    Invoke-WebRequest -Uri "http://localhost:8080/api/cart?userId=8" -Method GET -Headers $headers
} catch {
    Write-Host "✓ Correctly blocked: $($_.Exception.Response.StatusCode)"
}
```

## Swagger UI Access

Open in browser: http://localhost:8080/swagger-ui/index.html

1. Click "Authorize" button
2. Enter: `Bearer <your_jwt_token>`
3. Test APIs interactively

## Common HTTP Status Codes

- **200 OK**: Success
- **403 Forbidden**: Access denied (wrong role or accessing other user's data)
- **401 Unauthorized**: No token or invalid token
- **404 Not Found**: Resource doesn't exist
- **500 Internal Server Error**: Server error (check logs)

## Troubleshooting

### Token Expired
If you get 403 errors, re-login to get a fresh token (tokens expire after 24 hours).

### Wrong User ID
Make sure you're using the correct user ID that matches your logged-in user (except for admin).

### Application Not Running
Check if the application is running:
```powershell
Invoke-WebRequest -Uri http://localhost:8080/actuator/health
```

## Role Capabilities Summary

- **CUSTOMER**: Own cart read/write, own orders, product browsing
- **VENDOR**: Product management, own inventory
- **SUPPORT**: View all carts, view all orders, assist customers
- **MANAGER**: All SUPPORT permissions + product management + reporting
- **ADMIN**: Full system access (all permissions)

## Next Steps

1. Test with different roles
2. Try placing orders
3. Test product management
4. Explore Swagger UI
5. Check application logs for security events
