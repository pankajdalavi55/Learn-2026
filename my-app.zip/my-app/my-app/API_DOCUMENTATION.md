# E-Commerce Platform API Documentation

## Overview
Complete e-commerce REST API with product catalog, shopping cart, and order management with inventory tracking.

## Features
- ✅ Product Management with filtering, search, sorting & pagination
- ✅ Shopping Cart with real-time inventory validation
- ✅ Order Management with automatic inventory updates
- ✅ Category hierarchy support
- ✅ Comprehensive exception handling
- ✅ Logging at all layers
- ✅ Input validation
- ✅ Health monitoring with Actuator

---

## API Endpoints

### Product APIs

#### Get All Products (Paginated & Sorted)
```
GET /api/products?page=0&size=20&sortBy=price&sortDir=ASC
```
**Query Parameters:**
- `page` (default: 0) - Page number
- `size` (default: 20) - Items per page
- `sortBy` (default: createdAt) - Sort field (price, name, rating, createdAt)
- `sortDir` (default: DESC) - Sort direction (ASC/DESC)

#### Advanced Product Filtering
```
GET /api/products/filter?category=1&brand=Nike&minPrice=10&maxPrice=100&keyword=shoe&page=0&size=20&sortBy=price&sortDir=ASC
```
**Query Parameters:**
- `category` - Filter by category ID
- `brand` - Filter by brand name
- `minPrice` - Minimum price
- `maxPrice` - Maximum price
- `keyword` - Search in name, description, brand
- `page`, `size`, `sortBy`, `sortDir` - Pagination & sorting

#### Search Products
```
GET /api/products/search?keyword=laptop&page=0&size=20
```

#### Get Products by Category
```
GET /api/products/category/1?page=0&size=20
```

#### Get Product by ID
```
GET /api/products/1
```

#### Get All Brands
```
GET /api/products/brands/list
```

#### Create Product
```
POST /api/products
Content-Type: application/json

{
  "name": "Laptop",
  "description": "High performance laptop",
  "price": 999.99,
  "stockQuantity": 50,
  "brand": "Dell",
  "sku": "DELL-LAP-001",
  "imageUrl": "https://example.com/image.jpg",
  "categoryId": 1,
  "isActive": true,
  "isFeatured": false
}
```

#### Update Product
```
PUT /api/products/1
Content-Type: application/json

{
  "name": "Updated Laptop",
  "price": 899.99,
  ...
}
```

#### Delete Product
```
DELETE /api/products/1
```

---

### Cart APIs

#### Get Cart
```
GET /api/cart?userId=1
```

#### Add to Cart
```
POST /api/cart/add?userId=1
Content-Type: application/json

{
  "productId": 1,
  "quantity": 2
}
```
**Features:**
- Auto-validates stock availability
- Updates quantity if product already in cart
- Prevents adding out-of-stock items

#### Update Cart Item Quantity
```
PUT /api/cart/update?userId=1&productId=1&quantity=3
```
**Features:**
- Validates stock before updating
- Recalculates cart total

#### Remove from Cart
```
DELETE /api/cart/remove?userId=1&productId=1
```

#### Clear Cart
```
DELETE /api/cart/clear?userId=1
```

---

### Order APIs

#### Place Order
```
POST /api/orders?userId=1
Content-Type: application/json

{
  "shippingAddress": "123 Main St",
  "shippingCity": "New York",
  "shippingState": "NY",
  "shippingPostalCode": "10001",
  "shippingCountry": "USA",
  "phoneNumber": "+1234567890",
  "notes": "Please deliver before 5 PM",
  "paymentMethod": "Credit Card"
}
```
**Features:**
- Validates stock for all items
- Automatically reduces inventory
- Generates unique order number
- Clears cart after successful order

#### Get Order by ID
```
GET /api/orders/1?userId=1
```

#### Get Order by Order Number
```
GET /api/orders/number/ORD-1234567890?userId=1
```

#### Get User Order History
```
GET /api/orders/user/1?page=0&size=10
```

#### Update Order Status (Admin)
```
PATCH /api/orders/1/status?status=SHIPPED
```
**Order Statuses:**
- PENDING
- CONFIRMED
- PROCESSING
- SHIPPED
- DELIVERED
- CANCELLED
- REFUNDED

#### Cancel Order
```
POST /api/orders/1/cancel?userId=1
```
**Features:**
- Only allows cancellation for PENDING/CONFIRMED orders
- Automatically restores inventory

---

### User APIs

#### Create User
```
POST /api/users
Content-Type: application/json

{
  "name": "John Doe",
  "email": "john@example.com",
  "phone": "1234567890"
}
```

#### Get User
```
GET /api/users/1
```

#### Get All Users
```
GET /api/users?active=true
```

#### Update User
```
PUT /api/users/1
```

#### Delete User
```
DELETE /api/users/1
```

---

### Health Check

#### Application Health
```
GET /actuator/health
```

#### Metrics
```
GET /actuator/metrics
```

---

## Database Schema

### Tables Created
1. **users** - User information
2. **categories** - Product categories (with hierarchy)
3. **products** - Product catalog with inventory
4. **carts** - Shopping carts
5. **cart_items** - Cart line items
6. **orders** - Order headers
7. **order_items** - Order line items

### Key Features
- Automatic timestamps (created_at, updated_at)
- Foreign key constraints
- Unique constraints (email, order_number)
- Inventory tracking with stock quantity
- Order status workflow
- Soft delete support (isActive flag)

---

## Testing the API

### Example Flow

1. **Create a User**
```bash
curl -X POST http://localhost:8080/api/users \
  -H "Content-Type: application/json" \
  -d '{"name":"John","email":"john@test.com","phone":"1234567890"}'
```

2. **Create Categories & Products**
```bash
# Create category first, then products with categoryId
```

3. **Browse Products**
```bash
curl "http://localhost:8080/api/products?page=0&size=10&sortBy=price&sortDir=ASC"
```

4. **Add to Cart**
```bash
curl -X POST "http://localhost:8080/api/cart/add?userId=1" \
  -H "Content-Type: application/json" \
  -d '{"productId":1,"quantity":2}'
```

5. **Place Order**
```bash
curl -X POST "http://localhost:8080/api/orders?userId=1" \
  -H "Content-Type: application/json" \
  -d '{
    "shippingAddress":"123 Main St",
    "shippingCity":"New York",
    "shippingState":"NY",
    "shippingPostalCode":"10001",
    "shippingCountry":"USA",
    "phoneNumber":"+1234567890",
    "paymentMethod":"Credit Card"
  }'
```

---

## Error Handling

All errors return structured JSON responses:

```json
{
  "status": 404,
  "message": "Product not found with id: 123",
  "timestamp": "2025-11-29T10:30:00"
}
```

### Common Error Codes
- **400** - Bad Request (validation errors, insufficient stock)
- **404** - Not Found (product, user, order not found)
- **409** - Conflict (duplicate email)
- **500** - Internal Server Error

---

## Architecture

### Layer Structure
```
Controller → Service → Repository → Database
    ↓          ↓
  DTO      Entity
```

### Key Design Patterns
- **DTO Pattern** - Separation between API and domain models
- **Repository Pattern** - Data access abstraction
- **Service Layer** - Business logic encapsulation
- **Global Exception Handler** - Centralized error handling

### Best Practices Implemented
✅ Input validation with Bean Validation
✅ Transaction management
✅ Comprehensive logging
✅ Pagination for large datasets
✅ Proper HTTP status codes
✅ RESTful API design
✅ Inventory management with concurrency safety
✅ Clean code architecture
