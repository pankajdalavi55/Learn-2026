# Flexera IAM - Complete Database Schema & Relationships

## Overview
The Flexera IAM system uses a combination of **PostgreSQL** (for relational data) and **MongoDB** (for document-based data). The database is named `global_resource_service` (grs_production in production).

---

## Database: PostgreSQL (Primary)

### Core Entity Tables

#### 1. **users**
**Purpose**: Central user identity table
- `id` (INTEGER, PK)
- `email` (TEXT, UNIQUE)
- `first_name` (TEXT)
- `last_name` (TEXT)
- `company` (TEXT)
- `phone` (TEXT)
- `timezone_name` (TEXT)
- `okta_id` (TEXT) - Integration with Okta
- `authority` (TEXT) - Authentication authority
- `password_verifiers` (TEXT) - Hashed passwords
- `platform_roles` (JSONB) - Platform-level roles
- `global_object_version` (INTEGER) - Optimistic locking
- `global_object_checksum` (TEXT) - Data integrity
- `last_ui_login` (TIMESTAMPTZ)
- `last_api_login` (TIMESTAMPTZ)
- `has_active_refresh_token` (BOOLEAN)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Relationships**:
- Has many `affiliations` (1:N)
- Has many `group_memberships` (1:N)
- Has many `service_accounts` (as creator, 1:N)
- Referenced by `invitations` (inviter/invitee)
- Has many `access_rules` (as subject)

---

#### 2. **orgs** (Organizations)
**Purpose**: Top-level tenant organizations
- `id` (INTEGER, PK)
- `name` (TEXT, UNIQUE)
- `description` (TEXT)
- `owner_id` (INTEGER, FK → users.id)
- `partner_id` (TEXT) - External partner reference
- `parent_org_id` (INTEGER, FK → orgs.id) - For org hierarchy
- `msp_org_id` (INTEGER, FK → orgs.id) - MSP parent org
- `cm_enterprise_id` (INTEGER) - Cloud Management integration
- `plan_id` (TEXT) - Subscription plan
- `shard_id` (INTEGER) - Database shard
- `shard_hostname` (TEXT)
- `product_enablement` (JSONB) - Enabled products
- `legacy` (BOOLEAN)
- `max_projects` (INTEGER)
- `snow_atlas_tenant_id` (TEXT) - ServiceNow Atlas integration
- `msp_external_id` (TEXT) - External MSP identifier
- `authority` (TEXT)
- `last_org_activity` (TIMESTAMPTZ)
- `global_object_version` (INTEGER)
- `global_object_checksum` (TEXT)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Relationships**:
- Self-referencing for hierarchy (parent_org_id)
- Has many `projects` (1:N)
- Has many `affiliations` (1:N)
- Has many `groups` (1:N)
- Has many `roles` (1:N)
- Has many `access_policies` (1:N)
- Has many `org_attributes` (1:N)
- Has many `contracts` (as initiator or target, 1:N)

---

#### 3. **projects**
**Purpose**: Sub-organizational units within orgs
- `id` (INTEGER, PK)
- `org_id` (INTEGER, FK → orgs.id, NOT NULL)
- `name` (TEXT, NOT NULL)
- `description` (TEXT)
- `authority` (TEXT)
- `global_object_version` (INTEGER)
- `global_object_checksum` (TEXT)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Relationships**:
- Belongs to `orgs` (N:1)
- Has many `affiliations` (1:N)
- Referenced by `access_rules` (scope)

---

#### 4. **affiliations**
**Purpose**: User-to-org/project membership with roles
- `user_id` (INTEGER, FK → users.id, NOT NULL)
- `org_id` (INTEGER, FK → orgs.id, NOT NULL)
- `project_id` (INTEGER, FK → projects.id, NULL)
- `authority` (TEXT)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Composite Key**: (user_id, org_id, project_id)

**Relationships**:
- Belongs to `users` (N:1)
- Belongs to `orgs` (N:1)
- Optionally belongs to `projects` (N:1)
- Linked to roles via `access_rules`

---

### Access Control Tables

#### 5. **roles**
**Purpose**: Role definitions with privileges
- `id` (INTEGER, PK)
- `org_id` (INTEGER, FK → orgs.id, NOT NULL)
- `name` (TEXT, NOT NULL)
- `description` (TEXT)
- `authority` (TEXT)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Unique**: (org_id, name)

**Relationships**:
- Belongs to `orgs` (N:1)
- Has many `role_privileges` (1:N)
- Referenced by `access_rules`

---

#### 6. **privileges**
**Purpose**: Granular permission definitions
- `id` (INTEGER, PK)
- `name` (TEXT, UNIQUE, NOT NULL)
- `display_name` (TEXT)
- `description` (TEXT)
- `category` (TEXT)
- `suite` (TEXT) - Product suite
- `capability_name` (TEXT)
- `action` (TEXT)
- `resource` (TEXT)
- `scopes` (TEXT[]) - Applicable scopes
- `created_at` (TIMESTAMPTZ)

**Relationships**:
- Has many `role_privileges` (1:N)

---

#### 7. **role_privileges**
**Purpose**: Junction table linking roles to privileges
- `role_id` (INTEGER, FK → roles.id, NOT NULL)
- `privilege_id` (INTEGER, FK → privileges.id, NOT NULL)
- `created_at` (TIMESTAMPTZ)

**Composite PK**: (role_id, privilege_id)

**Relationships**:
- Belongs to `roles` (N:1)
- Belongs to `privileges` (N:1)

---

#### 8. **access_rules**
**Purpose**: Grant roles to subjects (users/groups) at specific scopes
- `id` (SERIAL, PK)
- `role_href` (TEXT, NOT NULL) - Reference to role
- `subject_href` (TEXT, NOT NULL) - User/Group/ServiceAccount reference
- `scope_href` (TEXT, NOT NULL) - Org/Project scope
- `created_at` (TIMESTAMPTZ)

**Indexes**: role_href, subject_href, scope_href

**Relationships**:
- References `roles` via href pattern
- References `users`, `groups`, or `service_accounts` via subject_href
- References `orgs` or `projects` via scope_href

---

### Group Management Tables

#### 9. **groups**
**Purpose**: User groups within organizations
- `id` (INTEGER, PK)
- `org_id` (INTEGER, FK → orgs.id, NOT NULL)
- `name` (TEXT, NOT NULL)
- `description` (TEXT)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Unique**: (org_id, name)

**Relationships**:
- Belongs to `orgs` (N:1)
- Has many `group_memberships` (1:N)
- Has many `group_policy_assignments` (1:N)
- Referenced by `access_rules`

---

#### 10. **group_memberships**
**Purpose**: User-to-group relationships
- `user_id` (INTEGER, FK → users.id, NOT NULL)
- `group_id` (INTEGER, FK → groups.id, NOT NULL)
- `created_at` (TIMESTAMPTZ)

**Composite PK**: (user_id, group_id)

**Relationships**:
- Belongs to `users` (N:1)
- Belongs to `groups` (N:1)

---

### Granular Access Control Tables

#### 11. **org_attributes**
**Purpose**: Organizational structure attribute definitions
- `id` (SERIAL, PK, UNIQUE)
- `org_id` (INTEGER, FK → orgs.id, NOT NULL)
- `name` (TEXT, NOT NULL) - e.g., "location", "business_unit"
- `description` (TEXT)
- `is_builtin` (BOOLEAN, NOT NULL)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Index**: org_id

**Relationships**:
- Belongs to `orgs` (N:1)
- Has many `org_attribute_nodes` (1:N)

---

#### 12. **org_attribute_nodes**
**Purpose**: Hierarchical nodes within org attributes (using ltree)
- `path` (TEXT, PK, UNIQUE) - Full path (e.g., "location/asia/india")
- `attribute_name` (TEXT, FK → org_attributes.name, NOT NULL)
- `org_id` (INTEGER, FK → orgs.id, NOT NULL)
- `name` (TEXT, NOT NULL)
- `description` (TEXT)
- `parent_path` (TEXT, FK → org_attribute_nodes.path, NULL)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Constraints**:
- UNIQUE (org_id, name)
- Self-referencing FK on parent_path

**Indexes**: attribute_name, org_id, path (GIST for ltree)

**Relationships**:
- Belongs to `org_attributes` (N:1)
- Self-referencing for hierarchy (parent_path)
- Referenced by `granular_scopes` (via JSON scope field)

---

#### 13. **access_policies**
**Purpose**: Named access policy containers
- `id` (UUID, PK)
- `org_id` (INTEGER, FK → orgs.id, NOT NULL)
- `name` (TEXT, NOT NULL)
- `description` (TEXT)
- `created_by` (INTEGER, FK → users.id, NOT NULL)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Relationships**:
- Belongs to `orgs` (N:1)
- Has many `iam_roles` via `access_policy_roles` (M:N)
- Has many `groups` via `group_policy_assignments` (M:N)

---

#### 14. **iam_roles**
**Purpose**: IAM role definitions containing scoped permissions
- `id` (UUID, PK)
- `org_id` (INTEGER, FK → orgs.id, NOT NULL)
- `name` (TEXT, NOT NULL)
- `description` (TEXT)
- `created_by` (INTEGER, FK → users.id, NOT NULL)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Relationships**:
- Belongs to `orgs` (N:1)
- Has many `access_policies` via `access_policy_roles` (M:N)
- Has many `granular_scoped_permissions` via junction (M:N)

---

#### 15. **granular_scopes**
**Purpose**: Multi-dimensional access scope definitions
- `id` (UUID, PK)
- `org_id` (INTEGER, FK → orgs.id, NOT NULL)
- `name` (TEXT, NOT NULL)
- `description` (TEXT)
- `scope` (JSONB, NOT NULL) - Array of attribute/node combinations
- `created_by` (INTEGER, FK → users.id, NOT NULL)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Relationships**:
- Belongs to `orgs` (N:1)
- Has many `granular_scoped_permissions` (1:N)
- References `org_attribute_nodes` via JSON scope

---

#### 16. **granular_scoped_permissions**
**Purpose**: Permission + Scope combinations
- `id` (UUID, PK)
- `org_id` (INTEGER, FK → orgs.id, NOT NULL)
- `name` (TEXT, NOT NULL)
- `description` (TEXT)
- `grs_role_id` (INTEGER, FK → roles.id) - Legacy GRS role
- `granular_scope_id` (UUID, FK → granular_scopes.id, NOT NULL)
- `permissions` (TEXT[]) - Array of permission names
- `permission_category` (TEXT)
- `created_by` (INTEGER, FK → users.id, NOT NULL)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Relationships**:
- Belongs to `orgs` (N:1)
- Belongs to `granular_scopes` (N:1)
- Has many `iam_roles` via junction (M:N)

---

#### 17. **iam_role_granular_scoped_permissions** (Junction)
**Purpose**: Links IAM roles to their scoped permissions
- `id` (SERIAL, PK)
- `iam_role_id` (UUID, FK → iam_roles.id, NOT NULL)
- `granular_scoped_permission_id` (UUID, FK → granular_scoped_permissions.id, NOT NULL)
- `org_id` (INTEGER)
- `created_by` (INTEGER)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Relationships**:
- Belongs to `iam_roles` (N:1)
- Belongs to `granular_scoped_permissions` (N:1)

---

#### 18. **access_policy_roles** (Junction)
**Purpose**: Links access policies to IAM roles
- `id` (SERIAL, PK)
- `access_policy_id` (UUID, FK → access_policies.id, NOT NULL)
- `iam_role_id` (UUID, FK → iam_roles.id, NOT NULL)
- `org_id` (INTEGER)
- `created_by` (INTEGER)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Relationships**:
- Belongs to `access_policies` (N:1)
- Belongs to `iam_roles` (N:1)

---

#### 19. **group_policy_assignments** (Junction)
**Purpose**: Assigns access policies to groups
- `grs_group_id` (INTEGER, FK → groups.id, NOT NULL)
- `access_policy_id` (UUID, FK → access_policies.id, NOT NULL)
- `policy_type` (TEXT) - Type classification
- `org_id` (INTEGER, FK → orgs.id, NOT NULL)
- `created_by` (INTEGER)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Relationships**:
- Belongs to `groups` (N:1)
- Belongs to `access_policies` (N:1)

---

### Service Account Tables

#### 20. **service_accounts**
**Purpose**: Machine/application identities
- `id` (INTEGER, PK)
- `org_id` (INTEGER, FK → orgs.id, NOT NULL)
- `name` (TEXT, NOT NULL)
- `description` (TEXT)
- `created_by` (INTEGER, FK → users.id, NOT NULL)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Index**: org_id

**Relationships**:
- Belongs to `orgs` (N:1)
- Created by `users` (N:1)
- Has many `service_account_clients` (1:N)
- Referenced by `access_rules`

---

#### 21. **service_account_clients**
**Purpose**: OAuth clients for service accounts
- `id` (TEXT, PK) - Client ID
- `service_account_id` (INTEGER, FK → service_accounts.id, NOT NULL)
- `created_by` (INTEGER, FK → users.id, NOT NULL)
- `created_at` (TIMESTAMPTZ)

**Index**: service_account_id

**Relationships**:
- Belongs to `service_accounts` (N:1)
- Created by `users` (N:1)

---

### Contract Management Tables

#### 22. **contracts**
**Purpose**: MSP contracts between organizations
- `id` (BIGSERIAL, PK)
- `initiator_org_id` (INTEGER, FK → orgs.id, NOT NULL)
- `target_org_id` (INTEGER, FK → orgs.id, NOT NULL)
- `title` (TEXT, NOT NULL)
- `description` (TEXT)
- `status` (TEXT, NOT NULL) - pending/active/inactive
- `allowed_capabilities` (JSONB, NOT NULL)
- `created_by` (INTEGER, FK → users.id, NOT NULL)
- `expires_at` (TIMESTAMPTZ, NOT NULL)
- `enable` (BOOLEAN, NOT NULL)
- `last_seen` (TIMESTAMPTZ)
- `deleted_at` (TIMESTAMPTZ)
- `created_at` (TIMESTAMPTZ)
- `updated_at` (TIMESTAMPTZ)

**Indexes**: initiator_org_id, target_org_id

**Relationships**:
- Belongs to `orgs` as initiator (N:1)
- Belongs to `orgs` as target (N:1)
- Created by `users` (N:1)

---

## Database: MongoDB (Document Store)

### 1. **invitations**
**Purpose**: User invitation tracking
- `_id` (ObjectId, PK)
- `inviter_id` (INTEGER) - User who sent invitation
- `invitee_id` (INTEGER) - User who received invitation (if exists)
- `invitee_email` (TEXT) - Email for new users
- `org_invitation` (Object) - Org-level invitation
  - `id` (INTEGER) - Org ID
  - `roles` (Array) - Role hrefs
- `project_invitations` (Array) - Project-level invitations
  - `id` (INTEGER) - Project ID
  - `roles` (Array) - Role hrefs
- `group_ids` (Array) - Group IDs to add user to
- `invitation_scope` (TEXT) - org/project
- `status` (TEXT) - pending/accepted/expired
- `activation_token` (TEXT, UNIQUE)
- `created_at` (Date)
- `expires_at` (Date)
- `updated_at` (Date)

---

### 2. **capabilities**
**Purpose**: Product capability definitions
- `_id` (String, PK) - Capability ID
- `description` (TEXT)
- `roles` (Array) - Role definitions for this capability
- `term_definitions` (Array) - Capability-specific terminology
- `terms` (Array) - Terms and conditions
- `api_names` (Array) - Associated API names
- `onboarding_messages_enabled` (Boolean)
- `onboarding_tasks` (Array)
- `created_at` (Date)
- `updated_at` (Date)

---

### 3. **orgs_capabilities**
**Purpose**: Capability enablement per organization
- `_id` (ObjectId, PK)
- `org_id` (INTEGER)
- `capability_name` (TEXT)
- `status` (TEXT) - enabled/disabled
- `error` (TEXT) - Error details if any
- `created_at` (Date)
- `updated_at` (Date)
- `expire_at` (Date) - TTL index for cleanup

---

### 4. **apis**
**Purpose**: API service definitions
- `_id` (String, PK) - API name
- `description` (TEXT)
- `created_at` (Date)
- `updated_at` (Date)

---

### 5. **role_definitions**
**Purpose**: Role definitions in MongoDB (Permission Management Service)
- `_id` (ObjectId, PK)
- `id` (String) - Role ID
- `name` (TEXT)
- `display_name` (TEXT)
- `description` (TEXT)
- `category` (TEXT)
- `org_id` (INTEGER)
- `capability_name` (TEXT)
- `privilege_ids` (Array) - Privilege IDs
- `scopes` (Array)
- `global_object_version` (INTEGER)
- `created_at` (Date)
- `updated_at` (Date)

---

### 6. **partners**
**Purpose**: Partner organization information
- `_id` (ObjectId, PK)
- `code` (TEXT, UNIQUE) - Partner code
- `name` (TEXT)
- `description` (TEXT)
- `created_at` (Date)
- `updated_at` (Date)

---

### 7. **identity_providers** (SAML2)
**Purpose**: SAML identity provider configurations
- `_id` (ObjectId, PK)
- `org_id` (INTEGER)
- `okta_id` (TEXT) - Okta integration ID
- `name` (TEXT)
- `sso_url` (TEXT) - Single Sign-On URL
- `issuer_uri` (TEXT)
- `acs_url` (TEXT) - Assertion Consumer Service URL
- `audience_uri` (TEXT)
- `request_binding` (TEXT)
- `request_signing_key_id` (TEXT)
- `request_signature_algorithm` (TEXT)
- `response_signature_algorithm` (TEXT)
- `response_signature_verification` (TEXT)
- `sign_authn_requests` (Boolean)
- `certificate_public_key_id` (TEXT)
- `jit_provisioning_enabled` (Boolean)
- `idp_profile_master` (Boolean)
- `group_sync_policy` (Object)
- `metadata_url` (TEXT)
- `logout_redirect_url` (TEXT)
- `created_at` (Date)
- `updated_at` (Date)

---

### 8. **idp_domains** (SAML2 Domains)
**Purpose**: Email domain to IDP mapping
- `_id` (ObjectId, PK)
- `org_id` (INTEGER)
- `idp_id` (ObjectId) - References identity_providers
- `name` (TEXT) - Domain name (e.g., "company.com")
- `discovery_hint` (TEXT)
- `verification_code` (TEXT)
- `verified_at` (Date)
- `created_at` (Date)
- `updated_at` (Date)

---

### 9. **signing_keys** (SAML2)
**Purpose**: SAML request signing keys
- `_id` (ObjectId, PK)
- `key_id` (TEXT, UNIQUE)
- `key_blob` (TEXT) - Encrypted key material
- `created_at` (Date)

---

### 10. **login_policies**
**Purpose**: Organization login policies
- `_id` (ObjectId, PK)
- `org_id` (INTEGER, UNIQUE)
- `enforce_sso` (Boolean)
- `default_idp_id` (ObjectId) - Default identity provider
- `created_at` (Date)
- `updated_at` (Date)

---

### 11. **password_resets**
**Purpose**: Password reset token tracking
- `_id` (ObjectId, PK)
- `user_id` (INTEGER)
- `okta_id` (TEXT)
- `reset_token` (TEXT, UNIQUE)
- `created_at` (Date)
- `expires_at` (Date)

---

### 12. **resource_tags**
**Purpose**: Resource tagging system
- `_id` (ObjectId, PK)
- `resource_href` (TEXT) - Resource reference
- `tags` (Object) - Key-value tag pairs
- `created_at` (Date)
- `updated_at` (Date)

---

### 13. **projects** (GoodData)
**Purpose**: GoodData project mappings
- `_id` (ObjectId, PK)
- `good_data_project_id` (TEXT)
- `org_id` (INTEGER)
- `capability_id` (TEXT)
- `created_at` (Date)
- `updated_at` (Date)

---

### 14. **project_users** (GoodData)
**Purpose**: GoodData user-to-project mappings
- `_id` (ObjectId, PK)
- `user_id` (INTEGER)
- `good_data_project_id` (TEXT)
- `good_data_user_href` (TEXT)
- `roles` (Array)
- `created_at` (Date)
- `updated_at` (Date)

---

### 15. **users** (GoodData)
**Purpose**: GoodData user profiles
- `_id` (ObjectId, PK)
- `user_id` (INTEGER)
- `good_data_user_href` (TEXT)
- `created_at` (Date)
- `updated_at` (Date)

---

## Complete Entity Relationship Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                           CORE IDENTITY & TENANT                            │
└─────────────────────────────────────────────────────────────────────────────┘

                    ┌──────────────┐
                    │    users     │
                    │  (PostgreSQL)│
                    └───────┬──────┘
                            │
         ┌──────────────────┼──────────────────┐
         │                  │                  │
         ▼                  ▼                  ▼
  ┌────────────┐    ┌──────────────┐   ┌──────────────┐
  │affiliations│    │    groups    │   │   service    │
  └──────┬─────┘    │(memberships) │   │  accounts    │
         │          └──────┬───────┘   └──────────────┘
         │                 │
         ▼                 │
  ┌────────────┐           │           ┌──────────────┐
  │   orgs     │◄──────────┘           │   projects   │
  │ (tenant)   │◄──────────────────────┤  (sub-org)   │
  └──────┬─────┘                       └──────────────┘
         │
         └─────┬────────┬─────────┬──────────┬──────────┐
               │        │         │          │          │
               ▼        ▼         ▼          ▼          ▼
         ┌────────┐ ┌────────┐ ┌─────┐ ┌────────┐ ┌────────┐
         │ roles  │ │ groups │ │org_ │ │access_ │ │contracts│
         │        │ │        │ │attrs│ │policies│ │        │
         └────────┘ └────────┘ └─────┘ └────────┘ └────────┘


┌─────────────────────────────────────────────────────────────────────────────┐
│                    TRADITIONAL RBAC (Legacy GRS)                            │
└─────────────────────────────────────────────────────────────────────────────┘

  ┌────────────┐         ┌──────────────┐         ┌─────────────┐
  │   roles    │────────▶│role_privileges│◄────────│ privileges  │
  │            │    1:N  │  (junction)   │   N:1   │             │
  └──────┬─────┘         └───────────────┘         └─────────────┘
         │
         │ referenced by
         ▼
  ┌─────────────────┐
  │  access_rules   │───────▶ subject_href (users/groups/service_accounts)
  │  (grants)       │───────▶ scope_href (orgs/projects)
  └─────────────────┘


┌─────────────────────────────────────────────────────────────────────────────┐
│              GRANULAR ACCESS CONTROL (New IAM System)                       │
└─────────────────────────────────────────────────────────────────────────────┘

┌────────────────┐
│org_attributes  │ (e.g., location, business_unit, cost_center)
└───────┬────────┘
        │ 1:N (attribute_name FK)
        ▼
┌────────────────────┐
│org_attribute_nodes │ (hierarchical: location/asia/india)
│  (uses ltree)      │ ◄─── self-referencing (parent_path)
└────────────────────┘
        │
        │ referenced by JSON scope
        ▼
┌─────────────────┐          ┌───────────────────────────┐
│granular_scopes  │──────────▶│granular_scoped_permissions│
│                 │   1:N    │  (permission + scope)     │
└─────────────────┘          └─────────────┬─────────────┘
                                           │ M:N
                             ┌─────────────▼──────────────┐
                             │iam_role_granular_scoped_   │
                             │permissions (junction)      │
                             └─────────────┬──────────────┘
                                           │
                                           ▼
                             ┌─────────────────────┐
                             │    iam_roles        │
                             │                     │
                             └──────────┬──────────┘
                                        │ M:N
                              ┌─────────▼─────────┐
                              │access_policy_roles│
                              │   (junction)      │
                              └─────────┬─────────┘
                                        │
                                        ▼
                              ┌──────────────────┐
                              │ access_policies  │
                              └────────┬─────────┘
                                       │ M:N
                            ┌──────────▼──────────┐
                            │group_policy_        │
                            │assignments          │
                            │(junction)           │
                            └──────────┬──────────┘
                                       │
                                       ▼
                              ┌────────────────┐
                              │    groups      │
                              └────────┬───────┘
                                       │
                                       ▼
                              ┌────────────────┐
                              │group_memberships│
                              └────────┬───────┘
                                       │
                                       ▼
                              ┌────────────────┐
                              │     users      │
                              └────────────────┘


┌─────────────────────────────────────────────────────────────────────────────┐
│                        SERVICE ACCOUNTS & CLIENTS                           │
└─────────────────────────────────────────────────────────────────────────────┘

  ┌────────────────┐         ┌──────────────────────┐
  │     users      │────────▶│  service_accounts    │
  │  (creator)     │  creates│                      │
  └────────────────┘         └──────────┬───────────┘
                                        │ 1:N
                                        ▼
                             ┌──────────────────────┐
                             │service_account_clients│
                             │  (OAuth clients)     │
                             └──────────────────────┘


┌─────────────────────────────────────────────────────────────────────────────┐
│                    MSP (Managed Service Provider)                           │
└─────────────────────────────────────────────────────────────────────────────┘

  ┌────────────┐             ┌─────────────┐
  │   orgs     │────────────▶│  contracts  │
  │ (initiator)│  creates    │             │
  └────────────┘             └──────┬──────┘
                                    │ references
       ┌────────────┐               │
       │   orgs     │◄──────────────┘
       │  (target)  │
       └────────────┘


┌─────────────────────────────────────────────────────────────────────────────┐
│                    MONGODB COLLECTIONS (Document Store)                     │
└─────────────────────────────────────────────────────────────────────────────┘

  invitations         → References users (inviter_id, invitee_id)
                      → References orgs (org_invitation.id)
                      → References projects (project_invitations[].id)
                      → References groups (group_ids[])

  capabilities        → Referenced by orgs_capabilities
                      → Contains role definitions

  orgs_capabilities   → References orgs (org_id)
                      → References capabilities (capability_name)

  role_definitions    → References orgs (org_id)
                      → References privileges (privilege_ids[])
                      → References capabilities (capability_name)

  identity_providers  → References orgs (org_id)
  idp_domains        → References orgs (org_id)
                      → References identity_providers (idp_id)
  login_policies     → References orgs (org_id)
                      → References identity_providers (default_idp_id)

  partners           → Referenced by orgs (partner_id)

  password_resets    → References users (user_id)

  resource_tags      → Generic tagging system (resource_href pattern)


┌─────────────────────────────────────────────────────────────────────────────┐
│                    GOODDATA INTEGRATION (MongoDB)                           │
└─────────────────────────────────────────────────────────────────────────────┘

  projects           → References orgs (org_id)
                     → GoodData project mapping

  project_users      → References users (user_id)
                     → References projects (good_data_project_id)

  users              → References users (user_id)
                     → GoodData user profile
```

---

## Key Relationships Summary

### User Access Flow
1. **User** → affiliates to **Org** (via affiliations)
2. **User** → joins **Groups** (via group_memberships)
3. **Groups** → assigned **Access Policies** (via group_policy_assignments)
4. **Access Policies** → contain **IAM Roles** (via access_policy_roles)
5. **IAM Roles** → have **Granular Scoped Permissions** (via junction)
6. **Granular Scoped Permissions** → combine **Permissions** + **Granular Scopes**
7. **Granular Scopes** → reference **Org Attribute Nodes** (hierarchical paths)

### Legacy RBAC Flow (GRS)
1. **User/Group** → granted **Roles** at **Scope** (via access_rules)
2. **Roles** → contain **Privileges** (via role_privileges)
3. **Scope** → Org or Project level

### Hierarchical Structures
- **Orgs** can have parent/child relationships (parent_org_id)
- **Orgs** can have **MSP parent** (msp_org_id)
- **Org Attribute Nodes** form trees within attributes (parent_path)
- **Projects** belong to **Orgs**

---

## Database Engines

| Database      | Purpose                    | Tables/Collections |
|---------------|----------------------------|-------------------|
| **PostgreSQL**| Relational data, ACID      | 22 tables         |
| **MongoDB**   | Documents, flexible schema | 15+ collections   |

---

## Foreign Key Constraints

### PostgreSQL Foreign Keys:
- `orgs.owner_id` → `users.id`
- `orgs.parent_org_id` → `orgs.id`
- `orgs.msp_org_id` → `orgs.id`
- `projects.org_id` → `orgs.id`
- `affiliations.user_id` → `users.id`
- `affiliations.org_id` → `orgs.id`
- `affiliations.project_id` → `projects.id`
- `roles.org_id` → `orgs.id`
- `role_privileges.role_id` → `roles.id`
- `role_privileges.privilege_id` → `privileges.id`
- `groups.org_id` → `orgs.id`
- `group_memberships.user_id` → `users.id`
- `group_memberships.group_id` → `groups.id`
- `service_accounts.org_id` → `orgs.id`
- `service_accounts.created_by` → `users.id`
- `service_account_clients.service_account_id` → `service_accounts.id`
- `org_attributes.org_id` → `orgs.id`
- `org_attribute_nodes.attribute_name` → `org_attributes.name`
- `org_attribute_nodes.parent_path` → `org_attribute_nodes.path`
- `access_policies.org_id` → `orgs.id`
- `iam_roles.org_id` → `orgs.id`
- `granular_scopes.org_id` → `orgs.id`
- `granular_scoped_permissions.org_id` → `orgs.id`
- `granular_scoped_permissions.granular_scope_id` → `granular_scopes.id`
- `contracts.initiator_org_id` → `orgs.id`
- `contracts.target_org_id` → `orgs.id`

### MongoDB References (application-level):
- Most MongoDB collections reference PostgreSQL via numeric IDs
- No database-level FK constraints in MongoDB

---

## Indexes

### Critical Indexes:
- **users**: email (UNIQUE), okta_id
- **orgs**: name (UNIQUE), parent_org_id, msp_org_id
- **affiliations**: (user_id, org_id, project_id) composite
- **groups**: (org_id, name) composite UNIQUE
- **access_rules**: role_href, subject_href, scope_href
- **org_attribute_nodes**: path (GIST for ltree), attribute_name, org_id
- **group_memberships**: (user_id, group_id) composite

---

## Notes

1. **Dual RBAC Systems**: The platform supports both legacy GRS RBAC (roles + privileges + access_rules) and new Granular Access Control (access policies + IAM roles + scoped permissions)

2. **Hierarchical Data**: org_attribute_nodes uses PostgreSQL ltree extension for efficient hierarchical queries

3. **Multi-tenancy**: All data is scoped to organizations (org_id)

4. **Soft Deletes**: Some tables use `deleted_at` timestamp instead of hard deletes

5. **Optimistic Locking**: Uses `global_object_version` for concurrency control

6. **External Integrations**: 
   - Okta (okta_id fields)
   - GoodData (separate collections)
   - ServiceNow Atlas (snow_atlas_tenant_id)
   - Cloud Management (cm_enterprise_id)

---

**Generated**: December 2, 2025
**Database**: global_resource_service (PostgreSQL + MongoDB)
