# MyShop E-Commerce Platform - Project Overview

## 📋 Project Summary

This is a full-stack e-commerce platform consisting of:
- **Backend**: Spring Boot REST API (Java) - Located in `my-app/`
- **Frontend**: React + TypeScript SPA - Located in `my-app-ui/`

## 🏗️ Architecture

### Backend (Spring Boot)
- **Framework**: Spring Boot 3.x
- **Database**: MySQL
- **Security**: JWT-based authentication
- **API Documentation**: Swagger/OpenAPI
- **Port**: 8080

### Frontend (React)
- **Framework**: React 18 + TypeScript
- **Build Tool**: Vite
- **Styling**: Tailwind CSS
- **Routing**: React Router DOM v6
- **State Management**: React Context API
- **HTTP Client**: Axios
- **Port**: 5173 (development)

## 🎯 Key Features

### User Management & Authentication
- ✅ User registration and login
- ✅ JWT token-based authentication
- ✅ Role-based access control (RBAC)
- ✅ 5 user roles: CUSTOMER, VENDOR, SUPPORT, MANAGER, ADMIN

### Product Management
- ✅ Browse products with pagination
- ✅ Advanced filtering (category, brand, price range)
- ✅ Product search
- ✅ Product details view
- ✅ CRUD operations for products (Admin/Manager/Vendor)

### Shopping Cart
- ✅ Add items to cart
- ✅ Update quantities
- ✅ Remove items
- ✅ Real-time cart total calculation
- ✅ Persistent cart (per user)

### Order Management
- ✅ Place orders from cart
- ✅ Order history with pagination
- ✅ Order status tracking
- ✅ Order details view
- ✅ Cancel orders (pending only)

### Category Management
- ✅ Hierarchical categories
- ✅ CRUD operations (Admin/Manager)
- ✅ Filter products by category

### Admin Dashboard
- ✅ Role-based access
- ✅ Quick links to management interfaces
- ✅ Overview of system entities

## 📂 Project Structure

### Backend Structure
```
my-app/
├── src/main/java/com/pd/my_app/
│   ├── config/          # Security & app configuration
│   ├── controller/      # REST controllers
│   ├── dto/            # Data Transfer Objects
│   ├── entity/         # JPA entities
│   ├── exception/      # Custom exceptions
│   ├── repository/     # JPA repositories
│   ├── security/       # Security components (JWT)
│   └── service/        # Business logic
├── src/main/resources/
│   └── application.yaml # Application configuration
└── build.gradle        # Dependencies
```

### Frontend Structure
```
my-app-ui/
├── src/
│   ├── components/     # Reusable UI components
│   │   ├── common/    # Navbar, Footer, Loading, etc.
│   │   ├── product/   # Product card, filters
│   │   ├── cart/      # Cart-related components
│   │   └── order/     # Order components
│   ├── context/       # React Context (Auth, Cart)
│   ├── pages/         # Page components/views
│   ├── services/      # API service layer
│   ├── types/         # TypeScript type definitions
│   ├── utils/         # Helper functions
│   ├── App.tsx        # Main app with routing
│   └── main.tsx       # Entry point
├── tailwind.config.js # Tailwind configuration
├── package.json       # Dependencies
└── README.md          # Documentation
```

## 🚀 Getting Started

### Prerequisites
- Java 17+
- Node.js 18+
- MySQL 8+
- npm or yarn

### Backend Setup
```bash
cd my-app

# Update database credentials in src/main/resources/application.yaml
# MySQL should be running on localhost:3306

# Build and run
./gradlew bootRun

# API will be available at http://localhost:8080
# Swagger UI: http://localhost:8080/swagger-ui.html
```

### Frontend Setup
```bash
cd my-app-ui

# Install dependencies
npm install

# Start development server
npm run dev

# App will be available at http://localhost:5173
```

### Database Setup
The application uses MySQL. Create a database:
```sql
CREATE DATABASE app_data;
```

Spring Boot will automatically create tables on first run (ddl-auto: update).

## 🔐 Security & Roles

### Role Hierarchy
1. **CUSTOMER** (Default)
   - Browse products
   - Manage own cart
   - Place orders
   - View own orders

2. **VENDOR**
   - All CUSTOMER permissions
   - Create/update/delete own products

3. **SUPPORT**
   - View all users (read-only)
   - View all orders and carts
   - Cannot modify data

4. **MANAGER**
   - All SUPPORT permissions
   - Manage all products
   - Manage categories
   - Update order status

5. **ADMIN** (Super user)
   - Full system access
   - User management
   - Role assignment
   - Override all restrictions

### Authentication Flow
1. User registers or logs in
2. Backend validates credentials
3. JWT token is generated and returned
4. Frontend stores token in localStorage
5. Token is included in subsequent API requests
6. Backend validates token on each request

## 🌐 API Endpoints

### Authentication
- `POST /api/auth/register` - Register new user
- `POST /api/auth/login` - Login user

### Products
- `GET /api/products` - List products (public)
- `GET /api/products/{id}` - Get product details
- `GET /api/products/search` - Search products
- `GET /api/products/filter` - Filter products
- `POST /api/products` - Create product (VENDOR+)
- `PUT /api/products/{id}` - Update product
- `DELETE /api/products/{id}` - Delete product (MANAGER+)

### Categories
- `GET /api/categories` - List categories (public)
- `GET /api/categories/{id}` - Get category
- `POST /api/categories` - Create category (MANAGER+)
- `PUT /api/categories/{id}` - Update category (MANAGER+)
- `DELETE /api/categories/{id}` - Delete category (MANAGER+)

### Cart
- `GET /api/cart?userId={id}` - Get user cart
- `POST /api/cart/add?userId={id}` - Add to cart
- `PUT /api/cart/update` - Update cart item
- `DELETE /api/cart/remove` - Remove from cart
- `DELETE /api/cart/clear` - Clear cart

### Orders
- `POST /api/orders?userId={id}` - Place order
- `GET /api/orders/{id}` - Get order details
- `GET /api/orders/user/{userId}` - User order history
- `PATCH /api/orders/{id}/status` - Update order status (MANAGER+)
- `POST /api/orders/{id}/cancel` - Cancel order

## 🎨 UI Features

### Responsive Design
- Mobile-first approach
- Tailwind CSS utility classes
- Responsive navigation
- Grid layouts for products

### User Experience
- Toast notifications for actions
- Loading states
- Error handling
- Form validation
- Protected routes
- Role-based UI rendering

### Pages
- **Home** - Product listing with filters
- **Product Detail** - Single product view
- **Cart** - Shopping cart management
- **Checkout** - Order placement
- **Orders** - Order history
- **Login/Register** - Authentication
- **Admin Dashboard** - Management interface

## 🧪 Testing

### Test Accounts
Create test users via registration or use the API:

```bash
# Customer
POST /api/auth/register
{
  "name": "Test Customer",
  "email": "customer@test.com",
  "phone": "1234567890",
  "password": "password123",
  "role": "CUSTOMER"
}

# Admin (requires existing admin to create)
POST /api/users (with admin token)
{
  "name": "Admin User",
  "email": "admin@test.com",
  "phone": "1234567890",
  "password": "password123",
  "role": "ADMIN"
}
```

## 📊 Database Schema

### Main Entities
- **User** - User accounts with roles
- **Product** - Product catalog
- **Category** - Product categories (hierarchical)
- **Cart** - Shopping carts
- **CartItem** - Items in cart
- **Order** - Customer orders
- **OrderItem** - Items in orders

### Relationships
- User 1:1 Cart
- Cart 1:N CartItem
- Product N:1 Category
- User 1:N Order
- Order 1:N OrderItem
- CartItem N:1 Product
- OrderItem N:1 Product

## 🔧 Configuration

### Backend Configuration (application.yaml)
```yaml
spring:
  datasource:
    url: jdbc:mysql://localhost:3306/app_data
    username: root
    password: root
  
jwt:
  secret: your-secret-key
  expiration: 86400000  # 24 hours
```

### Frontend Configuration (src/services/axios.ts)
```typescript
const API_BASE_URL = 'http://localhost:8080/api';
```

## 📈 Future Enhancements

Potential features to add:
- [ ] Product reviews and ratings
- [ ] Wishlist functionality
- [ ] Payment gateway integration
- [ ] Email notifications
- [ ] Advanced analytics dashboard
- [ ] Product recommendations
- [ ] Multi-language support
- [ ] Dark mode
- [ ] Social login (OAuth)
- [ ] Invoice generation

## 🐛 Known Issues

- Admin product/category management UI is placeholder (basic structure in place)
- No pagination controls on some admin views
- Image upload not implemented (URLs only)

## 📝 Development Notes

### Adding New Features
1. Backend: Create entity → repository → service → controller → DTO
2. Frontend: Create type → service → context (if needed) → component/page
3. Update routing in App.tsx
4. Add navigation links in Navbar

### Code Style
- Backend: Follow Spring Boot conventions
- Frontend: Use functional components with hooks
- TypeScript: Strict mode enabled
- CSS: Use Tailwind utility classes

## 🤝 Contributing

1. Create feature branch from main
2. Implement changes
3. Test thoroughly
4. Submit pull request

## 📄 License

This project is for educational/portfolio purposes.

## 👥 Contact

For questions or support, please contact the development team.
