# Profile Management Feature - Implementation Summary

## Overview
Added comprehensive user profile management with saved addresses and payment cards functionality, connected to the backend user ID.

## Backend Changes

### 1. New Entities Created

#### UserAddress.java
- **Location**: `src/main/java/com/pd/my_app/entity/UserAddress.java`
- **Fields**:
  - `id`, `user`, `label`, `fullName`, `phone`
  - `addressLine1`, `addressLine2`, `city`, `state`, `postalCode`, `country`
  - `isDefault`, `createdAt`, `updatedAt`
- **Relationship**: `@ManyToOne` with User entity
- **Features**: Auto-default for first address, timestamps

#### PaymentCard.java
- **Location**: `src/main/java/com/pd/my_app/entity/PaymentCard.java`
- **Fields**:
  - `id`, `user`, `label`, `cardholderName`
  - `cardNumberEncrypted`, `cardLastFour`, `cardType`
  - `expiryMonth`, `expiryYear`, `isDefault`, `createdAt`, `updatedAt`
- **Relationship**: `@ManyToOne` with User entity
- **Features**: Encrypted card storage, masked display, auto-default for first card

### 2. User Entity Updated
- **Location**: `src/main/java/com/pd/my_app/entity/User.java`
- **Added**:
  - `@OneToMany` relationship with `UserAddress` (cascade all, orphan removal)
  - `@OneToMany` relationship with `PaymentCard` (cascade all, orphan removal)

### 3. DTOs Created

#### UserAddressDTO.java
- **Location**: `src/main/java/com/pd/my_app/dto/UserAddressDTO.java`
- **Purpose**: Transfer address data between frontend and backend
- **Validation**: Jakarta validation annotations for all required fields

#### PaymentCardDTO.java
- **Location**: `src/main/java/com/pd/my_app/dto/PaymentCardDTO.java`
- **Purpose**: Transfer card data (includes masked display fields)
- **Validation**: Regex patterns for card number, expiry month/year

### 4. Repositories Created

#### UserAddressRepository.java
- **Location**: `src/main/java/com/pd/my_app/repository/UserAddressRepository.java`
- **Methods**:
  - `findByUserIdOrderByIsDefaultDescCreatedAtDesc(Long userId)`
  - `findByIdAndUserId(Long id, Long userId)`
  - `findByUserIdAndIsDefault(Long userId, Boolean isDefault)`
  - `countByUserId(Long userId)`

#### PaymentCardRepository.java
- **Location**: `src/main/java/com/pd/my_app/repository/PaymentCardRepository.java`
- **Methods**: Same pattern as UserAddressRepository

### 5. Services Created

#### UserAddressService.java
- **Location**: `src/main/java/com/pd/my_app/service/UserAddressService.java`
- **Features**:
  - CRUD operations for addresses
  - Auto-set first address as default
  - Clear previous default when setting new default
  - Auto-promote next address to default on deletion
  - User ID validation

#### PaymentCardService.java
- **Location**: `src/main/java/com/pd/my_app/service/PaymentCardService.java`
- **Features**:
  - CRUD operations for payment cards
  - AES encryption for card numbers
  - Store last 4 digits for display
  - Auto-set first card as default
  - Clear previous default when setting new default
  - Auto-promote next card to default on deletion
  - User ID validation

### 6. Controllers Created

#### UserAddressController.java
- **Location**: `src/main/java/com/pd/my_app/controller/UserAddressController.java`
- **Endpoints**:
  - `GET /api/user/addresses` - Get all user addresses
  - `POST /api/user/addresses` - Add new address
  - `PUT /api/user/addresses/{addressId}` - Update address
  - `DELETE /api/user/addresses/{addressId}` - Delete address
  - `PATCH /api/user/addresses/{addressId}/set-default` - Set default address
- **Security**: JWT token authentication, user ID extracted from token

#### PaymentCardController.java
- **Location**: `src/main/java/com/pd/my_app/controller/PaymentCardController.java`
- **Endpoints**:
  - `GET /api/user/cards` - Get all user cards
  - `POST /api/user/cards` - Add new card
  - `PUT /api/user/cards/{cardId}` - Update card
  - `DELETE /api/user/cards/{cardId}` - Delete card
  - `PATCH /api/user/cards/{cardId}/set-default` - Set default card
- **Security**: JWT token authentication, user ID extracted from token

## Frontend Changes

### Profile.tsx Updated
- **Location**: `my-app-ui/src/pages/Profile.tsx`

#### New Features:
1. **Saved Addresses Section**
   - Display all user addresses in grid layout
   - Visual indicator for default address (highlighted border, badge)
   - Add/Edit/Delete functionality with modals
   - Set default address button
   - Empty state with icon

2. **Saved Payment Cards Section**
   - Display all payment cards with masked numbers
   - Visual indicator for default card (highlighted border, badge)
   - Add/Edit/Delete functionality with modals
   - Set default card button
   - Shows card type, expiry, last 4 digits
   - Empty state with icon

3. **Address Modal Component**
   - Full form for adding/editing addresses
   - Fields: Label, Full Name, Phone, Address Lines, City, State, Postal Code, Country
   - Set as default checkbox
   - Form validation

4. **Card Modal Component**
   - Full form for adding/editing payment cards
   - Fields: Label, Cardholder Name, Card Number, Card Type, Expiry Month/Year
   - Set as default checkbox
   - Card type dropdown (Visa, Mastercard, Amex, Discover)
   - Numeric input validation for card number
   - Note: Card number optional when editing (keeps existing if empty)

5. **Updated Quick Stats**
   - Shows count of saved addresses
   - Shows count of payment cards
   - Total orders (placeholder)

#### API Integration:
- `fetchAddresses()` - GET user addresses
- `fetchPaymentCards()` - GET user cards
- `handleDeleteAddress()` - DELETE address with confirmation
- `handleSetDefaultAddress()` - PATCH set default address
- `handleDeleteCard()` - DELETE card with confirmation
- `handleSetDefaultCard()` - PATCH set default card

#### TypeScript Interfaces:
```typescript
interface Address {
  id: number;
  label: string;
  fullName: string;
  phone: string;
  addressLine1: string;
  addressLine2?: string;
  city: string;
  state: string;
  postalCode: string;
  country: string;
  isDefault: boolean;
}

interface PaymentCard {
  id: number;
  label: string;
  cardholderName: string;
  maskedCardNumber: string;
  cardLastFour: string;
  cardType: string;
  expiryMonth: string;
  expiryYear: string;
  isDefault: boolean;
}
```

## Database Schema

### New Tables Required

#### user_addresses
```sql
CREATE TABLE user_addresses (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  label VARCHAR(50),
  full_name VARCHAR(100) NOT NULL,
  phone VARCHAR(15) NOT NULL,
  address_line1 VARCHAR(255) NOT NULL,
  address_line2 VARCHAR(255),
  city VARCHAR(100) NOT NULL,
  state VARCHAR(100) NOT NULL,
  postal_code VARCHAR(20) NOT NULL,
  country VARCHAR(100) NOT NULL,
  is_default BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP,
  updated_at TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

#### payment_cards
```sql
CREATE TABLE payment_cards (
  id BIGINT PRIMARY KEY AUTO_INCREMENT,
  user_id BIGINT NOT NULL,
  label VARCHAR(50),
  cardholder_name VARCHAR(100) NOT NULL,
  card_number_encrypted VARCHAR(255) NOT NULL,
  card_last_four VARCHAR(4),
  card_type VARCHAR(20) NOT NULL,
  expiry_month VARCHAR(2) NOT NULL,
  expiry_year VARCHAR(4) NOT NULL,
  is_default BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP,
  updated_at TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);
```

## Security Features

1. **JWT Authentication**: All endpoints require valid JWT token
2. **User Isolation**: Users can only access their own addresses and cards
3. **Card Encryption**: Card numbers encrypted with AES before storage
4. **Masked Display**: Only last 4 digits shown in responses
5. **Input Validation**: Jakarta validation on all DTOs

## Key Business Logic

1. **Auto-Default**: First address/card automatically set as default
2. **Single Default**: Only one address and one card can be default
3. **Smart Deletion**: When default is deleted, next one becomes default
4. **Cascade Delete**: User deletion removes all addresses and cards

## Testing Checklist

- [ ] Create new address via API
- [ ] Update existing address
- [ ] Set address as default
- [ ] Delete address (default and non-default)
- [ ] Add new payment card
- [ ] Update card details
- [ ] Set card as default
- [ ] Delete card (default and non-default)
- [ ] Verify encryption of card numbers
- [ ] Test user isolation (can't access other users' data)
- [ ] Test frontend modals
- [ ] Verify default badges display correctly
- [ ] Test empty states

## Next Steps

1. **Database Migration**: Run migrations to create new tables
2. **Restart Backend**: Restart Spring Boot application
3. **Test API Endpoints**: Use Postman or similar tool
4. **Frontend Testing**: Test complete flow from UI
5. **Integration Testing**: Test with checkout flow

## API Documentation

### Address Endpoints

```
GET    /api/user/addresses              - Get all user addresses
POST   /api/user/addresses              - Add new address
PUT    /api/user/addresses/{id}         - Update address
DELETE /api/user/addresses/{id}         - Delete address
PATCH  /api/user/addresses/{id}/set-default - Set default
```

### Payment Card Endpoints

```
GET    /api/user/cards                  - Get all user cards
POST   /api/user/cards                  - Add new card
PUT    /api/user/cards/{id}             - Update card
DELETE /api/user/cards/{id}             - Delete card
PATCH  /api/user/cards/{id}/set-default - Set default
```

All endpoints require `Authorization: Bearer <token>` header.

## Notes

- Card encryption key is hardcoded in PaymentCardService - **replace with secure key management in production**
- First address/card is automatically set as default
- Users must have at least one default if any addresses/cards exist
- Deleting a default automatically promotes the next item to default
